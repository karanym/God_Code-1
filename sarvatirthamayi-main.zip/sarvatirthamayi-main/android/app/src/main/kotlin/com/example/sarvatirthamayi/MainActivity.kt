package com.example.sarvatirthamayi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
