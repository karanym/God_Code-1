import 'package:flutter/material.dart';
import 'package:sarvatirthamayi/main.dart';
import 'api/api_service.dart';
import 'thankyou_page.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TripBookingPage extends StatefulWidget {
  final int tripId;
  final String tripTitle;
  final String imageUrl;
  final int tripPrice;
  final String tripDuration;

  const TripBookingPage({
    super.key,
    required this.tripId,
    required this.tripTitle,
    required this.imageUrl,
    required this.tripPrice,
    required this.tripDuration,
  });

  @override
  _TripBookingPageState createState() => _TripBookingPageState();
}

class _TripBookingPageState extends State<TripBookingPage> {
  final Color themeColor = const Color(0xFF6A1B9A);
  final ApiService apiService = ApiService();
  final _storage = const FlutterSecureStorage();
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _startDateController = TextEditingController();
  final TextEditingController _noOfDevoteesController = TextEditingController();
  String? _selectedTripType;
  String? _paymentType;

  final List<String> _tripTypes = ["Pilgrimage", "Adventure", "Family Tour", "Custom"];
  final List<String> _paymentOptions = ["Online", "Offline"];

  int _currentStep = 1;
  int _totalPrice = 0;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _noOfDevoteesController.addListener(_calculateTotalPrice);
  }

  void _calculateTotalPrice() {
    final count = int.tryParse(_noOfDevoteesController.text) ?? 0;
    setState(() {
      _totalPrice = count * widget.tripPrice;
    });
  }

  Future<void> _loadUserData() async {
    final name = await _storage.read(key: 'user_name');
    final email = await _storage.read(key: 'user_email');
    final mobile = await _storage.read(key: 'user_mobile');
    setState(() {
      _nameController.text = name ?? '';
      _emailController.text = email ?? '';
      _mobileController.text = mobile ?? '';
    });
  }

  void _submitBookingForm() {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _currentStep = 2;
    });
  }

  void _submitPayment() {
    if (_paymentType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select a payment type")),
      );
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Payment type selected")),
    );
    setState(() {
      _currentStep = 3;
    });
  }

  void _goToThankYou() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => ThankYouPage(
          name: _nameController.text,
          mobile: _mobileController.text,
          email: _emailController.text,
          tripTitle: widget.tripTitle,
          imageUrl: widget.imageUrl,
          startDate: _startDateController.text,
          noOfDays: widget.tripDuration,
          noOfDevotees: _noOfDevoteesController.text,
          tripType: _selectedTripType ?? "",
          tripPrice: widget.tripPrice,
          totaltripPrice: _totalPrice,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Book Your Trip"),
        backgroundColor: themeColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildStepper(),
            const SizedBox(height: 20),
            _buildSectionTitle("Booking Progress"),
            const SizedBox(height: 20),
            _buildPriceDetails(),
            const SizedBox(height: 20),
            if (_currentStep == 1) _buildBookingForm(),
            if (_currentStep == 2) _buildPaymentStep(),
            if (_currentStep == 3) _buildSuccessStep(),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        const Expanded(
          child: Divider(thickness: 1, color: Colors.grey),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Text(
            title,
            style: const TextStyle(fontSize: 18, color: MyApp.themeColor, fontWeight: FontWeight.bold),
          ),
        ),
        const Expanded(
          child: Divider(thickness: 1, color: Colors.grey),
        ),
      ],
    );
  }

  Widget _buildStepper() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildStepCircle("1", "Details", _currentStep >= 1),
          _buildLine(),
          _buildStepCircle("2", "Payment", _currentStep >= 2),
          _buildLine(),
          _buildStepCircle("3", "Success", _currentStep >= 3),
        ],
      ),
    );
  }

  Widget _buildStepCircle(String step, String label, bool isActive) {
    return Column(
      children: [
        CircleAvatar(
          radius: 18,
          backgroundColor: isActive ? themeColor : Colors.grey[400],
          child: Text(
            step,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 5),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  Widget _buildLine() {
    return Expanded(
      child: Container(
        height: 2,
        color: Colors.grey[400],
      ),
    );
  }

  Widget _buildPriceDetails() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Trip: ${widget.tripTitle}", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text("Per Person Price: ₹${widget.tripPrice}", style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 4),
          Text("No. of Devotees: ${_noOfDevoteesController.text.isEmpty ? '0' : _noOfDevoteesController.text}", style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 4),
          Text("Total Price: ₹$_totalPrice", style: const TextStyle(fontSize: 18, color: Colors.green, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }


  Widget _buildBookingForm() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            _buildTextField("Full Name", _nameController, Icons.person),
            _buildTextField("Email", _emailController, Icons.email, inputType: TextInputType.emailAddress),
            _buildTextField("Mobile", _mobileController, Icons.phone, inputType: TextInputType.phone),
            _buildDateField("Select Start Date", _startDateController, Icons.date_range),
            _buildTextField("No. of Devotees (Above 7 Yrs +)", _noOfDevoteesController, Icons.group, inputType: TextInputType.number),
            DropdownButtonFormField<String>(
              decoration: _buildInputDecoration("Type of Trip", Icons.directions),
              items: _tripTypes.map((String type) {
                return DropdownMenuItem<String>(
                  value: type,
                  child: Text(type),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedTripType = value;
                });
              },
              validator: (value) => value == null ? "Please select a trip type" : null,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitBookingForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  "Continue to Payment ${_totalPrice > 0 ? ' - ₹${_totalPrice}' : ''}",
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentStep() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          const Text("Select Payment Type", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ..._paymentOptions.map((option) {
            return RadioListTile<String>(
              title: Text(option),
              value: option,
              activeColor: themeColor,
              groupValue: _paymentType,
              onChanged: (value) {
                setState(() {
                  _paymentType = value;
                });
              },
            );
          }),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _submitPayment,
              style: ElevatedButton.styleFrom(
                backgroundColor: themeColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text("Complete Booking", style: TextStyle(color: Colors.white, fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSuccessStep() {
    return Column(
      children: [
        const Icon(Icons.check_circle, color: Colors.green, size: 80),
        const SizedBox(height: 10),
        const Text("Booking Successful!", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Text("Click below to view your confirmation", style: TextStyle(fontSize: 14)),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _goToThankYou,
            style: ElevatedButton.styleFrom(
              backgroundColor: themeColor,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text("Finish", style: TextStyle(color: Colors.white, fontSize: 16)),
          ),
        ),
      ],
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, IconData icon, {TextInputType inputType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: inputType,
        validator: (value) => value!.isEmpty ? "Please enter $label" : null,
        decoration: _buildInputDecoration(label, icon),
      ),
    );
  }

  Widget _buildDateField(String label, TextEditingController controller, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextFormField(
        controller: controller,
        decoration: _buildInputDecoration(label, icon),
        readOnly: true,
        onTap: () async {
          // Convert tripDuration to int
          int? durationDays = int.tryParse(widget.tripDuration);

          if (durationDays == null || durationDays <= 0) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Invalid trip duration")),
            );
            return;
          }

          DateTime? picked = await showDatePicker(
            context: context,
            firstDate: DateTime.now(),
            lastDate: DateTime(2100),
            initialDate: DateTime.now(),
          );

          if (picked != null) {
            if (durationDays == 1) {
              controller.text = "${picked.day}-${picked.month}-${picked.year}";
            } else {
              DateTime endDate = picked.add(Duration(days: durationDays - 1));
              controller.text =
              "${picked.day}-${picked.month}-${picked.year} to ${endDate.day}-${endDate.month}-${endDate.year}";
            }
          }
        },
        validator: (value) => value!.isEmpty ? "Please select $label" : null,
      ),
    );
  }

  InputDecoration _buildInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: themeColor),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
    );
  }
}
