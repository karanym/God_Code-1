import 'package:flutter/material.dart';
import 'api/api_service.dart';
import 'trip_detail_page.dart';
import 'api/trip_model.dart';
import 'package:intl/intl.dart';

class PopularTripsPage extends StatefulWidget {
  const PopularTripsPage({super.key});

  @override
  State<PopularTripsPage> createState() => _PopularTripsPageState();
}

class _PopularTripsPageState extends State<PopularTripsPage> {
  final TextEditingController searchController = TextEditingController();
  List<Map<String, dynamic>> trips = [];
  List<Map<String, dynamic>> filteredTrips = [];
  bool isLoading = true;
  bool hasError = false;
  bool showOnlyPopular = false;
  String selectedTripType = "All"; // ✅ Default filter for trip type

  final Color themeColor = const Color(0xFF6A1B9A); // ✅ Theme color

  @override
  void initState() {
    super.initState();
    loadTrips();
  }

  Future<void> loadTrips() async {
    try {
      ApiService apiService = ApiService();
      List<Trip> fetchedTrips = await apiService.fetchTrips();
      final currencyFormat = NumberFormat.currency(locale: "en_IN", symbol: "₹",decimalDigits: 0);
      setState(() {
        trips = fetchedTrips.map((trip) => {
          "id": trip.id,
          "title": trip.title ?? "Unknown",
          "image": trip.thumbnailImage ?? "https://example.com/default.jpg",
          "status": trip.status ?? "inactive",
          "type": trip.popularStatus ?? "no",
          "type_of_trip": trip.typeOfTrip ?? "Unknown", // ✅ Trip Type filter
          "price": trip.price != null ? currencyFormat.format(trip.price) : "N/A",
        }).toList();

        filterTrips(); // Apply filtering immediately
        isLoading = false;
      });
    } catch (e) {
      print("Error loading trips: $e");
      setState(() {
        hasError = true;
        isLoading = false;
      });
    }
  }

  void filterTrips() {
    setState(() {
      filteredTrips = trips.where((trip) {
        bool matchesTitle = trip["title"]
            .toLowerCase()
            .contains(searchController.text.toLowerCase());

        bool matchesPopular = !showOnlyPopular || trip["popular_status"] == "yes";

        bool matchesTripType = selectedTripTypes.isEmpty ||
            selectedTripTypes.any((type) =>
            trip["type_of_trip"].toLowerCase() == type.toLowerCase());

        return matchesTitle && matchesPopular && matchesTripType;
      }).toList();
    });
  }

  Set<String> selectedTripTypes = {}; // Store selected trip types
  void showFilterSheet() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setBottomSheetState) {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header Row with Title and Close Button
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.refresh, color: themeColor),
                        onPressed: () {
                          setBottomSheetState(() {
                            showOnlyPopular = false;
                            selectedTripTypes.clear(); // Clear multiple selections
                          });
                          setState(() {});
                        },
                      ),
                      const Text(
                        "Filters",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),

                  // Popular Toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Popular Trips", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      Switch(
                        value: showOnlyPopular,
                        onChanged: (value) {
                          setBottomSheetState(() => showOnlyPopular = value);
                          setState(() {});
                        },
                        activeColor: themeColor,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Multi-Select Trip Type Filter
                  Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Type of Trip", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 10, // Horizontal spacing
                    runSpacing: 10, // Vertical spacing between wrapped rows
                    children: ["Family Tour","Pilgrimage", "Adventure", "Heritage", "Wellness"].map((type) {
                      final isSelected = selectedTripTypes.contains(type);
                      return GestureDetector(
                        onTap: () {
                          setBottomSheetState(() {
                            if (isSelected) {
                              selectedTripTypes.remove(type); // Remove if already selected
                            } else {
                              selectedTripTypes.add(type); // Add if not selected
                            }
                          });
                          setState(() {}); // Update UI
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: isSelected ? themeColor : Colors.grey.shade400),
                            color: isSelected ? themeColor.withOpacity(0.2) : Colors.grey.shade300,
                          ),
                          child: Text(
                            type,
                            style: TextStyle(
                              color: isSelected ? themeColor : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  // Apply & Reset Buttons
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: themeColor),
                            minimumSize: const Size(double.infinity, 45),
                          ),
                          onPressed: () {
                            setBottomSheetState(() {
                              showOnlyPopular = false;
                              selectedTripTypes.clear(); // Reset multi-selection
                            });
                            setState(() {});
                          },
                          child: Text("Reset", style: TextStyle(color: themeColor, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: themeColor,
                            minimumSize: const Size(double.infinity, 45),
                          ),
                          onPressed: () {
                            filterTrips();
                            Navigator.pop(context);
                          },
                          child: const Text("Apply Filters", style: TextStyle(color: Colors.white)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("All Trips"),
        backgroundColor: themeColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            // Search Bar & Filters
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      hintText: "Search by title...",
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onChanged: (value) => filterTrips(),
                  ),
                ),
                const SizedBox(width: 10),

                // Filter Button
                IconButton(
                  icon: Icon(Icons.filter_list, color: Colors.white), // Keep icon color white
                  onPressed: showFilterSheet,
                  style: IconButton.styleFrom(
                    backgroundColor: (showOnlyPopular || selectedTripTypes.isNotEmpty)
                        ? themeColor // Change background when filters are active
                        : Colors.grey.shade300, // Default color
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            if (isLoading)
              const Center(child: CircularProgressIndicator())
            else if (hasError)
              const Center(child: Text("Failed to load trips. Try again later."))
            else if (filteredTrips.isEmpty)
                const Center(child: Text("No trips found."))
              else
                Expanded(
                  child: GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.50,
                    ),
                    itemCount: filteredTrips.length,
                    itemBuilder: (context, index) {
                      final trip = filteredTrips[index];
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TripDetailPage(tripId: trip["id"]),
                            ),
                          );
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Image Section (Occupies more space)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                trip["image"] ?? "https://example.com/default.jpg",
                                fit: BoxFit.cover,
                                width: double.infinity,
                                height: 120, // ✅ Set fixed height to avoid overflow
                                errorBuilder: (context, error, stackTrace) =>
                                    Image.asset("assets/images/placeholder.png", height: 120, fit: BoxFit.cover),
                              ),
                            ),
                            const SizedBox(height: 8),

                            // Text & Price Section
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                              decoration: BoxDecoration(
                                color:  Color(0xFFF5F5F5),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min, // ✅ Prevent extra space issues
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    trip["title"],
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: Color(0xFF333333),
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 4), // Add spacing
                                  Text(
                                    "${trip["price"]}", // ✅ Show price correctly formatted
                                    style: TextStyle(
                                      color: themeColor,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );

                    },
                  ),
                ),
          ],
        ),
      ),
    );
  }
}
