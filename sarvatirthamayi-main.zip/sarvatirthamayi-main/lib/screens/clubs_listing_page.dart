import 'package:flutter/material.dart';
import 'api/api_service.dart';
import 'api/clubs.dart';
import 'club_detail_page.dart';

class ClubListingPage extends StatefulWidget {
  @override
  _ClubListingPageState createState() => _ClubListingPageState();
}

class _ClubListingPageState extends State<ClubListingPage> {
  late ApiService apiService;
  late Future<List<Club>> clubsFuture;

  final Color themeColor = const Color(0xFF6A1B9A);

  @override
  void initState() {
    super.initState();
    apiService = ApiService();
    clubsFuture = apiService.fetchClubs();
  }

  String getSubscriptionLabel(String status) {
    switch (status) {
      case "subscribed":
        return "Subscribed";
      case "requested":
        return "Requested";
      case "not_subscribed":
        return "Not Subscribed";
      default:
        return "";
    }
  }

  Color getSubscriptionColor(String status) {
    switch (status) {
      case "subscribed":
        return Colors.green;
      case "requested":
        return Colors.orange;
      case "not_subscribed":
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  void showClubDetailsBottomSheet(BuildContext context, Club club) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[400],
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                club.name,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                club.clubTypeDisplay,
                style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
              ),
              const SizedBox(height: 12),
              const Divider(),
              const SizedBox(height: 8),
              Text(
                "Subscription Status: ${getSubscriptionLabel(club.subscriptionStatus)}",
                style: TextStyle(
                  color: getSubscriptionColor(club.subscriptionStatus),
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                "Expiry Status: ${club.expiryStatus ?? 'N/A'}",
                style: const TextStyle(fontSize: 13),
              ),
              const SizedBox(height: 6),
              Text(
                "Expiry Date: ${club.expiryDate ?? 'N/A'}",
                style: const TextStyle(fontSize: 13),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Text(
                    "Notification Enabled: ",
                    style: TextStyle(fontSize: 13),
                  ),
                  Text(
                    club.notification == true ? "Yes" : "No",
                    style: const TextStyle(fontSize: 13),
                  ),
                  const SizedBox(width: 6),
                  if (club.notification == true && (club.daysLeft != null && club.daysLeft! <= 30))
                    const BlinkingDot(),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                "Days Left: ${club.daysLeft != null ? club.daysLeft.toString() : 'N/A'} days",
                style: const TextStyle(fontSize: 13),
              ),
              const SizedBox(height: 16),

              /// Show Renew Button if expired
              if (club.expiryStatus == "expired")
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // Navigate to your payment page here
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ClubDetailPage(clubId: club.id), // or your payment page widget
                        ),
                      );
                    },
                    icon: const Icon(Icons.payment),
                    label: const Text("Renew Membership"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: themeColor,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: themeColor,
        title: const Text("Clubs"),
      ),
      body: FutureBuilder<List<Club>>(
        future: clubsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No clubs available"));
          }

          List<Club> clubs = snapshot.data!;

          return GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.74,
            ),
            itemCount: clubs.length,
            itemBuilder: (context, index) {
              Club club = clubs[index];

              return InkWell(
                onTap: () {
                  showClubDetailsBottomSheet(context, club);
                },
                borderRadius: BorderRadius.circular(12),
                child: Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                        child: club.imageUrl.isNotEmpty
                            ? Image.network(
                          club.imageUrl,
                          height: 90,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        )
                            : Container(
                          height: 90,
                          color: Colors.grey[300],
                          child: const Icon(Icons.image, size: 50, color: Colors.grey),
                        ),
                      ),
                      // Content section
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                children: [
                                  Text(
                                    club.name,
                                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    club.clubTypeDisplay,
                                    style: TextStyle(color: Colors.grey.shade700, fontSize: 11),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    "${club.formattedPrice}",
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: themeColor,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 6),
                                  if (club.subscriptionStatus != "not_subscribed")
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: getSubscriptionColor(club.subscriptionStatus),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            club.subscriptionStatus == "subscribed"
                                                ? Icons.check_circle
                                                : Icons.timelapse,
                                            size: 12,
                                            color: Colors.white,
                                          ),
                                          const SizedBox(width: 4),
                                          Text(
                                            getSubscriptionLabel(club.subscriptionStatus),
                                            style: const TextStyle(fontSize: 9, color: Colors.white),
                                          ),
                                        ],
                                      ),
                                    ),
                                ],
                              ),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => ClubDetailPage(clubId: club.id),
                                      ),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: themeColor,
                                    padding: const EdgeInsets.symmetric(vertical: 6),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: const Text(
                                    "Know More & Subscribe",
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// 🔴 Blinking red dot widget
class BlinkingDot extends StatefulWidget {
  const BlinkingDot({super.key});

  @override
  _BlinkingDotState createState() => _BlinkingDotState();
}

class _BlinkingDotState extends State<BlinkingDot> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat(reverse: true);
    _animation = Tween<double>(begin: 1.0, end: 0.0).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: Container(
        width: 10,
        height: 10,
        decoration: const BoxDecoration(
          color: Colors.red,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
