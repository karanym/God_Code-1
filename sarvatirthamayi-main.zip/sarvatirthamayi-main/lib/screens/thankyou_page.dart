import 'package:flutter/material.dart';
import 'package:sarvatirthamayi/main.dart';
import 'package:sarvatirthamayi/screens/home_page.dart';

class ThankYouPage extends StatelessWidget {
  final String name;
  final String mobile;
  final String email;
  final String tripTitle;
  final String imageUrl;
  final String startDate;
  final String noOfDays;
  final String noOfDevotees;
  final String tripType;
  final int tripPrice;
  final int totaltripPrice;

  const ThankYouPage({
    super.key,
    required this.name,
    required this.mobile,
    required this.email,
    required this.tripTitle,
    required this.imageUrl,
    required this.startDate,
    required this.noOfDays,
    required this.noOfDevotees,
    required this.tripType,
    required this.tripPrice,
    required this.totaltripPrice,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              "assets/images/event-banner.png",
              fit: BoxFit.cover,
            ),
          ),

          // Content Overlay
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.black.withOpacity(0.6), // Semi-transparent overlay
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Thank You Message
                const Text(
                  "🎉 Thank You for Booking! 🎉",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),

                const SizedBox(height: 20),

                // Trip Details Card
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          imageUrl,
                          height: 180,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        tripTitle,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Form-Filled Booking Details
                _buildDetailRow("🙍 Name", name),
                _buildDetailRow("📞 Mobile", mobile),
                _buildDetailRow("📧 Email", email),
                _buildDetailRow("📅 Start Date", startDate),
                _buildDetailRow("📆 No. of Days", noOfDays),
                _buildDetailRow("🧑‍🤝‍🧑 Devotees", noOfDevotees),
                _buildDetailRow("✈️ Trip Type", tripType),
                _buildDetailRow("💰 Price", "₹$tripPrice"),

                const SizedBox(height: 30),

                // Pay Now Button
                // SizedBox(
                //   width: double.infinity,
                //   child: ElevatedButton(
                //     onPressed: () {
                //       // Add your payment logic here
                //     },
                //     style: ElevatedButton.styleFrom(
                //       backgroundColor: MyApp.themeColor,
                //       padding: const EdgeInsets.symmetric(vertical: 16),
                //       shape: RoundedRectangleBorder(
                //         borderRadius: BorderRadius.circular(10),
                //       ),
                //     ),
                //     child: const Text(
                //       "💳 Proceed To Pay",
                //       style: TextStyle(
                //         color: Colors.white,
                //         fontSize: 18,
                //         fontWeight: FontWeight.bold,
                //       ),
                //     ),
                //   ),
                // ),

                const SizedBox(height: 15),

                // Back to Popular Trips Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const HomePage(),
                        ),
                            (route) => false,
                      );
                    },
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    label: const Text(
                      "Back to Home",
                      style: TextStyle(color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Helper Widget to Display Booking Details
  Widget _buildDetailRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }
}
