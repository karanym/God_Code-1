import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'api/api_service.dart';
import 'package:sarvatirthamayi/widgets/html_parser_widget.dart';

class RitualsListingPage extends StatefulWidget {
  final int templeId;
  final String templeTitle;
  final String templeIcon;

  const RitualsListingPage({
    super.key,
    required this.templeId,
    required this.templeTitle,
    required this.templeIcon,
  });

  @override
  State<RitualsListingPage> createState() => _RitualsListingPageState();
}

class _RitualsListingPageState extends State<RitualsListingPage> {
  List<dynamic>? rituals;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchRituals();
  }

  Future<void> fetchRituals() async {
    final data = await ApiService().fetchRitualsApi(widget.templeId);
    setState(() {
      rituals = data ?? [];
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.templeTitle} - Rituals"),
        backgroundColor: const Color(0xFF6A1B9A),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : rituals == null || rituals!.isEmpty
          ? const Center(child: Text("No rituals found"))
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: rituals!.length,
        itemBuilder: (context, index) {
          final ritual = rituals![index];
          final ritualImages = ritual['ritual_images'] ?? [];

          return Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    ritual['ritual_label_details']?['title'] ?? "Unknown Ritual",
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Price: ₹${ritual['ritual_price'] ?? '0.00'}",
                    style: const TextStyle(color: Colors.black54),
                  ),
                  const SizedBox(height: 10),
                  if (ritualImages.isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: CarouselSlider(
                        options: CarouselOptions(
                          height: 180,
                          enlargeCenterPage: true,
                          autoPlay: true,
                          viewportFraction: 0.8,
                        ),
                        items: ritualImages.map<Widget>((img) {
                          return Image.network(
                            img['ritual_image'] ?? 'https://via.placeholder.com/200',
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (context, error, stackTrace) =>
                            const Icon(Icons.broken_image, size: 180),
                          );
                        }).toList(),
                      ),
                    ),
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () => _showRitualDetailsSheet(context, ritual),
                      child: const Text(
                        "More Details",
                        style: TextStyle(
                            color: Color(0xFF6A1B9A),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showRitualDetailsSheet(BuildContext context, Map ritual) {
    List<String> ritualDays = [];
    if (ritual['ritual_days'] != null && ritual['ritual_days'].toString().isNotEmpty) {
      try {
        ritualDays = List<String>.from(json.decode(ritual['ritual_days'].replaceAll("'", "\"")));
      } catch (e) {
        print("Error decoding ritual_days: $e");
      }
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      backgroundColor: Colors.white,
      builder: (context) {
        return SizedBox(
          height: MediaQuery.of(context).size.height * 0.85,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      icon: const Icon(Icons.close, size: 28),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  Text(
                    ritual['ritual_label_details']?['title'] ?? "Unknown Ritual",
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  const SizedBox(height: 10),
                  _infoRow("Temple", ritual['temple_details']?['temple_name'] ?? 'N/A'),
                  _infoRow("Ritual Type", ritual['ritual_type'] ?? 'N/A'),
                  _infoRow("Category", ritual['ritual_category'] ?? 'N/A'),
                  _infoRow("Duration", ritual['ritual_duration'] ?? 'N/A'),
                  _infoRow("Perform Time", ritual['ritual_perform_time'] ?? 'Not specified'),
                  if (ritualDays.isNotEmpty) _infoRow("Perform Days", ritualDays.join(", ")),
                  if (ritual['ritual_benefits'] != null)
                    _infoSection("Benefits", HtmlTextWidget(htmlText: ritual['ritual_benefits'] ?? "")),
                  if (ritual['ritual_procedure'] != null)
                    _infoSection("Procedure", HtmlTextWidget(htmlText: ritual['ritual_procedure'] ?? "")),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 120, child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: Text(value, style: const TextStyle(color: Colors.black54))),
        ],
      ),
    );
  }

  Widget _infoSection(String title, Widget content) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), content],
      ),
    );
  }
}
