import 'package:flutter/material.dart';
import 'package:sarvatirthamayi/main.dart';
import 'api/api_service.dart';
import 'api/club_model.dart';
import 'club_subscription_page.dart';
import 'club_subscription_renew_page.dart';
import 'login.dart';

class ClubDetailPage extends StatefulWidget {
  final int clubId;

  const ClubDetailPage({Key? key, required this.clubId}) : super(key: key);

  @override
  _ClubDetailPageState createState() => _ClubDetailPageState();
}

class _ClubDetailPageState extends State<ClubDetailPage> {
  Club? club;
  bool isLoading = true;
  Map<String, dynamic>? subscription;
  bool isSubDetailsOpen = true;

  @override
  void initState() {
    super.initState();
    _fetchClubDetails();
  }

  void _fetchClubDetails() async {
    final data = await ApiService().fetchClubDetails(widget.clubId);
    if (data != null && data['status'] == 'success') {
      setState(() {
        club = Club.fromJson(data['club']);
        subscription = data['subscription'];
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  Widget _subscriptionDetails() {
    if (subscription == null) return const SizedBox();

    if (subscription!['status'] != 'subscribed') {
      return const SizedBox();
    }

    return Container(
      margin: const EdgeInsets.only(top: 16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        children: [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            title: const Text(
              "Your Subscription Details",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            trailing: IconButton(
              icon: Icon(
                isSubDetailsOpen ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                color: MyApp.themeColor,
              ),
              onPressed: () {
                setState(() {
                  isSubDetailsOpen = !isSubDetailsOpen;
                });
              },
            ),
          ),
          if (isSubDetailsOpen)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _infoRow("Status:", subscription!['status'] ?? "-",
                      color: Colors.green),
                  _infoRow("Joined Date:", subscription!['joined_date'] ?? "-"),
                  _infoRow("Expiry Date:", subscription!['expiry_date'] ?? "-"),
                  _infoRow("Left Days:", "${subscription!['left_days'] ?? '-'} days"),
                  _infoRow("Expiry Status:", subscription!['expiry_status'] ?? "-",
                      color: subscription!['expiry_status'] == 'expired'
                          ? Colors.red
                          : Colors.green),
                  const SizedBox(height: 8),
                ],
              ),
            ),
        ],
      ),
    );
  }


  Widget _infoRow(String label, String value, {Color color = Colors.black87}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Club Details"),
        backgroundColor: MyApp.themeColor,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : club == null
          ? const Center(child: Text("Error loading data"))
          : SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 80),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Club Image
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(
                club!.imageUrl,
                width: double.infinity,
                height: 200,
                fit: BoxFit.cover,
              ),
            ),

            // Club Info
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    club!.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    club!.clubType,
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    club!.formattedPrice,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: MyApp.themeColor,
                    ),
                  ),
                  // 🔽 Subscription details AFTER price section
                  _subscriptionDetails(),
                  const SizedBox(height: 10),
                  Text(
                    club!.description,
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      // Bottom Subscribe Button
      bottomNavigationBar: club != null
          ? Container(
        padding: const EdgeInsets.all(12),
        decoration: const BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black26, blurRadius: 8, spreadRadius: 2),
          ],
        ),
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton(
              onPressed: () async {
                final token = await ApiService().getToken();
                if (token == null) {
                  // Show login dialog
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text('Login Required'),
                        content: const Text('You need to login to continue.'),
                        actions: [
                          TextButton(
                            child: const Text('Cancel'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          TextButton(
                            child: const Text(
                              'Login',
                              style: TextStyle(color: MyApp.themeColor),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => LoginScreen(),
                                ),
                              );
                            },
                          ),
                        ],
                      );
                    },
                  );
                } else {
                  // Navigate based on expiry status
                  if (subscription != null && subscription!['expiry_status'] == 'expired') {
                    // Navigate to Renewal Page
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SubscriptionRenewalPage(club: club!),
                      ),
                    );
                  } else {
                    // Navigate to normal Subscription Page
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SubscriptionPage(club: club!),
                      ),
                    );
                  }
                }
              },

            style: ElevatedButton.styleFrom(
              backgroundColor: MyApp.themeColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              padding: const EdgeInsets.symmetric(vertical: 15),
            ),
            child: Text(
              (subscription != null && subscription!['expiry_status'] == 'expired')
                  ? "Renew"
                  : "Subscribe Now",
              style: const TextStyle(fontSize: 18, color: Colors.white),
            ),
          ),
        ),
      )
          : null,
    );
  }
}
