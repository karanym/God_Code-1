import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'api/api_service.dart';
import 'home_page.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> userProfile = {};
  bool isLoading = true;
  File? _image;
  final picker = ImagePicker();

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController cityController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  Future<void> fetchProfile() async {
    setState(() => isLoading = true);
    try {
      var response = await ApiService().fetchProfile();
      if (response != null) {
        setState(() {
          userProfile = response;
          nameController.text = response['name'] ?? '';
          emailController.text = response['email'] ?? '';
          cityController.text = response['city'] ?? '';
        });
      }
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> updateProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() => isLoading = true);
      try {
        var data = {
          'name': nameController.text.trim(),
          'email': emailController.text.trim(),
          'city': cityController.text.trim(),
        };
        var response = await ApiService().updateProfile(data);
        if (response != null) {
          setState(() {
            userProfile = response;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profile Updated Successfully')),
          );
        }
      } finally {
        setState(() => isLoading = false);
      }
    }
  }


  Future<void> updateProfileImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      _image = File(pickedFile.path);
      setState(() {});
      await ApiService().uploadImage('api/profile/update-image/', _image!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : GestureDetector(
        onTap: () async {
          FocusScope.of(context).unfocus();
          await updateProfile();
        },
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Increased Banner Height to 250
              Stack(
                children: [
                  Image.asset('assets/images/banner-right.png',
                      width: double.infinity,
                      height: 250,
                      fit: BoxFit.cover),
                  Positioned(
                    top: 40,
                    left: 16,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back,
                          color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  Positioned(
                    top: 40,
                    right: 16,
                    child: IconButton(
                      icon: const Icon(Icons.home, color: Colors.white),
                      onPressed: () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => HomePage()),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // Profile Image
              GestureDetector(
                onTap: updateProfileImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.grey[300],
                  child: ClipOval(
                    child: _image != null
                        ? Image.file(_image!,
                        width: 100, height: 100, fit: BoxFit.cover)
                        : (userProfile['profile'] != null
                        ? Image.network(userProfile['profile'],
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover)
                        : Image.asset('assets/images/default.jpg',
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover)),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Form
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _buildTextField(
                          'Name', nameController, Icons.person),
                      _buildTextField(
                          'Email', emailController, Icons.email),
                      _buildTextField(
                          'City', cityController, Icons.location_city),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: updateProfile,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFF6A1B9A),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)),
                            padding:
                            const EdgeInsets.symmetric(vertical: 15),
                          ),
                          child: const Text('Update Profile',
                              style: TextStyle(fontSize: 16)),
                        ),
                      ),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      String label, TextEditingController controller, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Focus(
        onFocusChange: (hasFocus) async {
          if (!hasFocus) {
            await updateProfile();
          }
        },
        child: TextFormField(
          controller: controller,
          validator: (value) =>
          value == null || value.trim().isEmpty ? 'Please enter $label' : null,
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon, color: Color(0xFF6A1B9A)),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
              borderSide: const BorderSide(color: Color(0xFF6A1B9A), width: 2),
            ),
            filled: true,
            fillColor: Colors.white,
          ),
        ),
      ),
    );
  }
}
