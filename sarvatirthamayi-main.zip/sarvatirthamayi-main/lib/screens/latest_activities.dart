import 'package:flutter/material.dart';
import 'api/api_service.dart'; // Adjust the path as needed

class LatestActivities extends StatefulWidget {
  const LatestActivities({super.key});

  @override
  _LatestActivitiesState createState() => _LatestActivitiesState();
}

class _LatestActivitiesState extends State<LatestActivities> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  List<dynamic> latestActivities = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchLatestActivities();
  }

  Future<void> _fetchLatestActivities() async {
    try {
      final homeData = await ApiService().fetchHomePageData();
      setState(() {
        latestActivities = List<dynamic>.from(homeData['latest_activities'] ?? []);
        isLoading = false;
      });
    } catch (e) {
      print("Error fetching latest activities: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  void _goToPrevious() {
    if (_currentPage > 0) {
      _pageController.previousPage(
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  void _goToNext() {
    if (_currentPage < latestActivities.length - 1) {
      _pageController.nextPage(
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? Center(child: CircularProgressIndicator()) // Show loader while fetching data
        : latestActivities.isEmpty
        ? Center(child: Text("No latest activities available"))
        : Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          height: 250,
          child: PageView.builder(
            controller: _pageController,
            itemCount: latestActivities.length,
            onPageChanged: (index) {
              setState(() {
                _currentPage = index;
              });
            },
            itemBuilder: (context, index) {
              final activity = latestActivities[index];
              final imageUrl = activity['image'] ?? "";
              final title = activity['title'] ?? "No Title";

              return Stack(
                children: [
                  // Background Image
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: imageUrl.isNotEmpty
                        ? Image.network(
                      "$imageUrl",
                      width: double.infinity,
                      height: 250,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          Image.asset("assets/images/placeholder.jpg",
                              width: double.infinity, height: 250, fit: BoxFit.cover),
                    )
                        : Image.asset(
                      "assets/images/placeholder.jpg",
                      width: double.infinity,
                      height: 250,
                      fit: BoxFit.cover,
                    ),
                  ),

                  // Bottom Gradient Background
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 80,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(12),
                          bottomRight: Radius.circular(12),
                        ),
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            Colors.black.withOpacity(0.7),
                            Colors.black.withOpacity(0.0),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Title
                  Positioned(
                    bottom: 20,
                    left: 0,
                    right: 0,
                    child: Text(
                      title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(
                            color: Colors.black38,
                            blurRadius: 4,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),

        // Left Arrow (Hidden on first page)
        if (_currentPage > 0)
          Positioned(
            left: 10,
            child: GestureDetector(
              onTap: _goToPrevious,
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black.withOpacity(0.5),
                ),
                padding: const EdgeInsets.all(8),
                child: const Icon(Icons.chevron_left, color: Colors.white, size: 32),
              ),
            ),
          ),

        // Right Arrow (Hidden on last page)
        if (_currentPage < latestActivities.length - 1)
          Positioned(
            right: 10,
            child: GestureDetector(
              onTap: _goToNext,
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black.withOpacity(0.5),
                ),
                padding: const EdgeInsets.all(8),
                child: const Icon(Icons.chevron_right, color: Colors.white, size: 32),
              ),
            ),
          ),
      ],
    );
  }
}
