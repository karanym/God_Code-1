import 'package:flutter/material.dart';
import 'api/api_service.dart';
import 'temple_details_page.dart';

class TempleListingPage extends StatefulWidget {
  const TempleListingPage({super.key});

  @override
  State<TempleListingPage> createState() => _TempleListingPageState();
}

class _TempleListingPageState extends State<TempleListingPage> {
  final ApiService apiService = ApiService();
  final TextEditingController searchController = TextEditingController();

  bool isLoading = true;
  List<Map<String, dynamic>> temples = [];
  List<Map<String, dynamic>> filteredTemples = [];

  String? selectedState;
  String? selectedTempleType;
  String? selectedDeity;

  final List<String> states = ["Andhra Pradesh", "Tamil Nadu", "Uttar Pradesh"];
  final List<String> templeTypes = ["Shiva Temple", "Vishnu Temple", "Devi Temple"];
  final List<String> deities = ["Shiva", "Vishnu", "Durga", "Ganesh"];

  @override
  void initState() {
    super.initState();
    fetchTemples();
  }

  Future<void> fetchTemples() async {
    final fetchedTemples = await apiService.fetchTemples();
    setState(() {
      temples = fetchedTemples;
      filteredTemples = List.from(fetchedTemples);
      isLoading = false;
    });
  }

  void applyFilters() {
    setState(() {
      filteredTemples = temples.where((temple) {
        final nameMatch = temple["temple_name"].toLowerCase().contains(searchController.text.toLowerCase());
        final stateMatch = selectedState == null || temple["state"] == selectedState;
        final typeMatch = selectedTempleType == null || temple["temple_type"] == selectedTempleType;
        final deityMatch = selectedDeity == null || temple["deity"] == selectedDeity;
        return nameMatch && stateMatch && typeMatch && deityMatch;
      }).toList();
    });
    Navigator.pop(context); // Close bottom sheet after applying filters
  }

  void resetFilters() {
    setState(() {
      searchController.clear();
      selectedState = null;
      selectedTempleType = null;
      selectedDeity = null;
      filteredTemples = List.from(temples);
    });
  }

  void showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 15),

            const Center(child: Text("Filter Temples", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),

            const SizedBox(height: 20),
            _buildDropdown("State", selectedState, states, (val) => setState(() => selectedState = val)),

            const SizedBox(height: 16),
            _buildDropdown("Temple Type", selectedTempleType, templeTypes, (val) => setState(() => selectedTempleType = val)),

            const SizedBox(height: 16),
            _buildDropdown("Deity", selectedDeity, deities, (val) => setState(() => selectedDeity = val)),

            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: resetFilters,
                  icon: const Icon(Icons.refresh, color: Colors.white),
                  label: const Text("Reset", style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[700],
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: applyFilters,
                  icon: const Icon(Icons.check, color: Colors.white),
                  label: const Text("Apply", style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6A1B9A),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Temples"), backgroundColor: const Color(0xFF6A1B9A)),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      hintText: "Search Temples...",
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onChanged: (value) => applyFilters(),
                  ),
                ),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.filter_list, color: Colors.white),
                  onPressed: showFilterBottomSheet,
                  color: const Color(0xFF6A1B9A),
                  style: IconButton.styleFrom(backgroundColor: const Color(0xFF6A1B9A)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : GridView.builder(
                padding: const EdgeInsets.all(8),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.8,
                ),
                itemCount: filteredTemples.length,
                itemBuilder: (context, index) {
                  final temple = filteredTemples[index];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TempleDetailsPage(
                            templeId: temple['id'],
                          ),
                        ),
                      );
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Increased image height automatically
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.network(
                              temple['icon_image'] ?? 'https://via.placeholder.com/150',
                              fit: BoxFit.cover,
                              width: double.infinity,
                              errorBuilder: (context, error, stackTrace) => const Icon(Icons.image, size: 50),
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        // Full-width background text box
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          decoration: BoxDecoration(
                            color: Color(0xFFF5F5F5), // Light background
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(
                            child: Text(
                              temple['title'] ?? '',
                              textAlign: TextAlign.center,
                              maxLines: 2, // Supports multi-line text
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 16, // Slightly larger font
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF333333), // Dark text
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );

                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(String label, String? selectedValue, List<String> options, Function(String?) onChanged) {
    return DropdownButtonFormField<String>(
      value: selectedValue,
      decoration: InputDecoration(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.white,
      ),
      items: options.map((val) {
        return DropdownMenuItem(
          value: val,
          child: Text(val, style: TextStyle(color: selectedValue == val ? const Color(0xFF6A1B9A) : Colors.black)),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }
}
