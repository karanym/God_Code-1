import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'latest_activities.dart';
import 'popular_trips.dart';
import 'temples.dart';
import 'clubs_listing_page.dart';
import 'rituals_page.dart';
import 'profile_page.dart';
import 'login.dart';
import 'my_trips_page.dart';
import 'api/api_service.dart'; // Import your API service

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const Color themeColor = Color(0xFF6A1B9A);
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  bool isLoggedIn = false;
  final ApiService apiService = ApiService();
  String? userName;
  int? _selectedIndex;

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  Future<void> _checkLoginStatus() async {
    String? token = await _secureStorage.read(key: 'auth_token');
    String? storedUserName = await _secureStorage.read(key: 'user_name');

    setState(() {
      isLoggedIn = token != null;
      userName = storedUserName;
    });
  }

  Future<void> _handleLogout(BuildContext context) async {
    bool confirmLogout = await _showLogoutConfirmationDialog(context);
    if (!confirmLogout) return;

    bool success = await apiService.logout();
    if (success) {
      await _secureStorage.delete(key: "auth_token"); // Clear token
      await _secureStorage.delete(key: "user_name"); // Clear token
      await _secureStorage.delete(key: "user_mobile"); // Clear token
      await _secureStorage.delete(key: "user_email"); // Clear token
      if (mounted) {
        Navigator.of(context).pop(); // Close drawer
        Future.delayed(const Duration(milliseconds: 300), () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Logged out successfully")),
          );
        });
      }
      _checkLoginStatus(); // Refresh UI
    } else {
      if (mounted) {
        Future.delayed(const Duration(milliseconds: 300), () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Logout failed. Try again!")),
          );
        });
      }
    }
  }

  Future<bool> _showLogoutConfirmationDialog(BuildContext context) async {
    return await showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text("Confirm Logout"),
          content: const Text("Are you sure you want to log out?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text("Yes"),
            ),
          ],
        );
      },
    ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildDrawer(context),
      appBar: AppBar(
        title: Text(isLoggedIn && userName != null ? "Hello, $userName" : "SARVATIRTHAMAYI"),
        backgroundColor: themeColor,
        centerTitle: true,
        actions: [
          if (!isLoggedIn)
            IconButton(
              icon: const Icon(Icons.login, color: Colors.white),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                ).then((_) => _checkLoginStatus()); // Refresh after login
              },
            ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Welcome to Divine Temple",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: themeColor),
              ),
              const SizedBox(height: 10),
              const Text(
                "Sarvatirthamayi is a Temples & Sanatan Dharma App designed to enrich your spiritual journey",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              const SizedBox(height: 20),
              SizedBox(
                height: 100,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _buildFeatureBox(Icons.card_travel, "My Trips", () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => MyTripsPage()));
                    }),
                    _buildFeatureBox(Icons.auto_awesome, "Rituals", () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => RitualsPage()));
                    }),
                    _buildFeatureBox(Icons.temple_hindu, "Temples", () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => TempleListingPage()));
                    }),
                    _buildFeatureBox(Icons.groups, "Clubs", () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ClubListingPage()));
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Center(
                child: Text(
                  "Latest Activities",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: themeColor),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(height: 250, child: LatestActivities()),
              const SizedBox(height: 20),
              SizedBox(height: 300, child: PopularTrips()),
              const SizedBox(height: 30),

              GestureDetector(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => TempleListingPage()));
                },
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.asset(
                        'assets/images/ritual-banner.png', // Add your banner image here
                        width: double.infinity,
                        height: 150,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      height: 150,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.black.withOpacity(0.4), // dark overlay for text visibility
                      ),
                    ),
                    Positioned.fill(
                      child: Center(
                        child: Text(
                          "Explore All Temples",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                offset: Offset(0, 1),
                                blurRadius: 5,
                                color: Colors.black54,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildFooterMenu(),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: Colors.white),
            child: Center(
              child: Image.asset(
                'assets/images/logo.jpeg',
                width: 200,
                height: 200,
                fit: BoxFit.contain,
              ),
            ),
          ),
          _buildDrawerItem(Icons.card_travel, 'My Trips', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => MyTripsPage()));
          }),
          _buildDrawerItem(Icons.auto_awesome, 'Rituals', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) =>RitualsPage()));
          }),
          _buildDrawerItem(Icons.temple_hindu, 'Temples', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => TempleListingPage()));
          }),
          _buildDrawerItem(Icons.groups, 'Clubs', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => ClubListingPage()));
          }),
          const Spacer(),
          if (isLoggedIn)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
                icon: const Icon(Icons.logout, color: Colors.white),
                label: const Text(
                  "Logout",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
                onPressed: () => _handleLogout(context),
              ),
            ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: themeColor),
      title: Text(
        title,
        style: const TextStyle(
          color: themeColor,
          fontWeight: FontWeight.bold,
        ),
      ),
      onTap: onTap,
    );
  }

  Widget _buildFeatureBox(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: themeColor.withOpacity(0.6), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 32, color: themeColor),
            const SizedBox(height: 6),
            Text(
              title,
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: themeColor
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }


  Widget _buildFooterMenu() {
    return BottomNavigationBar(
      currentIndex: _selectedIndex ?? 0,
      selectedItemColor: themeColor,
      unselectedItemColor: Colors.black54,
      showSelectedLabels: true, // Show labels for selected items
      showUnselectedLabels: true, // Show labels for unselected items
      onTap: (index) {
        if (index == _selectedIndex) return; // Prevent unnecessary navigation

        setState(() {
          _selectedIndex = index == 0 ? null : index; // Set null for home page
        });

        switch (index) {
          case 0:
          // Stay on Home Page
            break;
          case 1:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ClubListingPage()),
            );
            break;
          case 2:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TempleListingPage()),
            );
            break;
          case 3:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RitualsPage()),
            );
            break;
          case 4:
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ProfilePage()),
            );
            break;
          default:
            setState(() {
              _selectedIndex = null; // No selection when on Home
            });
        }
      },
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.groups), label: "Clubs"),
        BottomNavigationBarItem(icon: Icon(Icons.temple_hindu), label: "Temples"),
        BottomNavigationBarItem(icon: Icon(Icons.auto_awesome), label: "Rituals"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }


}
