import 'package:flutter/material.dart';
import 'api/api_service.dart';
import 'trip_booking_page.dart';
import 'login.dart';

class TripDetailPage extends StatefulWidget {
  final int tripId;

  const TripDetailPage({super.key, required this.tripId});

  @override
  _TripDetailPageState createState() => _TripDetailPageState();
}

class _TripDetailPageState extends State<TripDetailPage> {
  final ApiService apiService = ApiService();
  Map<String, dynamic>? tripDetails;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTripDetails();
  }

  Future<void> fetchTripDetails() async {
    try {
      final response = await apiService.fetchTripDetails(widget.tripId);
      setState(() {
        tripDetails = response;
        isLoading = false;
      });
    } catch (e) {
      print("Error fetching trip details: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : tripDetails == null
          ? const Center(child: Text("Trip details not found"))
          : Stack(
        children: [
          Column(
            children: [
              _buildBannerSection(),
              _buildContentSection(),
            ],
          ),
          _buildBookNowButton(),
        ],
      ),
    );
  }

  Widget _buildBannerSection() {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(20),
            bottomRight: Radius.circular(20),
          ),
          child: Image.network(
            tripDetails!["banner_image"] ?? '',
            fit: BoxFit.cover,
            width: double.infinity,
            height: 250,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                width: double.infinity,
                height: 250,
                color: Colors.grey[300],
                child: const Icon(Icons.image, size: 50, color: Colors.grey),
              );
            },
          ),
        ),
        Positioned(
          bottom: 15,
          left: 20,
          right: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              tripDetails!["image_caption"] ?? "",
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        Positioned(
          top: 40,
          left: 10,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContentSection() {
    return Expanded(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tripDetails!["trip_title"] ?? "Trip Title",
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              tripDetails!["short_description"] ?? "No description available",
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 15),
            _buildPriceCard(),
            const SizedBox(height: 20),
            _buildDetailRow("Duration:", "${tripDetails!["trip_duration"]} day(s)"),
            _buildDetailRow("Temples Covered:", "${tripDetails!["no_of_temples"]} temple(s)"),
            if (tripDetails!["temple_names"] != null && tripDetails!["temple_names"].isNotEmpty)
              _buildDetailRow("Temple Names:", tripDetails!["temple_names"].join(", ")),
            _buildDetailRow("Assembly Point:", tripDetails!["trip_assembly_point"] ?? "N/A"),
            _buildDetailRow("Group Size:", "Min ${tripDetails!["min_group_size"]}, Max ${tripDetails!["max_group_size"]}"),
            const SizedBox(height: 10),
            const Text(
              "Trip Description:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(tripDetails!["trip_description"] ?? "No description available"),
            const SizedBox(height: 15),
            const Text(
              "Facilities Covered:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(tripDetails!["facilities_covered"] ?? "Not specified"),
            const SizedBox(height: 20),
            const Text(
              "Trip Highlights:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (tripDetails!["item_list"] != null &&
                tripDetails!["item_list"].isNotEmpty)
              ...tripDetails!["item_list"].map<Widget>((item) {
                return _buildItem(
                  item["list_title"] ?? "No Title",
                  item["list_description"] ?? "No Description",
                );
              }).toList()
            else
              const Text("No highlights available."),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 16, color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildPriceCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "Price:",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            "₹${tripDetails!["price"] ?? "N/A"}",
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF6A1B9A),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBookNowButton() {
    return Positioned(
      bottom: 30,
      left: 20,
      right: 20,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF6A1B9A),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        onPressed: () async {
          final token = await apiService.getToken();
          if (token == null) {
            _showLoginPrompt(context);
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => TripBookingPage(
                  tripId: widget.tripId,
                  tripTitle: tripDetails!["trip_title"],
                  imageUrl: tripDetails!["banner_image"],
                  tripPrice: tripDetails!["price"],
                  tripDuration: tripDetails!["trip_duration"],

                ),
              ),
            );
          }
        },
        child: const Text(
          "Book Now",
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
      ),
    );
  }

  void _showLoginPrompt(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Login Required"),
        content: const Text("Please login to continue booking."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const LoginScreen(),
                ),
              );
            },
            child: const Text("Login"),
          ),
        ],
      ),
    );
  }

  Widget _buildItem(String title, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.star, color: Colors.orange, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Text(
                  description,
                  style: const TextStyle(fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
