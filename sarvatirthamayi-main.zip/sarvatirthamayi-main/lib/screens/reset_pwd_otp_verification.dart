import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'reset_password.dart';
import '/widgets/curved_button.dart';

class ResetOTPVerificationScreen extends StatefulWidget {
  final String mobile;
  final String otp;

  const ResetOTPVerificationScreen({super.key, required this.mobile, required this.otp});
  // Getter for mobile
  String get getMobile => mobile;
  @override
  _ResetOTPVerificationScreenState createState() => _ResetOTPVerificationScreenState();
}

class _ResetOTPVerificationScreenState extends State<ResetOTPVerificationScreen> {
  final Color themeColor = const Color(0xFF6A1B9A);
  final List<TextEditingController> otpControllers =
  List.generate(6, (index) => TextEditingController());
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // Pre-fill OTP from widget.otp if available
    for (int i = 0; i < widget.otp.length && i < 6; i++) {
      otpControllers[i].text = widget.otp[i];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Top Banner Section
          Expanded(
            flex: 4,
            child: Stack(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Image.asset("assets/images/banner-right.png", fit: BoxFit.cover),
                ),
                Positioned(
                  top: 40,
                  left: 10,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                Positioned(
                  top: 40,
                  right: 20,
                  child: IconButton(
                    icon: const Icon(Icons.home, color: Colors.white, size: 28),
                    onPressed: () {
                      Navigator.popUntil(context, (route) => route.isFirst);
                    },
                  ),
                ),
              ],
            ),
          ),

          // OTP Form Section
          Expanded(
            flex: 6,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo
                  Image.asset("assets/images/logo.jpeg", height: 80),
                  const SizedBox(height: 15),

                  // OTP Title
                  const Text(
                    "Verify OTP",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  Text(
                    "OTP sent to ${widget.mobile}",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black54,
                    ),
                  ),

                  const SizedBox(height: 20),

                  // OTP Input Fields
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(6, (index) => _otpBox(index)),
                  ),

                  const SizedBox(height: 25),

                  // Verify OTP Button
                  isLoading
                      ? const CircularProgressIndicator()
                      : CurvedButton(
                    text: "Verify OTP",
                    color: themeColor,
                    onPressed: verifyOtpHandler,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // OTP Box Widget
  Widget _otpBox(int index) {
    return Container(
      width: 40,
      height: 50,
      margin: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: themeColor, width: 2),
      ),
      child: TextField(
        controller: otpControllers[index],
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        maxLength: 1,
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        decoration: const InputDecoration(
          counterText: "",
          border: InputBorder.none,
        ),
        onChanged: (value) {
          if (value.isNotEmpty && index < 5) {
            FocusScope.of(context).nextFocus();
          }
        },
      ),
    );
  }

  // API Call Handler
  void verifyOtpHandler() async {
    String otp = otpControllers.map((controller) => controller.text).join();
    if (otp.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Enter a valid 6-digit OTP")),
      );
      return;
    }

    setState(() => isLoading = true);

    final success = await verifyOtpResetPassword(widget.mobile, otp);

    setState(() => isLoading = false);

    if (success) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ResetPasswordScreen(mobile: widget.mobile),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Invalid OTP or verification failed")),
      );
    }
  }
  String authToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6InNhcnZhdGlydGhhbWF5aUBtYWlsaW5hdG9yLmNvbSIsImV4cCI6NDg5MzMyNDQyMywiZW1haWwiOiJzYXJ2YXRpcnRoYW1heWlAbWFpbGluYXRvci5jb20ifQ.y-IM2sin3OWbhYzrBH8P7xhpyguEtYjljnR7yQzZkKU"; // Store token dynamically

  // Set Token Method
  void setToken(String token) {
    authToken = token;
  }
  // API Function
  Future<bool> verifyOtpResetPassword(String mobile, String otp) async {
    final url = Uri.parse('http://10.0.2.2:8000/api/verify-otp-reset-password/');
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json","Authorization": "Bearer $authToken"},
        body: jsonEncode({"mobile": mobile, "otp": otp}),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      debugPrint("API Error: $e");
      return false;
    }
  }
}
