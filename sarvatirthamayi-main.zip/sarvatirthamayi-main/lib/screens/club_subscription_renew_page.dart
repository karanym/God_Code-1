import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sarvatirthamayi/main.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api/api_service.dart';
import 'api/club_model.dart';
import 'club_thank_you_page.dart';

class SubscriptionRenewalPage extends StatefulWidget {
  final Club club;

  const SubscriptionRenewalPage({Key? key, required this.club}) : super(key: key);

  @override
  _SubscriptionRenewalPageState createState() => _SubscriptionRenewalPageState();
}

class _SubscriptionRenewalPageState extends State<SubscriptionRenewalPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  int _currentStep = 0;
  bool isSubmitting = false;

  final _secureStorage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    String? name = await _secureStorage.read(key: 'user_name');
    String? email = await _secureStorage.read(key: 'user_email');
    String? phone = await _secureStorage.read(key: 'user_mobile');

    setState(() {
      _nameController.text = name ?? '';
      _emailController.text = email ?? '';
      _phoneController.text = phone ?? '';
    });
  }

  void _nextStep() {
    if (_currentStep < 2) {
      setState(() {
        _currentStep++;
      });
    }
  }

  void _previousStep() {
    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
      });
    }
  }

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isSubmitting = true;
      });

      String currentDate = DateFormat("yyyy-MM-dd").format(DateTime.now());

      Map<String, dynamic> requestData = {
        "name": _nameController.text,
        "phone": _phoneController.text,
        "email": _emailController.text,
        "joined_date": currentDate,
        "club": widget.club.id,
        "price": widget.club.price,
        "status": "active",
        "renewal":1
      };

      bool success = await ApiService().submitSubscription(requestData);

      setState(() {
        isSubmitting = false;
      });

      if (success) {
        _nextStep();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to subscribe. Try again.")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Renew Subscription to Club"),
        backgroundColor: MyApp.themeColor,
      ),
      body: Column(
        children: [
          _buildStepperSection(),
          _buildDividerSection(),
          Expanded(
            child: _buildStepContentContainer(),
          ),
        ],
      ),
    );
  }

  Widget _buildStepperSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.white,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(16),
        ),
        child: _buildProgressIndicator(),
      ),
    );
  }

  Widget _buildDividerSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: Divider(
              color: MyApp.themeColor,
              thickness: 1.5,
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              "Membership Form",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: MyApp.themeColor,
              ),
            ),
          ),
          Expanded(
            child: Divider(
              color: MyApp.themeColor,
              thickness: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepContentContainer() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(16),
          ),
          child: _buildStepContent(),
        ),
      ),
    );
  }

  Widget _buildProgressIndicator() {
    const double dotRadius = 20;
    const double lineHeight = 2;

    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned(
          top: dotRadius,
          left: dotRadius,
          right: dotRadius,
          child: Container(
            height: lineHeight,
            color: Colors.grey.shade300,
          ),
        ),
        Positioned(
          top: dotRadius,
          left: dotRadius,
          right: dotRadius,
          child: Row(
            children: [
              Expanded(
                flex: _currentStep > 0 ? _currentStep : 0,
                child: Container(
                  height: lineHeight,
                  color: MyApp.themeColor,
                ),
              ),
              Expanded(
                flex: _currentStep < 2 ? 2 - _currentStep : 0,
                child: Container(
                  height: lineHeight,
                  color: Colors.transparent,
                ),
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(3, (index) {
            return Column(
              children: [
                CircleAvatar(
                  radius: dotRadius,
                  backgroundColor: _currentStep >= index
                      ? MyApp.themeColor
                      : Colors.grey.shade300,
                  child: _currentStep > index
                      ? const Icon(Icons.check, color: Colors.white, size: 20)
                      : index == 1 && _currentStep == 1
                      ? const Icon(Icons.currency_rupee,
                      color: Colors.white, size: 20)
                      : Text(
                    '${index + 1}',
                    style: TextStyle(
                      color: _currentStep >= index
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  index == 0
                      ? "Details"
                      : index == 1
                      ? "Payment"
                      : "Success",
                  textAlign: TextAlign.center,
                ),
              ],
            );
          }),
        ),
      ],
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildForm();
      case 1:
        return _buildPaymentType();
      case 2:
        return _buildSuccess();
      default:
        return _buildForm();
    }
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          Text(
            widget.club.name,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 6),
          Text(
            "Price: ${widget.club.formattedPrice}",
            style: const TextStyle(fontSize: 18, color: MyApp.themeColor),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _nameController,
            decoration: _inputDecoration("Name", Icons.person),
            validator: (value) => value!.isEmpty ? "Enter Name" : null,
          ),
          const SizedBox(height: 15),
          TextFormField(
            controller: _emailController,
            decoration: _inputDecoration("Email", Icons.email),
            validator: (value) => value!.isEmpty ? "Enter Email" : null,
          ),
          const SizedBox(height: 15),
          TextFormField(
            controller: _phoneController,
            decoration: _inputDecoration("Phone", Icons.phone),
            validator: (value) => value!.isEmpty ? "Enter Phone" : null,
          ),
          const SizedBox(height: 25),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: isSubmitting ? null : _submitForm,
              style: _buttonStyle(),
              child: isSubmitting
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Next"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentType() {
    return Column(
      children: [
        const Text(
          "Choose Payment Type",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        ListTile(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: MyApp.themeColor),
          ),
          leading: const Icon(Icons.payment, color: MyApp.themeColor),
          title: const Text("Online Payment"),
          onTap: () {
            _nextStep();
          },
        ),
        const SizedBox(height: 25),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _previousStep,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: MyApp.themeColor),
                ),
                child: const Text("Back"),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: _nextStep,
                style: _buttonStyle(),
                child: const Text("Proceed to Payment"),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSuccess() {
    return Column(
      children: [
        const Icon(Icons.check_circle, color: MyApp.themeColor, size: 80),
        const SizedBox(height: 20),
        const Text(
          "Payment Successful!",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => ThankYouPage(
                    name: _nameController.text,
                    mobile: _phoneController.text,
                    email: _emailController.text,
                    clubTitle: widget.club.name,
                    price: widget.club.formattedPrice,
                    imageUrl: widget.club.imageUrl,
                    joinedDate: DateFormat("yyyy-MM-dd").format(DateTime.now()),
                  ),
                ),
              );
            },
            style: _buttonStyle(),
            child: const Text("Finish"),
          ),
        ),
      ],
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: MyApp.themeColor),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: MyApp.themeColor),
      ),
    );
  }

  ButtonStyle _buttonStyle() {
    return ElevatedButton.styleFrom(
      backgroundColor: MyApp.themeColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.symmetric(vertical: 16),
    );
  }
}
