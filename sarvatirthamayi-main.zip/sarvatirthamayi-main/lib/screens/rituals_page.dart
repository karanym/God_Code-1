import 'package:flutter/material.dart';
import 'package:dotted_border/dotted_border.dart';
import 'api/api_service.dart';
import 'dart:convert';
import 'package:sarvatirthamayi/widgets/html_parser_widget.dart';

class RitualsPage extends StatefulWidget {
  @override
  _RitualsPageState createState() => _RitualsPageState();
}

class _RitualsPageState extends State<RitualsPage> {
  List temples = [];
  List rituals = [];
  int selectedTempleId = 0;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchRituals();
  }

  Future<void> fetchRituals() async {
    try {
      List response = await ApiService().fetchAllRitualsApi();
      if (response.isNotEmpty) {
        Set templeSet = {};

        temples = response.where((ritual) {
          if (templeSet.contains(ritual['temple_id'])) return false;
          templeSet.add(ritual['temple_id']);
          return true;
        }).map((ritual) => {
          "id": ritual['temple_id'],
          "temple_name": ritual['temple_name'],
          "icon_image": ritual['temple_icon']
        }).toList();

        if (temples.isNotEmpty) {
          selectedTempleId = temples[0]['id'];
          fetchTempleRituals(selectedTempleId);
        }


      }
    } catch (e) {
      print('Error fetching rituals: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> fetchTempleRituals(int templeId) async {
    setState(() {
      isLoading = true;
      selectedTempleId = templeId;
    });

    try {
      List response = await ApiService().fetchAllRitualsApi();
      // Print the full API response
      //print("Full API Response: $response");
      setState(() => rituals = response.where((r) => r['temple_id'] == templeId).toList());
      // Print rituals to see if images exist
      // for (var ritual in rituals) {
      //   print("Ritual: $ritual");
      // }

    } catch (e) {
      print('Error fetching temple rituals: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Rituals"),
        backgroundColor: Color(0xFF6A1B9A),
      ),
      body: Container(
        color: Colors.white, // Grey background highlight
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
          children: [
            _buildTempleSelector(),
            Expanded(child: _buildRitualsGrid()),
          ],
        ),
      ),
    );
  }

  Widget _buildTempleSelector() {
    return Container(
      height: 150, // Fixed height for the whole row
      color: Colors.white,
      padding: EdgeInsets.symmetric(vertical: 10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: temples.map((temple) {
            bool isSelected = temple['id'] == selectedTempleId;
            return SizedBox(
              width: 90, // Ensures consistent width for each item
              child: GestureDetector(
                onTap: () => fetchTempleRituals(temple['id']),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // 🔹 Selection Box Around Image Only
                    Container(
                      width: 80,
                      height: 80,
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: isSelected ? Color(0xFF6A1B9A) : Colors.grey.shade300,
                          width: isSelected ? 2 : 1,
                        ),
                        boxShadow: [
                          if (isSelected)
                            BoxShadow(
                              color: Color(0xFF6A1B9A).withOpacity(0.2),
                              blurRadius: 6,
                              offset: Offset(0, 2),
                            ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          temple['icon_image'],
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: Colors.grey.shade300,
                            child: Icon(Icons.broken_image, size: 30, color: Colors.grey),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 3), // Reduced height

                    // 🔹 Temple Name (Outside the Box)
                    SizedBox(
                      height: 28, // Prevents text from causing overflow
                      child: Center(
                        child: Text(
                          temple['temple_name'],
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isSelected ? Color(0xFF6A1B9A) : Colors.black87,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }


  Widget _buildRitualsGrid() {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: rituals.isEmpty
          ? Center(
        child: Text(
          "No rituals available",
          style: TextStyle(color: Color(0xFF6A1B9A), fontSize: 16),
        ),
      )
          : GridView.builder(
        itemCount: rituals.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 0.8,
        ),
        itemBuilder: (context, index) {
          return _buildRitualItem(rituals[index]);
        },
      ),
    );
  }

  Widget _buildRitualItem(Map ritual) {
    return DottedBorder(
      color: Color(0xFF6A1B9A),
      borderType: BorderType.RRect,
      radius: Radius.circular(10),
      dashPattern: [6, 4],
      strokeWidth: 1.5,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
        ),
        child: Column(
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
                  child: Image.network(
                    ritual['ritual_image'],
                    width: double.infinity,
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(Icons.broken_image, size: 100, color: Colors.grey),
                  ),
                ),
                Positioned(
                  top: 5,
                  right: 5,
                  child: GestureDetector(
                    onTap: () => _showAllImages(context, ritual['ritual_images'], ritual['ritual_title'], ritual['temple_name']),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF6A1B9A).withOpacity(0.8),
                      ),
                      padding: EdgeInsets.all(5),
                      child: Icon(Icons.image, color: Colors.white, size: 18),
                    ),
                  ),



                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    ritual['ritual_title'],
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF6A1B9A)),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "Type: ${ritual['ritual_type'].toUpperCase()}",
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  SizedBox(height: 5),
                  ElevatedButton(
                    onPressed: () => _showRitualDetailsSheet(context, ritual),
                    style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF6A1B9A)),
                    child: Text("Know More", style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAllImages(BuildContext context, List images, String ritualTitle, String templeTitle) {
    int currentIndex = 0;
    PageController pageController = PageController();

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                width: MediaQuery.of(context).size.width * 0.9,
                height: MediaQuery.of(context).size.height * 0.7,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    // 🔹 Title Section with Temple Name & Ritual Label
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                      child: Column(
                        children: [
                          Text(
                            templeTitle,
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                          ),
                          SizedBox(height: 4),
                          Text(
                            ritualTitle,
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                          ),
                        ],
                      ),
                    ),

                    // 🔹 Image Section with Swipe Arrows
                    Expanded(
                      child: Stack(
                        children: [
                          PageView.builder(
                            controller: pageController,
                            itemCount: images.length,
                            onPageChanged: (index) {
                              setState(() => currentIndex = index);
                            },
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: EdgeInsets.symmetric(horizontal: 10),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.network(
                                    images[index]['ritual_image'],
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Icon(Icons.broken_image, size: 100, color: Colors.grey),
                                  ),
                                ),
                              );
                            },
                          ),

                          // Left Arrow (Only if more than 1 image)
                          if (images.length > 1 && currentIndex > 0)
                            Positioned(
                              left: 10,
                              top: MediaQuery.of(context).size.height * 0.3,
                              child: GestureDetector(
                                onTap: () {
                                  if (currentIndex > 0) {
                                    pageController.previousPage(duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
                                  }
                                },
                                child: Container(
                                  padding: EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.black.withOpacity(0.5),
                                  ),
                                  child: Icon(Icons.arrow_back_ios, color: Colors.white, size: 24),
                                ),
                              ),
                            ),

                          // Right Arrow (Only if more than 1 image)
                          if (images.length > 1 && currentIndex < images.length - 1)
                            Positioned(
                              right: 10,
                              top: MediaQuery.of(context).size.height * 0.3,
                              child: GestureDetector(
                                onTap: () {
                                  if (currentIndex < images.length - 1) {
                                    pageController.nextPage(duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
                                  }
                                },
                                child: Container(
                                  padding: EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.black.withOpacity(0.5),
                                  ),
                                  child: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 24),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),

                    // 🔹 Close Button (Bottom)
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: IconButton(
                        icon: Icon(Icons.close, color: Colors.black, size: 30),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showRitualDetailsSheet(BuildContext context, Map ritual) {
    List<String> ritualDays = [];
    if (ritual['ritual_days'] != null && ritual['ritual_days'].toString().isNotEmpty) {
      try {
        ritualDays = List<String>.from(json.decode(ritual['ritual_days'].replaceAll("'", "\"")));
      } catch (e) {
        print("Error decoding ritual_days: $e");
      }
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      backgroundColor: Colors.white,
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.85,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Close Button
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  icon: const Icon(Icons.close, size: 28, color: Color(0xFF6A1B9A)),
                  onPressed: () => Navigator.pop(context),
                ),
              ),

              // Ritual Title
              Text(
                ritual?['ritual_title'] ?? "Unknown Ritual",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Color(0xFF6A1B9A),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                ritual?['temple_name'] ?? 'N/A',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.black54,
                ),
              ),

              const SizedBox(height: 10),

              // Ritual Info
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _infoRow("Temple", ritual?['temple_name'] ?? 'N/A'),
                      _infoRow("Ritual Type", ritual['ritual_type'] ?? 'N/A'),
                      _infoRow("Category", ritual['ritual_category'] ?? 'N/A'),
                      _infoRow("Duration", ritual['ritual_duration'] ?? 'N/A'),
                      _infoRow("Perform Time", ritual['ritual_perform_time'] ?? 'Not specified'),
                      if (ritualDays.isNotEmpty) _infoRow("Perform Days", ritualDays.join(", ")),

                      const SizedBox(height: 10),
                      _divider(),

                      if (ritual['ritual_benefits'] != null)
                        _infoSection("Benefits", HtmlTextWidget(htmlText: ritual['ritual_benefits'] ?? "")),
                      if (ritual['ritual_procedure'] != null)
                        _infoSection("Procedure", HtmlTextWidget(htmlText: ritual['ritual_procedure'] ?? "")),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

// Info Row with a cleaner layout
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.black54,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

// Section with heading and grey background
  Widget _infoSection(String title, Widget content) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: Color(0xFF6A1B9A),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 6),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.grey[200], // Grey background highlight
              borderRadius: BorderRadius.circular(10),
            ),
            child: content,
          ),
        ],
      ),
    );
  }

// Divider for sections
  Widget _divider() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      height: 1,
      color: Colors.grey[300],
    );
  }

}
