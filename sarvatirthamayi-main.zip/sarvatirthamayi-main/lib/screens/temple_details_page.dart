import 'package:flutter/material.dart';
import 'api/api_service.dart';
import 'rituals_listing_page.dart'; // Import the new page

class TempleDetailsPage extends StatefulWidget {
  final int templeId;

  const TempleDetailsPage({super.key, required this.templeId});

  @override
  State<TempleDetailsPage> createState() => _TempleDetailsPageState();
}

class _TempleDetailsPageState extends State<TempleDetailsPage> {
  Map<String, dynamic>? templeDetails;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTempleDetails();
  }

  Future<void> fetchTempleDetails() async {
    final details = await ApiService().fetchTempleDetailsApi(widget.templeId);

    setState(() {
      templeDetails = details;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Temple Details"),
        backgroundColor: const Color(0xFF6A1B9A),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : templeDetails == null
          ? const Center(child: Text("Temple details not found"))
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Banner Image
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.network(
                templeDetails!['detail_image'],
                width: double.infinity,
                height: 250,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),

            // Title
            Text(
              templeDetails!['temple_title'],
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
            const SizedBox(height: 10),

            // Short Description
            Text(
              templeDetails!['short_description'],
              style: const TextStyle(
                  fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 20),

            // Rituals Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6A1B9A),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.all(16),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => RitualsListingPage(
                        templeId: widget.templeId,
                        templeTitle: templeDetails!['temple_title'],
                        templeIcon: templeDetails!['detail_image'],
                      ),
                    ),
                  );
                },
                child: const Text(
                  "View All Rituals",
                  style: TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold,color: Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Highlights Section
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.shade100,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 6,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Highlights",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    templeDetails!['highlights'],
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
