import 'package:flutter/material.dart';
import 'home_page.dart';
import 'popular_trips_all.dart';
import 'temples.dart';
import 'rituals_page.dart';
import 'profile_page.dart';

const Color themeColor = Color(0xFFF18553);

class FooterMenu extends StatefulWidget {
  @override
  _FooterMenuState createState() => _FooterMenuState();
}

class _FooterMenuState extends State<FooterMenu> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    HomePage(),
    PopularTripsPage(),
    TempleListingPage(),
    RitualsPage(),
    ProfilePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex], // ✅ Show selected page
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: themeColor,
        unselectedItemColor: Colors.black54,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        onTap: _onItemTapped,
        items: [
          _buildNavItem(Icons.home, "Home", 0),
          _buildNavItem(Icons.luggage, "Trips", 1),
          _buildNavItem(Icons.temple_hindu, "Temples", 2),
          _buildNavItem(Icons.auto_awesome, "Rituals", 3),
          _buildNavItem(Icons.person, "Profile", 4),
        ],
      ),
    );
  }

  BottomNavigationBarItem _buildNavItem(IconData icon, String label, int index) {
    return BottomNavigationBarItem(
      icon: Icon(icon, color: _selectedIndex == index ? themeColor : Colors.black54),
      label: label,
    );
  }
}
