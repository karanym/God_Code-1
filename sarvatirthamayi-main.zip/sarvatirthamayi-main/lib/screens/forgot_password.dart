import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'reset_pwd_otp_verification.dart'; // Import OTP Verification Page
import 'home_page.dart'; // Import Home Page

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController mobileController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _isKeyboardOpen = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      setState(() {
        _isKeyboardOpen = _focusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    mobileController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  String authToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6InNhcnZhdGlydGhhbWF5aUBtYWlsaW5hdG9yLmNvbSIsImV4cCI6NDg5MzMyNDQyMywiZW1haWwiOiJzYXJ2YXRpcnRoYW1heWlAbWFpbGluYXRvci5jb20ifQ.y-IM2sin3OWbhYzrBH8P7xhpyguEtYjljnR7yQzZkKU"; // Store token dynamically

  // Set Token Method
  void setToken(String token) {
    authToken = token;
  }

  Future<void> sendOtp() async {
    setState(() => isLoading = true);
    final url = Uri.parse('http://10.0.2.2:8000/api/send-otp-reset-password/'); // Replace with your actual API URL
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json',"Authorization": "Bearer $authToken",},
        body: jsonEncode({'mobile': mobileController.text.trim()}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String otp = data['otp'];
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ResetOTPVerificationScreen(
              mobile: mobileController.text.trim(),
              otp: otp,
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to send OTP")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color themeColor = Color(0xFF6A1B9A); // Theme color
    double screenHeight = MediaQuery.of(context).size.height;
    double keyboardPadding = MediaQuery.of(context).viewInsets.bottom;

    return Scaffold(
      body: SingleChildScrollView(
        child: SizedBox(
          height: screenHeight, // Ensures full screen height
          child: Column(
            children: [
              // Top Section with Banner & Home Button
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                height: _isKeyboardOpen ? screenHeight * 0.25 : screenHeight * 0.40, // Adjust height dynamically
                child: Stack(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Image.asset(
                        "assets/images/banner-right.png",
                        fit: BoxFit.cover,
                      ),
                    ),
                    Positioned(
                      top: 40,
                      left: 10,
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),
                    Positioned(
                      top: 40,
                      right: 20,
                      child: IconButton(
                        icon: const Icon(Icons.home, color: Colors.white, size: 28),
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const HomePage()),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),

              // Form Section
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(bottom: keyboardPadding),
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Fix Logo rendering
                        if (!_isKeyboardOpen)
                          Image.asset("assets/images/logo.jpeg", height: 80, errorBuilder: (context, error, stackTrace) {
                            return const SizedBox(); // fallback if logo missing
                          }),

                        const SizedBox(height: 15),
                        const Text(
                          "Forgot Password?",
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const Text(
                          "Enter your mobile number to receive an OTP.",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 16, color: Colors.black54),
                        ),
                        const SizedBox(height: 20),

                        // Mobile Number Input
                        TextField(
                          controller: mobileController,
                          keyboardType: TextInputType.phone,
                          focusNode: _focusNode,
                          decoration: InputDecoration(
                            hintText: "Mobile Number",
                            prefixIcon: const Icon(Icons.phone, color: themeColor),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: const BorderSide(color: themeColor, width: 2),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: const BorderSide(color: themeColor, width: 2),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: const BorderSide(color: Color(0xFFD9734A), width: 3),
                            ),
                          ),
                        ),
                        const SizedBox(height: 25),

                        // Submit Button
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: themeColor,
                            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 40),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          ),
                          onPressed: isLoading
                              ? null
                              : () {
                            if (mobileController.text.isNotEmpty) {
                              sendOtp();
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text("Please enter your mobile number")),
                              );
                            }
                          },
                          child: isLoading
                              ? const CircularProgressIndicator(color: Colors.white)
                              : const Text("Send OTP", style: TextStyle(fontSize: 18, color: Colors.white)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
