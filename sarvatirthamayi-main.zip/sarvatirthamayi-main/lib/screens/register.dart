import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'otp_verification.dart';
import 'home_page.dart';
import '/widgets/curved_button.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  final TextEditingController cityController = TextEditingController();

  bool isLoading = false;

  String authToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6InNhcnZhdGlydGhhbWF5aUBtYWlsaW5hdG9yLmNvbSIsImV4cCI6NDg5MzMyNDQyMywiZW1haWwiOiJzYXJ2YXRpcnRoYW1heWlAbWFpbGluYXRvci5jb20ifQ.y-IM2sin3OWbhYzrBH8P7xhpyguEtYjljnR7yQzZkKU"; // Store token dynamically

  // Set Token Method
  void setToken(String token) {
    authToken = token;
  }

  Future<void> registerUser() async {
    final url = Uri.parse("http://10.0.2.2:8000/api/registration/");
    final body = jsonEncode({
      "name": nameController.text,
      "mobile": mobileController.text,
      "email": emailController.text,
      "password": passwordController.text,
      "city": cityController.text,
    });

    try {
      setState(() => isLoading = true);
      final response = await http.post(
        url,
        headers: {
          "Authorization": "Bearer $authToken",
          "Content-Type": "application/json"},
        body: body,
      );

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        String otp = data["otp"];

        // ✅ Navigate to OTP Verification screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OtpVerificationScreen(
              name: nameController.text,
              mobile: mobileController.text,
              email: emailController.text,
              city: cityController.text,
              password: passwordController.text,
            ),
          ),
        );

      } else {
        print("Registration Failed: ${response.body}");
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color themeColor = Color(0xFF6A1B9A);

    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Column(
        children: [
          Expanded(
            flex: 4,
            child: Stack(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Image.asset(
                    "assets/images/banner-right.png",
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 40,
                  right: 20,
                  child: IconButton(
                    icon: const Icon(Icons.home, color: Colors.white, size: 28),
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => const HomePage()),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            flex: 6,
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Welcome to Sarvatirthamayi",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black87),
                    ),
                    const Text(
                      "Please create your account",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black38),
                    ),
                    const SizedBox(height: 15),

                    _buildTextField("Full Name", Icons.person, false, nameController),
                    const SizedBox(height: 10),
                    _buildTextField("Mobile Number", Icons.phone, false, mobileController),
                    const SizedBox(height: 10),
                    _buildTextField("Email", Icons.email, false, emailController),
                    const SizedBox(height: 10),
                    _buildTextField("Password", Icons.lock, true, passwordController),
                    const SizedBox(height: 10),
                    _buildTextField("Confirm Password", Icons.lock_outline, true, confirmPasswordController),
                    const SizedBox(height: 10),
                    _buildTextField("City", Icons.location_city, false, cityController),
                    const SizedBox(height: 15),

                    CurvedButton(
                      text: isLoading ? "Signing Up..." : "Sign Up",
                      color: themeColor,
                      onPressed: registerUser,
                    ),

                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Already have an account? "),
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            "Login",
                            style: TextStyle(color: themeColor, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(String hint, IconData icon, bool isPassword, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: const Color(0xFF6A1B9A)),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Color(0xFF6A1B9A), width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Color(0xFF6A1B9A), width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Color(0xFF6A1B9A), width: 3),
        ),
      ),
    );
  }
}
