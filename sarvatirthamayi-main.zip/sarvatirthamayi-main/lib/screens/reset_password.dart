import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '/widgets/curved_button.dart';
import 'login.dart';
import 'home_page.dart';
import 'dart:convert';

class ResetPasswordScreen extends StatefulWidget {
  final String mobile;
  const ResetPasswordScreen({required this.mobile, super.key});

  @override
  _ResetPasswordScreenState createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  final FocusNode _passwordFocusNode = FocusNode();
  final FocusNode _confirmPasswordFocusNode = FocusNode();

  bool _isKeyboardOpen = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _passwordFocusNode.addListener(_updateKeyboardStatus);
    _confirmPasswordFocusNode.addListener(_updateKeyboardStatus);
  }

  void _updateKeyboardStatus() {
    setState(() {
      _isKeyboardOpen = _passwordFocusNode.hasFocus || _confirmPasswordFocusNode.hasFocus;
    });
  }

  @override
  void dispose() {
    passwordController.dispose();
    confirmPasswordController.dispose();
    _passwordFocusNode.dispose();
    _confirmPasswordFocusNode.dispose();
    super.dispose();
  }

  String authToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6InNhcnZhdGlydGhhbWF5aUBtYWlsaW5hdG9yLmNvbSIsImV4cCI6NDg5MzMyNDQyMywiZW1haWwiOiJzYXJ2YXRpcnRoYW1heWlAbWFpbGluYXRvci5jb20ifQ.y-IM2sin3OWbhYzrBH8P7xhpyguEtYjljnR7yQzZkKU"; // Store token dynamically

  // Set Token Method
  void setToken(String token) {
    authToken = token;
  }

  Future<void> resetPassword() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:8000/api/reset-password/'),
        headers: {'Content-Type': 'application/json',"Authorization": "Bearer $authToken",},
        body: json.encode({
          'mobile': widget.mobile,
          'new_password': passwordController.text,
          'confirm_password': confirmPasswordController.text,
        }),
      );

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['message'] != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'])),
        );
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
              (route) => false,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['error'] ?? 'Failed to reset password')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Something went wrong')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color themeColor = Color(0xFF6A1B9A);
    double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: _isKeyboardOpen ? screenHeight * 0.20 : screenHeight * 0.35,
              child: Stack(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: Image.asset(
                      "assets/images/banner-right.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 20,
                    left: 10,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  Positioned(
                    top: 20,
                    right: 20,
                    child: IconButton(
                      icon: const Icon(Icons.home, color: Colors.white, size: 28),
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => const HomePage()),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (!_isKeyboardOpen)
                      Image.asset("assets/images/logo.jpeg", height: 80),
                    const SizedBox(height: 15),
                    const Text(
                      "Reset Password",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black87),
                    ),
                    Text(
                      "Set a new password for ${widget.mobile}",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16, color: Colors.black54),
                    ),
                    const SizedBox(height: 20),
                    _buildTextField("New Password", Icons.lock, passwordController, true, _passwordFocusNode),
                    const SizedBox(height: 20),
                    _buildTextField("Confirm Password", Icons.lock, confirmPasswordController, true, _confirmPasswordFocusNode),
                    const SizedBox(height: 20),
                    _isLoading
                        ? const CircularProgressIndicator(color: themeColor)
                        : CurvedButton(
                      text: "Reset Password",
                      color: themeColor,
                      onPressed: () {
                        if (passwordController.text.isEmpty || confirmPasswordController.text.isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Please enter both password fields")),
                          );
                          return;
                        }
                        if (passwordController.text != confirmPasswordController.text) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Passwords do not match")),
                          );
                          return;
                        }
                        resetPassword();
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String hint, IconData icon, TextEditingController controller, bool isPassword, FocusNode focusNode) {
    const Color themeColor = Color(0xFF6A1B9A);
    return TextFormField(
      controller: controller,
      obscureText: isPassword,
      focusNode: focusNode,
      autofocus: false,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: themeColor),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: themeColor, width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: themeColor, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Color(0xFFD9734A), width: 3),
        ),
      ),
    );
  }
}
