import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:sarvatirthamayi/main.dart';
import 'api/api_service.dart';
import 'login.dart'; // assuming you have this screen

class MyTripsPage extends StatefulWidget {
  const MyTripsPage({Key? key}) : super(key: key);

  @override
  State<MyTripsPage> createState() => _MyTripsPageState();
}

class _MyTripsPageState extends State<MyTripsPage> {
  final storage = const FlutterSecureStorage();
  List<dynamic> bookedTrips = [];
  bool isLoading = true;
  String? authToken;
  final ApiService apiService = ApiService();

  @override
  void initState() {
    super.initState();
    _checkAuth();
  }

  Future<void> _checkAuth() async {
    authToken = await storage.read(key: 'auth_token');
    if (authToken != null) {
      fetchBookedTrips();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> fetchBookedTrips() async {
    final response = await apiService.getBookedTrips();
    if (response != null && response['data'] != null) {
      setState(() {
        bookedTrips = response['data'];
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color themeColor = Color(0xFF6A1B9A);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: themeColor,
        title: const Text("My Booked Trips"),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : authToken == null || authToken!.isEmpty
          ? _buildLoggedOutView(themeColor)
          : bookedTrips.isEmpty
          ? const Center(child: Text("No booked trips found!"))
          : _buildTripsList(themeColor),
    );
  }

  Widget _buildLoggedOutView(Color themeColor) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.lock_outline, size: 80, color: themeColor),
            const SizedBox(height: 20),
            const Text(
              "You are not logged In",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 10),
            const Text(
              "Please login to view your booked trips.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.black54),
            ),
            const SizedBox(height: 25),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                icon: const Icon(Icons.login),
                label: const Text(
                  "Login Now",
                  style: TextStyle(fontSize: 16),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTripsList(Color themeColor) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: bookedTrips.length,
      itemBuilder: (context, index) {
        final trip = bookedTrips[index];
        final tripDetails = trip['trip_details'] ?? {};
        final requestOn = DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.parse(trip['request_on']));
        final startDate = DateFormat('dd MMM yyyy').format(DateTime.parse(trip['start_date']));

        return Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          margin: const EdgeInsets.only(bottom: 20),
          elevation: 6,
          shadowColor: themeColor.withOpacity(0.3),
          child: Column(
            children: [
              // Image with gradient overlay
              Stack(
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                    child: Image.network(
                      tripDetails['thumbnail_image'] ?? '',
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          height: 200,
                          color: Colors.grey.shade300,
                          child: const Center(child: Icon(Icons.image_not_supported, size: 50)),
                        );
                      },
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 70,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18)),
                        gradient: LinearGradient(
                          colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 12,
                    left: 16,
                    right: 16,
                    child: Text(
                      tripDetails['trip_title'] ?? trip['trip_title'] ?? '',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(14.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.calendar_today, size: 18, color: MyApp.themeColor),
                        const SizedBox(width: 6),
                        Text("Start: $startDate", style: const TextStyle(color: Colors.black87)),
                        const Spacer(),
                        Row(
                          children: [
                            const Icon(Icons.schedule, size: 18, color: MyApp.themeColor),
                            const SizedBox(width: 6),
                            Text("${trip['no_of_days']} Days", style: const TextStyle(color: Colors.black87)),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Icon(Icons.people, size: 18, color: MyApp.themeColor),
                        const SizedBox(width: 6),
                        Text("Devotees: ${trip['no_of_devotees']}", style: const TextStyle(color: Colors.black87)),
                        const Spacer(),
                        Text(
                          "₹ ${trip['trip_price']}",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Icon(Icons.bookmark_border, size: 18, color: MyApp.themeColor),
                        const SizedBox(width: 6),
                        Text("Type: ${trip['type_of_trip']}", style: const TextStyle(color: Colors.black87)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Icon(Icons.timelapse, size: 18, color: MyApp.themeColor),
                        const SizedBox(width: 6),
                        Text("Booked on: $requestOn", style: const TextStyle(color: Colors.black87)),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }
}
