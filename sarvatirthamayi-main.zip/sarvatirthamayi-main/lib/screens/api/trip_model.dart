import 'package:intl/intl.dart'; // ✅ Import intl for currency formatting

class Trip {
  final int id;
  final String title;
  final String thumbnailImage;
  final String status;
  final String popularStatus;
  final String typeOfTrip;
  final int price;

  Trip({
    required this.id,
    required this.title,
    required this.thumbnailImage,
    required this.status,
    required this.popularStatus,
    required this.typeOfTrip,
    required this.price,
  });

  factory Trip.fromJson(Map<String, dynamic> json) {
    return Trip(
      id: json["id"] ?? 0,
      title: json["trip_title"] ?? "Unknown Trip",
      thumbnailImage: json["thumbnail_image"] ?? "https://example.com/default.jpg",
      status: json["status"] ?? "inactive",
      popularStatus: json["popular_status"] ?? "no",
      typeOfTrip: json["type_of_trip"] ?? "Unknown",
      price: (json["price"] is num) ? (json["price"] as num).toInt() : 0, // ✅ Ensure price is a double
    );
  }

  // ✅ Function to format price when displaying
  String getFormattedPrice() {
    final currencyFormat = NumberFormat.currency(
        locale: "en_IN",
        symbol: "₹",
        decimalDigits: 0 // ✅ Removes .00
    );
    return currencyFormat.format(price);
  }
}
