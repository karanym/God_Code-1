import 'package:intl/intl.dart';

class Club {
  final int id;
  final String name;
  final String description;
  final String imageUrl;
  final String clubType;
  final String clubTypeDisplay;
  final double price;
  final String benefits;
  final int maxMembers;
  final String clubStatus;
  final String clubStatusDisplay;
  final String subscriptionStatus;
  final String subscriptionStatusDisplay;
  final String? expiryStatus;
  final DateTime? expiryDate;
  final bool notification; // <-- Added
  final int daysLeft; // <-- Added
  final DateTime timestamp;

  Club({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.clubType,
    required this.clubTypeDisplay,
    required this.price,
    required this.benefits,
    required this.maxMembers,
    required this.clubStatus,
    required this.clubStatusDisplay,
    required this.subscriptionStatus,
    required this.subscriptionStatusDisplay,
    this.expiryStatus,
    this.expiryDate,
    required this.notification, // <-- Added
    required this.daysLeft, // <-- Added
    required this.timestamp,
  });

  factory Club.fromJson(Map<String, dynamic> json) {
    return Club(
      id: json['id'] ?? 0,
      name: json['name'] ?? 'Unknown Club',
      description: json['description'] ?? 'No description available',
      imageUrl: json['image_url'] ?? '',
      clubType: json['club_type'] ?? 'Unknown Type',
      clubTypeDisplay: json['club_type_display'] ?? 'Unknown Type',
      price: double.tryParse(json['price'].toString()) ?? 0.0,
      benefits: json['benefits'] ?? '',
      maxMembers: json['max_members'] ?? 0,
      clubStatus: json['club_status'] ?? 'Unknown',
      clubStatusDisplay: json['club_status_display'] ?? 'Unknown',
      subscriptionStatus: json['subscription_status']?.toString() ?? 'not_subscribed',
      subscriptionStatusDisplay: json['subscription_status_display']?.toString() ?? 'Not Subscribed',
      expiryStatus: json['expiry_status'],
      expiryDate: json['expiry_date'] != null && json['expiry_date'] != ''
          ? DateTime.tryParse(json['expiry_date'])
          : null,
      notification: json['notification'] ?? false, // <-- Added
      daysLeft: json['days_left'] ?? 0, // <-- Added
      timestamp: DateTime.tryParse(json['timestamp'] ?? '') ?? DateTime.now(),
    );
  }

  String get formattedPrice {
    final formatCurrency = NumberFormat.currency(
      locale: "en_IN",
      symbol: "₹",
      decimalDigits: price == price.toInt() ? 0 : 2,
    );
    return formatCurrency.format(price);
  }

  String get formattedExpiryDate {
    if (expiryDate != null) {
      return DateFormat('dd MMM yyyy').format(expiryDate!);
    }
    return 'No expiry';
  }
}
