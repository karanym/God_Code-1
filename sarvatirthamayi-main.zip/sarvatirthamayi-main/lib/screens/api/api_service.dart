import 'dart:convert';
import 'package:http/http.dart' as http;
import 'trip_model.dart';
import 'clubs.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart';
import 'dart:io';

class ApiService {
  static const String baseUrl = "http://10.0.2.2:8000/api"; // Localhost for Android Emulator
  String authToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6InNhcnZhdGlydGhhbWF5aUBtYWlsaW5hdG9yLmNvbSIsImV4cCI6NDg5MzMyNDQyMywiZW1haWwiOiJzYXJ2YXRpcnRoYW1heWlAbWFpbGluYXRvci5jb20ifQ.y-IM2sin3OWbhYzrBH8P7xhpyguEtYjljnR7yQzZkKU"; // Store token dynamically

  final storage = const FlutterSecureStorage();
  // Set Token Method
  void setToken(String token) {
    authToken = token;
  }


  Future<List<dynamic>> getRituals() async {
    final response = await http.get(Uri.parse("${baseUrl}/rituals/"),

      headers: {
        "Authorization": "Bearer $authToken", // 🔹 Send token in headers
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception("Failed to load rituals");
    }
  }

  Future<List<dynamic>> getTempleRituals(int templeId) async {
    final response = await http.get(Uri.parse("${baseUrl}/temples_rituals/$templeId/"),
      headers: {
        "Authorization": "Bearer $authToken", // 🔹 Send token in headers
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception("Failed to load temple rituals");
    }
  }

  // 🔹 Generic GET request
  Future<dynamic> get(String endpoint) async {
    try {
      String? token = await storage.read(key: "auth_token"); // Retrieve stored token
      if (token == null) throw Exception("Token not found");

      final response = await http.get(
        Uri.parse("$baseUrl$endpoint"),
        headers: {
          "Authorization": "Bearer $token", // 🔹 Send token in headers
          "Content-Type": "application/json",
        },
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception("Error ${response.statusCode}: ${response.body}");
      }
    } catch (e) {
      print("API Error: $e");
      return null;
    }
  }

  // Fetch Home Page Data
  Future<Map<String, dynamic>> fetchHomePageData() async {
    final response = await http.get(
      Uri.parse("$baseUrl/home_page/"),
      headers: {
        "Authorization": "Bearer $authToken",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return {
        "latest_activities": data["latest_activities"] ?? [],
        "popular_trips": data["popular_trips"] ?? [],
        "temples": data["temples"] ?? [],
      };
    } else {
      throw Exception("Failed to load home page data: ${response.body}");
    }
  }

  Future<Map<String, dynamic>?> fetchProfile() async {
    try {
      String? token = await storage.read(key: "auth_token"); //user logged in token


      final response = await http.get(
        Uri.parse("$baseUrl/profile/"),
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        print("Error fetching profile: ${response.body}");
        return null;
      }
    } catch (e) {
      print("Exception in fetchProfile: $e");
      return null;
    }
  }


  // 🔹 Generic POST request
  Future<dynamic> post(String endpoint, Map<String, dynamic> body) async {
    try {
      String? token = await storage.read(key: "token");
      if (token == null) throw Exception("Token not found");

      final response = await http.post(
        Uri.parse("$baseUrl$endpoint"),
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
        body: jsonEncode(body),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        throw Exception("Error ${response.statusCode}: ${response.body}");
      }
    } catch (e) {
      print("API Error: $e");
      return null;
    }
  }

  // 🔹 Upload Image API (Multipart Request)
  Future<dynamic> uploadImage(String endpoint, File imageFile) async {
    try {
      String? token = await storage.read(key: "token");
      if (token == null) throw Exception("Token not found");

      var request = http.MultipartRequest(
        "POST",
        Uri.parse("$baseUrl$endpoint"),
      );

      // Attach the token in headers
      request.headers['Authorization'] = "Bearer $token";

      // Attach image file
      var imageStream = http.ByteStream(imageFile.openRead());
      var imageLength = await imageFile.length();
      var multipartFile = http.MultipartFile(
        'profile_image', // 🔹 API parameter name
        imageStream,
        imageLength,
        filename: basename(imageFile.path),
      );
      request.files.add(multipartFile);

      // Send request
      var response = await request.send();
      var responseBody = await response.stream.bytesToString();

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(responseBody);
      } else {
        throw Exception("Error ${response.statusCode}: $responseBody");
      }
    } catch (e) {
      print("Image Upload Error: $e");
      return null;
    }
  }
  /// Fetch Trip Details Using Token
  Future<Map<String, dynamic>> fetchTripDetails(int tripId) async {

    final response = await http.get(
      Uri.parse("$baseUrl/trip-detail?trip_id=$tripId"),
      headers: {
        "Authorization": "Bearer $authToken",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body)["trip_details"];
    } else {
      throw Exception("Failed to load trip details");
    }
  }

  /// Post Booking Details
  Future<bool> bookTrip(Map<String, dynamic> bookingData) async {
    final response = await http.post(
      Uri.parse("$baseUrl/booking/"), // API endpoint for booking
      headers: {
        "Authorization": "Bearer $authToken",
        "Content-Type": "application/json"},
      body: jsonEncode(bookingData),
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      return true; // Booking successful
    } else {
      return false; // Booking failed
    }
  }

  Future<List<Trip>> fetchTrips() async {
    final response = await http.get(Uri.parse("$baseUrl/trips/"),
      headers: {
        "Authorization": "Bearer $authToken",
        "Content-Type": "application/json"},
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)["trips"];
      return data.map((json) => Trip.fromJson(json)).toList();
    } else {
      throw Exception("Failed to load trips");
    }
  }
  Future<List<Map<String, dynamic>>> fetchTemples() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/temples/'),
        headers: {
          "Authorization": "Bearer $authToken",
          "Content-Type": "application/json"},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return List<Map<String, dynamic>>.from(data["temples"]);
      } else {
        throw Exception("Failed to load temples");
      }
    } catch (e) {
      print("Error fetching temples: $e");
      return [];
    }
  }
  /// Fetch Trip Details Using Token
  Future<Map<String, dynamic>> fetchTempleDetailsApi(int templeId) async {

    final response = await http.get(
      Uri.parse("$baseUrl/temple-detail?temple_id=$templeId"),
      headers: {
        "Authorization": "Bearer $authToken",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body)["temple_details"];
    } else {
      throw Exception("Failed to load trip details");
    }
  }

  Future<List<Club>> fetchClubs() async {

    String token = await storage.read(key: "auth_token") ?? authToken;

    final response = await http.get(
      Uri.parse('$baseUrl/clubs'),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> responseData = json.decode(response.body);

      if (responseData.containsKey('clubs')) {
        List<dynamic> clubsData = responseData['clubs'];
        return clubsData.map((json) => Club.fromJson(json)).toList();
      } else {
        throw Exception('Invalid API response: Missing "clubs" key');
      }
    } else {
      throw Exception('Failed to load clubs');
    }
  }

  Future<Map<String, dynamic>?> fetchClubDetails(int clubId) async {
    final url = Uri.parse('$baseUrl/club-detail?club_id=$clubId',);
    String token = await storage.read(key: "auth_token") ?? authToken;
    print('status_token');
    print(authToken);
    try {
      final response = await http.get(url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        });

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        print("Error: ${response.body}");
        return null;
      }
    } catch (e) {
      print("Exception: $e");
      return null;
    }
  }


  Future<bool> submitSubscription(Map<String, dynamic> data) async {
    String? token = await storage.read(key: "auth_token");
    //print(token);
    if (token == null) return false;

    final Uri url = Uri.parse("$baseUrl/subscribe-member/");
    final response = await http.post(
      url,
      body: jsonEncode(data),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token"
      },
    );

    print("Request Data: ${jsonEncode(data)}");
    print("Response Status: ${response.statusCode}");
    print("Response Body: ${response.body}");

    if (response.statusCode == 201) {
      return true;
    } else {
      print("API Error: ${response.body}");
      return false;
    }
  }

  /// Fetch all rituals without filtering by templeId
  Future<List<Map<String, dynamic>>> fetchAllRitualsApi() async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/rituals/"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $authToken"
        },);

      if (response.statusCode == 200) {
        List<dynamic> jsonData = json.decode(response.body);

        return jsonData.map<Map<String, dynamic>>((ritual) {
          return {
            "id": ritual["id"] as int?,
            "temple_id": int.tryParse(ritual["temple_id"].toString()),  // Ensure it's an integer
            "temple_name": ritual["temple_details"]?["temple_name"] ?? "Unknown Temple",
            "temple_icon": ritual["temple_details"]?["icon_image"] ?? "",
            "ritual_title": ritual["ritual_label_details"]?["title"] ?? "No Title",
            "ritual_image": ritual["ritual_label_details"]?["image_url"] ?? "",
            "ritual_price": double.tryParse(ritual["ritual_price"]?.toString() ?? "0.0"),
            "ritual_type": ritual["ritual_type"] ?? "unpaid",
            "ritual_images": (ritual["ritual_images"] as List<dynamic>?)?.map((img) {
              return {
                "image_caption": img["image_caption"] ?? "No Caption",
                "ritual_image": img["ritual_image"] ?? ""
              };
            }).toList() ?? [],
            "ritual_category": ritual["ritual_category"] ?? "Unknown",
            "ritual_benefits": ritual["ritual_benefits"] ?? "No benefits mentioned.",
            "ritual_procedure": ritual["ritual_procedure"] ?? "No procedure available.",
            "ritual_prasadham_or_giveback": ritual["ritual_prasadham_or_giveback"] ?? "None",
            "ritual_duration": ritual["ritual_duration"] ?? "Not specified",
            "ritual_perform_time": ritual["ritual_perform_time"] ?? "Not specified",
            "ritual_frequency": ritual["ritual_frequency"] ?? "Not specified",
            "ritual_days": (ritual["ritual_days"] is String && ritual["ritual_days"].isNotEmpty)
                ? List<String>.from(jsonDecode(ritual["ritual_days"].replaceAll("'", "\"")))
                : (ritual["ritual_days"] is List ? List<String>.from(ritual["ritual_days"]) : []),
          };
        }).toList();
      } else {
        print("API Error: ${response.body}");
        return [];
      }
    } catch (e) {
      print("Exception in fetchAllRitualsApi: $e");
      return [];
    }
  }

  Future<List<dynamic>?> fetchRitualsApi(int templeId) async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/temples_rituals/$templeId/"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $authToken"
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);

        // Ensure default values for null fields to prevent errors
        return data.map((ritual) => {
          "id": ritual["id"] ?? 0,
          "temple_details": ritual["temple_details"] ?? {},
          "ritual_label_details": ritual["ritual_label_details"] ?? {},
          "ritual_category": ritual["ritual_category"] ?? "Unknown",
          "ritual_type": ritual["ritual_type"] ?? "Unknown",
          "ritual_price": ritual["ritual_price"] ?? "0.00",
          "ritual_images": ritual["ritual_images"] ?? [],
          "ritual_benefits": ritual["ritual_benefits"] ?? "No benefits mentioned.",
          "ritual_procedure": ritual["ritual_procedure"] ?? "No procedure available.",
          "ritual_prasadham_or_giveback": ritual["ritual_prasadham_or_giveback"] ?? "None",
          "ritual_duration": ritual["ritual_duration"] ?? "Not specified",
          "ritual_perform_time": ritual["ritual_perform_time"] ?? "Not specified",
          "ritual_frequency": ritual["ritual_frequency"] ?? "Not specified",
          "ritual_days": (ritual["ritual_days"] is String && ritual["ritual_days"].isNotEmpty)
              ? List<String>.from(jsonDecode(ritual["ritual_days"].replaceAll("'", "\"")))
              : (ritual["ritual_days"] is List ? List<String>.from(ritual["ritual_days"]) : []),
        }).toList();
      } else {
        print("Error: ${response.statusCode}, ${response.body}");
        return null;
      }
    } catch (e) {
      print("Error fetching rituals: $e");
      return null;
    }
  }


  //login

   Future<Map<String, dynamic>?> login(String mobile, String password) async {
    final url = Uri.parse('${baseUrl}/login/');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'mobile_number': mobile,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {

      print('response');
      print(response.body);
      print(mobile);
      print(password);

      return json.decode(response.body);
    } else {
      return null;
    }
  }

  Future<void> storeToken(String token) async {
    await storage.write(key: 'auth_token', value: token);
  }

  Future<void> storeUserName(String name) async {
    await storage.write(key: 'user_name', value: name);
  }

  Future<String?> getToken() async {
    return await storage.read(key: 'auth_token');
  }

  Future<String?> getUserName() async {
    return await storage.read(key: 'user_name');
  }

  Future<bool> logout() async {
    String? token = await storage.read(key: "auth_token");

    if (token == null) return false; // No token means user is not logged in

    final response = await http.post(
      Uri.parse("$baseUrl/logout/"), // Update with your logout API endpoint
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      await storage.delete(key: "auth_token"); // Clear the token
      await storage.delete(key: 'user_name');
      return true;
    } else {
      return false;
    }
  }

  Future<dynamic> getBookedTrips() async {
    String? token = await storage.read(key: "auth_token");

    final response = await http.get(
      Uri.parse("${baseUrl}/my_trips/"),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token"
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      print("Error: ${response.statusCode}");
      return null;
    }
  }

  Future<Map<String, dynamic>?> updateProfile(Map<String, dynamic> data) async {
    String? token = await storage.read(key: 'auth_token');
    var response = await http.post(
      Uri.parse('${baseUrl}/profile/update/'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode(data),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      // Handle error properly here
      print('Profile update failed: ${response.body}');
      return null;
    }
  }

}//class
