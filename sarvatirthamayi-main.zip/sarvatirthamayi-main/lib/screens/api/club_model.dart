import 'package:intl/intl.dart';

class Club {
  final int id;
  final String name;
  final double price; // ✅ Change to double for proper numeric handling
  final String description;
  final String imageUrl;
  final String benefits;
  final String clubType;
  final int maxMembers;
  final String clubStatus;

  Club({
    required this.id,
    required this.name,
    required this.price,
    required this.description,
    required this.imageUrl,
    required this.benefits,
    required this.clubType,
    required this.maxMembers,
    required this.clubStatus,
  });

  factory Club.fromJson(Map<String, dynamic> json) {
    return Club(
      id: json['id'] ?? 0,
      name: json['name'] ?? 'Unknown Club',
      price: double.tryParse(json['price'].toString()) ?? 0.0, // ✅ Convert price to double
      description: json['description'] ?? 'No description available',
      imageUrl: json['image_url'] ?? '',
      benefits: json['benefits'] ?? '',
      clubType: json['club_type_display'] ?? 'Unknown Type',
      maxMembers: json['max_members'] ?? 0,
      clubStatus: json['club_status_display'] ?? 'Unknown',
    );
  }

  /// ✅ Format price without `.00` if it's a whole number
  String get formattedPrice {
    final formatCurrency = NumberFormat.currency(
      locale: "en_IN",
      symbol: "₹",
      decimalDigits: price == price.toInt() ? 0 : 2, // 🔥 Remove `.00` for whole numbers
    );
    return formatCurrency.format(price);
  }
}
