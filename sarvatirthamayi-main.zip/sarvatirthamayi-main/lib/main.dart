import 'package:flutter/material.dart';
import 'screens/home_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // Define the theme color: #F18553
  static const Color themeColor = Color(0xFF6A1B9A);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Temple App',
      theme: ThemeData(
        primaryColor: Color(0xFF6A1B9A), // Purple theme color
        scaffoldBackgroundColor: Colors.white, // Background color
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFF6A1B9A), // Purple AppBar
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        textTheme: TextTheme(
          bodyLarge: TextStyle(color: Color(0xFF333333)), // Dark text for light background
          bodyMedium: TextStyle(color: Color(0xFF444444)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF6A1B9A), // Purple button
            foregroundColor: Colors.white, // White text
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        radioTheme: RadioThemeData(
          fillColor: MaterialStateProperty.all(Color(0xFF6A1B9A)), // Purple radio button
        ),
      ),
      home: const HomePage(),
      // You can add your routes here for other screens
    );
  }
}
