import 'package:flutter/material.dart';

class CurvedButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final Color? color; // Added Color Parameter

  const CurvedButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.color, // Make it optional
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color ?? Colors.orange, // Default color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
      ),
      child: Text(
        text,
        style: const TextStyle(fontSize: 16, color: Colors.white),
      ),
    );
  }
}
