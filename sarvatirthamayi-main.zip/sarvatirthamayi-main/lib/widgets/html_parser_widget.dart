import 'package:flutter/material.dart';
import 'package:html/parser.dart' as htmlParser;
import 'package:html/dom.dart' as dom;

class HtmlTextWidget extends StatelessWidget {
  final String htmlText;

  const HtmlTextWidget({super.key, required this.htmlText});

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: _parseHtmlToText(htmlText),
    );
  }

  TextSpan _parseHtmlToText(String html) {
    dom.Document document = htmlParser.parse(html);
    return _parseNode(document.body!);
  }

  TextSpan _parseNode(dom.Node node) {
    List<TextSpan> spans = [];

    for (var child in node.nodes) {
      if (child is dom.Element) {
        TextStyle style = const TextStyle();

        if (child.localName == "b" || child.localName == "strong") {
          style = const TextStyle(fontWeight: FontWeight.bold);
        } else if (child.localName == "i" || child.localName == "em") {
          style = const TextStyle(fontStyle: FontStyle.italic);
        } else if (child.localName == "u") {
          style = const TextStyle(decoration: TextDecoration.underline);
        } else if (child.localName == "br") {
          spans.add(const TextSpan(text: "\n"));
          continue;
        } else if (child.localName == "ul" || child.localName == "ol") {
          for (var li in child.children) {
            spans.add(
              TextSpan(
                text: "• ${li.text.trim()}\n",
                style: const TextStyle(fontSize: 14),
              ),
            );
          }
          continue;
        } else if (child.localName == "li") {
          spans.add(
            TextSpan(
              text: "• ${child.text.trim()}\n",
              style: const TextStyle(fontSize: 14),
            ),
          );
          continue;
        }

        spans.add(TextSpan(
          text: child.text,
          style: style,
        ));
      } else if (child is dom.Text) {
        spans.add(TextSpan(text: child.text));
      }
    }

    return TextSpan(children: spans, style: const TextStyle(fontSize: 14, color: Colors.black));
  }
}
