from django.urls import path
from .views import *
from .auth_views import *
from rest_framework_jwt.views import obtain_jwt_token, refresh_jwt_token, verify_jwt_token

urlpatterns = [
    path('token/', obtain_jwt_token, name='token_obtain'),  # Get Token
    path('token/refresh/', refresh_jwt_token, name='token_refresh'),  # Refresh Token
    path('token/verify/', verify_jwt_token, name='token_verify'),  # Verify Token
    path('protected_view/', protected_view, name='protected_view'),
    path('temples/', temple_list, name='temple-list-api'),
    path('temple-detail/', temple_detail_api, name='temple-detail-api'),
    path('trip-detail/', trip_detail_api, name='trip-detail-api'),
    path('trips/', trips_list, name='trip-list-api'),
    path('home_page/', home_page_data, name='home_page_data'),
    path('booking/', booking_confirmation, name='booking-confirmation-api'),
    path('registration/', registration, name='registration'),
    path('register/', RegisterView.as_view(), name='register'),
    path('verify-otp/', OTPVerifyView.as_view(), name='verify-otp'),
    path('subscribe-member/', subscribe_member, name='subscribe-member'),
    path("clubs/", club_list_api, name="club_list_api"),
    path('club-detail/', get_club_details, name='club-detail-api'),
    path('rituals/', rituals, name='rituals-list'), 
    path('temples_rituals/<int:temple_id>/', temple_rituals, name='temple_rituals-list'), 
    path('rituals-detail/', ritual_detail_api, name='ritual-detail-api'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('profile/', get_profile, name='get_profile'),
    path('profile/update/', update_profile, name='update_profile'),
    path('profile/update-image/', update_profile_image, name='update_profile_image'),
    path('my_trips/', get_user_trip_bookings, name='create_trip_booking'),
    path('send-otp-reset-password/', SendOTPView.as_view(), name='send_otp_reset_password'),
    path('verify-otp-reset-password/', VerifyOTPView.as_view(), name='verify_otp_reset_password'),
    path('reset-password/', ResetPasswordView.as_view(), name='reset-password'),
    
]