import random
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from rest_framework import status, views
from rest_framework.response import Response
from rest_framework_jwt.settings import api_settings
from apps.pages.models import SmtUsers
from rest_framework.permissions import IsAuthenticated,AllowAny
from .serializers import RegisterSerializer, OTPVerifySerializer ,SmtUsersSerializer,SendOTPSerializer,VerifyOTPSerializer,ResetPasswordSerializer
from django.db import transaction
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, authentication_classes, permission_classes
import json
from django.core.mail import send_mail
from django.utils.timezone import now
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.contrib.auth import get_user_model

# Get JWT settings
jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER

class RegisterView(views.APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            mobile = serializer.validated_data['mobile']
            email = serializer.validated_data['email']

            # Check if user already exists
            # if SmtUsers.objects.filter(mobile=mobile).exists():
            #     return Response({"error": "User with this mobile already exists"}, status=status.HTTP_400_BAD_REQUEST)

            # Generate OTP
            otp = "123456"  # Hardcoded OTP for now

            # Save user data temporarily in SmtUsers
            user = SmtUsers.objects.create(
                name=serializer.validated_data['name'],
                mobile=mobile,
                email=email,
                city=serializer.validated_data['city'],
                password=make_password(serializer.validated_data['password']),
                mobile_verified_status=False,
                mobile_otp=otp  # Store OTP temporarily
            )

            return Response({"message": "OTP sent successfully", "otp": otp}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([AllowAny])  # Allow all users (unauthenticated)
@csrf_exempt
def registration(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)

    try:
        data = request.data  # Parse JSON from raw body
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON format"}, status=400)

    
    # Extract values from JSON
    name =data.get("name")
    city = data.get("city")
    password = data.get("password")
    mobile = data.get("mobile")
    email = data.get("email")

    # Validate required fields
    if not all([name, mobile, password]):
        return Response({"error": f"Missing required fields (name, mobile, password) {name} {mobile} {password} {str(data)}"}, status=400)

    # Check if mobile already exists
    if SmtUsers.objects.filter(mobile=mobile).exists():
        return Response({"error": "Mobile number already registered"}, status=400)

    try:
        with transaction.atomic():
            # Ensure the username is unique
            if User.objects.filter(username=mobile).exists():
                return JsonResponse({"error": "Mobile number already registered"}, status=400)

            # Create User
            user = User.objects.create_user(
                username=mobile,  # Unique username
                password=password,  # This will be hashed automatically
                email=email
            )

            # Create SmtUsers entry linked to User ID
            otp = "123456"  # Hardcoded OTP for now

            smt_user = SmtUsers.objects.create(
                user_id=user.id,
                name=name,
                email=email,
                mobile=mobile,
                password=make_password(password),  # This should ideally not be stored here
                city=city,
                mobile_verified_status=False,
                mobile_otp=otp,
                login_history=[{"action": "registration", "timestamp": now().isoformat()}]
            )

            # Send email notification if email exists
            mail_res_text = ''
            if email:
                try:
                    subject = "New Registration"
                    message = f"""
                    Dear {name},

                    Thank you for the registration.

                    Best Regards,
                    Sarvatirthamayi
                    """

                    send_mail(
                        subject,
                        message,
                        "hellojarvin@gmail.com",  # Replace with your sender email
                        [email],
                        fail_silently=False,
                    )

                    mail_res_text = "New User Registration email sent successfully!"

                except Exception as e:
                    mail_res_text = f"Email sending failed: {str(e)}"

            return Response({"message": "OTP sent successfully", "otp": otp}, status=status.HTTP_201_CREATED)
                    
    except Exception as e:
        import traceback
        return JsonResponse({"error": f"Failed to create user: {str(e)}", "trace": traceback.format_exc()}, status=500)

    return JsonResponse({
        "message": "New Registration is Successful",
        "email_status": mail_res_text
    }, status=201)

class OTPVerifyView(views.APIView):
    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        if serializer.is_valid():
            mobile = serializer.validated_data['mobile']
            otp = serializer.validated_data['otp']

            try:
                user = SmtUsers.objects.get(mobile=mobile)
            except SmtUsers.DoesNotExist:
                return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

            if user.mobile_otp == otp:
                # Update user verification status
                user.mobile_verified_status = True
                user.save()

                # Create Django User model entry (without admin privilege)
                django_user, created = User.objects.get_or_create(
                    username=mobile,
                    defaults={
                        "first_name": user.name,
                        "email": user.email,
                    },
                )

                # Generate JWT token
                payload = jwt_payload_handler(django_user)
                token = jwt_encode_handler(payload)

                return Response({
                    "message": "Registration successful",
                    "token": token
                })

            return Response({"error": "Invalid OTP"}, status=status.HTTP_400_BAD_REQUEST)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_profile(request):
    try:
        # Fetch user details from SmtUsers model using user_id
        user = SmtUsers.objects.filter(user_id=request.user.id).first()

        if not user:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        # Serialize the user data
        serializer = SmtUsersSerializer(user)

        return Response(serializer.data, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def update_profile(request):
    user = request.user
    user_id=request.user.id
    # Assuming you have a OneToOne relation like user.smtusers
    try:
        smt_user = SmtUsers.objects.filter(user_id=user_id).first() # or whatever your related name is
    except:
        return Response({"error": "Profile not found"}, status=status.HTTP_404_NOT_FOUND)

    serializer = SmtUsersSerializer(smt_user, data=request.data, partial=True)  # Allow partial updates
    if serializer.is_valid():
        serializer.save(user_id=user_id)
        return Response(serializer.data, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_profile_image(request):
    user = request.user
    if 'profile_image' in request.FILES:
        image = request.FILES['profile_image']
        file_path = f'profile_images/{user.id}/{image.name}'
        default_storage.save(file_path, ContentFile(image.read()))
        user.profile_image = file_path
        user.save()
        return Response({"message": "Profile image updated", "image_url": user.profile_image}, status=status.HTTP_200_OK)
    return Response({"error": "No image provided"}, status=status.HTTP_400_BAD_REQUEST)


class SendOTPView(views.APIView):
    def post(self, request):
        serializer = SendOTPSerializer(data=request.data)
        if serializer.is_valid():
            mobile = serializer.validated_data['mobile']
            
            # Fetch the user
            user = SmtUsers.objects.filter(mobile=mobile).first()

            # Set default OTP
            otp = "123456"

            # Store OTP in the user model (optional)
            user.mobile_otp = otp
            user.save()

            # Send OTP (You can integrate Twilio or other SMS services here)
            # For now, just returning the OTP in response
            return Response({"message": "OTP sent successfully", "otp": otp}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class VerifyOTPView(views.APIView):
    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        if serializer.is_valid():
            mobile = serializer.validated_data['mobile']
            
            # OTP is valid, fetch the user
            user = SmtUsers.objects.filter(mobile=mobile).first()

            # Reset OTP after successful verification (optional)
            user.mobile_otp = None
            user.save() 

            return Response({"message": "OTP verified successfully"}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

User = get_user_model()

class ResetPasswordView(views.APIView):
    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        if serializer.is_valid():
            mobile = serializer.validated_data['mobile']
            serializer.save()
            return Response({"message": "Password reset successful."}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


