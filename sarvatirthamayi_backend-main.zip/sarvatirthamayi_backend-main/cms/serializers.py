
from rest_framework import serializers
from django.conf import settings
from apps.pages.models import *
from apps.clubs.models import * 
from bson import Decimal128
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password

User = get_user_model()

class LatestActivitiesSerializer(serializers.ModelSerializer):
    image = serializers.SerializerMethodField()

    class Meta:
        model = LatestActivities
        fields = ["id", "title", "image", "status"]

    def get_image(self, obj):
        request = self.context.get("request")
        if obj.image:
            return request.build_absolute_uri(obj.image.url)
        return None


class TripsSerializer(serializers.ModelSerializer):
    thumbnail_image = serializers.SerializerMethodField()
    price = serializers.SerializerMethodField()

    class Meta:
        model = Trips
        fields = ["id", "trip_title", "thumbnail_image", "status","price"]

    def get_price(self, obj):
        if isinstance(obj.price, Decimal128):
            return int(obj.price.to_decimal())
        return float(obj.price)  
    
    def get_thumbnail_image(self, obj):
        request = self.context.get("request")
        if obj.thumbnail_image:
            return request.build_absolute_uri(obj.thumbnail_image.url)
        return None


class TemplesSerializer(serializers.ModelSerializer):
    icon_image = serializers.SerializerMethodField()

    class Meta:
        model = Temples
        fields = ["id", "temple_name", "icon_image", "short_description", "status","temple_state","diety","type_of_temple"]

    def get_icon_image(self, obj):
        request = self.context.get("request")
        if obj.icon_image:
            return request.build_absolute_uri(obj.icon_image.url)
        return None

class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmtUsers
        fields = ['name', 'mobile', 'email', 'city','password']

class OTPVerifySerializer(serializers.Serializer):
    mobile = serializers.CharField(max_length=15)
    otp = serializers.CharField(max_length=6)

class ClubMemberSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClubMember
        fields = ["name", "email", "phone", "club","joined_date","status"]
        
class ClubSerializer(serializers.ModelSerializer):
    club_type_display = serializers.CharField(source='get_club_type_display', read_only=True)
    club_status_display = serializers.CharField(source='get_club_status_display', read_only=True)
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = Club
        fields = [
            "id", "name", "price", "description", "image_url", "benefits", "club_type", "club_type_display",
            "max_members", "club_status", "club_status_display", "timestamp"
        ]

    def get_image_url(self, obj):
        request = self.context.get("request")
        if obj.image:
            return request.build_absolute_uri(obj.image.url)
        return None
    
class RitualsImagesSerializer(serializers.ModelSerializer):
    ritual_image = serializers.SerializerMethodField()
    class Meta:
        model = RitualsImages
        fields = ['id', 'image_caption', 'ritual_image']
    
    def get_ritual_image(self, obj):
        request = self.context.get("request")
        if obj.ritual_image:  # Check if image exists
            if request is not None:
                return request.build_absolute_uri(obj.ritual_image.url)
            return f"{settings.MEDIA_URL}{obj.ritual_image.url}"
        return None  # Return None if no image is available



class RitualsLabelsSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = RitualsLabels
        fields = ['id', 'title', 'image_url', 'status', 'timestamp']

    def get_image_url(self, obj):
        request = self.context.get("request")  # Get request context
        if obj.image:
            return request.build_absolute_uri(obj.image.url) if request else obj.image.url
        return None
    
class RitualsLabelsSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = RitualsLabels
        fields = ['id', 'title', 'image_url', 'status', 'timestamp']

    def get_image_url(self, obj):
        request = self.context.get("request")  # Get request context
        if obj.image:
            return request.build_absolute_uri(obj.image.url) if request else obj.image.url
        return None
    
class RitualsSerializer(serializers.ModelSerializer):
    ritual_images = serializers.SerializerMethodField()
    temple_details = serializers.SerializerMethodField()
    ritual_label_details = serializers.SerializerMethodField()

    class Meta:
        model = Rituals
        fields = ['id', 'temple_id', 'temple_details','ritual_label_details', 'rituals_label_id','ritual_category', 'ritual_type', 'ritual_price', 'ritual_images','ritual_benefits','ritual_procedure','ritual_prasadham_or_giveback','ritual_duration','ritual_perform_time','ritual_frequency','ritual_days']

    def get_ritual_images(self, obj):
        request = self.context.get("request")  # Pass request context
        images = RitualsImages.objects.filter(rituals_id=obj.id)
        return RitualsImagesSerializer(images, many=True, context={"request": request}).data

    def get_temple_details(self, obj):
        request = self.context.get("request")  # Get request context

        try:
            temple = Temples.objects.get(id=obj.temple_id)
            return TemplesSerializer(temple, context={"request": request}).data
        except Temples.DoesNotExist:
            return None
        
    def get_ritual_label_details(self, obj):
        request = self.context.get("request")  # Get request context

        try:
            ritual_label = RitualsLabels.objects.get(id=obj.rituals_label_id)  
            return RitualsLabelsSerializer(ritual_label, context={"request": request}).data  
        except RitualsLabels.DoesNotExist:
            return None


class RitualsDetailSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField()
    temple_details = serializers.SerializerMethodField()

    class Meta:
        model = Rituals
        fields = [
            'id', 'temple_id', 'rituals_label_id', 'ritual_type', 'ritual_status',
            'ritual_price', 'ritual_benefits', 'ritual_procedure',
            'ritual_prasadham_or_giveback', 'ritual_duration',
            'ritual_perform_time', 'ritual_updated_on', 'images'
        ]

    def get_images(self, obj):
        images = RitualsImages.objects.filter(rituals_id=obj.id)
        return RitualsImagesSerializer(images, many=True).data
    
    def get_temple_details(self, obj):
        try:
            temple = Temples.objects.get(id=obj.temple_id)
            return TemplesSerializer(temple).data
        except Temples.DoesNotExist:
            return None

class SmtUsersSerializer(serializers.ModelSerializer):
    profile = serializers.SerializerMethodField()
    class Meta:
        model = SmtUsers
        fields = ['id', 'name', 'email', 'mobile', 'city', 'profile','user_id']
    
    def get_profile(self, obj):
        request = self.context.get("request")  # Get request context
        if obj.profile:
            return request.build_absolute_uri(obj.profile.url) if request else obj.profile.url
        return None
    
class SendOTPSerializer(serializers.Serializer):
    mobile = serializers.CharField()

    def validate_mobile(self, value):
        if not SmtUsers.objects.filter(mobile=value).exists():
            raise serializers.ValidationError("User with this mobile number does not exist.")
        return value

class VerifyOTPSerializer(serializers.Serializer):
    mobile = serializers.CharField()
    otp = serializers.CharField(max_length=6)

    def validate(self, data):
        mobile = data.get('mobile')
        otp = data.get('otp')

        # Check if user exists
        try:
            user = SmtUsers.objects.get(mobile=mobile)
        except SmtUsers.DoesNotExist:
            raise serializers.ValidationError("User with this mobile number does not exist.")

        # Check if OTP matches
        if user.mobile_otp != otp:
            raise serializers.ValidationError("Invalid OTP.")

        return data

class TripBookingConfirmationSerializer(serializers.ModelSerializer):
    trip_details = serializers.SerializerMethodField()

    class Meta:
        model = TripBookingConfirmation
        fields = '__all__'  # includes all model fields + trip_details

    def get_trip_details(self, obj):
        try:
            trip = Trips.objects.get(id=obj.trip_id)
            context = {'request': self.context.get('request')}
            return TripsSerializer(trip, context=context).data
        except Trips.DoesNotExist:
            return None

class ResetPasswordSerializer(serializers.Serializer):
    mobile = serializers.CharField()
    new_password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)

    def validate(self, data):
        if data['new_password'] != data['confirm_password']:
            raise serializers.ValidationError("Passwords do not match.")
        return data

    def save(self):
        mobile = self.validated_data['mobile']
        password = self.validated_data['new_password']

        # Get smt_user record
        smt_user = SmtUsers.objects.filter(mobile=mobile).first()
        if not smt_user:
            raise serializers.ValidationError("SmtUser with this mobile does not exist.")

        # Get linked User model using smt_user.user_id
        try:
            user = User.objects.get(id=smt_user.user_id)
            user.set_password(password)
            user.save()
        except User.DoesNotExist:
            raise serializers.ValidationError("Linked User not found.")

        # Update SmtUsers model password
        smt_user.password = make_password(password)
        smt_user.save()

        return user

