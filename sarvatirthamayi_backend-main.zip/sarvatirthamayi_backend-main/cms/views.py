from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated,AllowAny
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from django.http import JsonResponse
from apps.pages.models import *
from apps.clubs.models import *
from django.core.serializers import serialize
import json
import requests
from django.core.mail import send_mail
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from .serializers import *
from django.contrib.auth import logout
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token
from rest_framework_jwt.utils import jwt_encode_handler, jwt_payload_handler
from django.db import transaction
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from django.utils import timezone
from datetime import date
from django.db.models import Count

#request test with token
@api_view(["GET"])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def home_page_data(request):
    latest_activities = LatestActivities.objects.filter(status="active").order_by("-id")[:10]  
    popular_trips = Trips.objects.filter(status="active")[:10]  
    temples = Temples.objects.filter(status="active")[:10]  

    response_data = {
        "latest_activities": LatestActivitiesSerializer(latest_activities, many=True, context={"request": request}).data,
        "popular_trips": TripsSerializer(popular_trips, many=True, context={"request": request}).data,
        "temples": TemplesSerializer(temples, many=True, context={"request": request}).data,
    }
    return Response(response_data)
    

@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def protected_view(request):
    print("Authenticated user:", request.user)  # Should print a User object if authenticated
    #return Response({"message": "You have access!"})
    return JsonResponse({"message": "You have access!"})

@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def temple_list(request):
    # Fetch all temples
    temples = Temples.objects.all()

    temple_data = []
    for temple in temples:
        # Get rituals related to this temple
        rituals = Rituals.objects.filter(temple_id=temple.id)

        # Construct rituals data
        rituals_data = []
        for ritual in rituals:
            # Get the related ritual label
            ritual_label = RitualsLabels.objects.filter(id=ritual.rituals_label_id).first()
            ritual_label_data = {
                "id": ritual_label.id,
                "title": ritual_label.title,
                "image": request.build_absolute_uri(ritual_label.image.url) if ritual_label and ritual_label.image else None,
                "status": ritual_label.status,
                "timestamp": ritual_label.timestamp
            } if ritual_label else {}

            # Get ritual images
            ritual_images = RitualsImages.objects.filter(rituals_id=ritual.id)
            ritual_images_data = [
                {
                    "id": image.id,
                    "caption": image.image_caption,
                    "image_url": request.build_absolute_uri(image.ritual_image.url) if image.ritual_image else None,
                    "status": image.ritual_image_status
                }
                for image in ritual_images
            ]

            # Append ritual data
            rituals_data.append({
                "id": ritual.id,
                "ritual_label": ritual_label_data,
                "ritual_type": ritual.ritual_type,
                "ritual_status": ritual.ritual_status,
                "ritual_price": str(ritual.ritual_price) if ritual.ritual_price else None,
                "ritual_benefits": ritual.ritual_benefits,
                "ritual_procedure": ritual.ritual_procedure,
                "ritual_duration": ritual.ritual_duration,
                "ritual_perform_time": ritual.ritual_perform_time,
                "ritual_updated_by": ritual.ritual_updated_by,
                "ritual_updated_on": ritual.ritual_updated_on,
                "ritual_images": ritual_images_data
            })

        # Append temple data
        temple_data.append({
            "id": temple.id,
            "title": temple.temple_name,
            "icon_image": request.build_absolute_uri(temple.icon_image.url) if temple.icon_image else None,
            "rituals": rituals_data  # Add rituals related to the temple
        })

    return JsonResponse({"temples": temple_data}, safe=False)


@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def temple_detail_api(request):
    """Fetch templeDetail based on temple_id"""
    
    temple_id = request.GET.get('temple_id')  # Get temple_id from query params
    
    if not temple_id:
        return JsonResponse({"error": "temple_id is required"}, status=400)

    main_temple_detail = Temples.objects.filter(id=temple_id).first()

    temple_detail = TempleDetail.objects.filter(temple_id=temple_id).first()

    if not temple_detail:
        return JsonResponse({"error": "TempleDetail not found"}, status=404)

    temple_detail_items = TempleDetailItem.objects.filter(temple_id=temple_id)

    if not temple_detail_items.exists():
        return Response({"error": "No TempleDetailItems found"}, status=404)

    response_data = json.loads(serialize('json', temple_detail_items, fields=('id', 'list_title', 'list_description')))

    # Extract only required fields
    formatted_data = [
        {
            "id": item["pk"],
            "list_title": item["fields"]["list_title"],
            "list_description": item["fields"]["list_description"]
        }
        for item in response_data
    ]
    # Preparing JSON response
    response_data = {
        "temple_id": temple_detail.temple_id,
        "temple_title": main_temple_detail.temple_name,
        "short_description": temple_detail.short_description,
        "highlights": temple_detail.highlights,
        "detail_image": request.build_absolute_uri(temple_detail.detail_image.url) if temple_detail.detail_image else None,
        "item_list":formatted_data
    }

    return JsonResponse({'temple_details': response_data})

@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def trips_list(request):
    # Fetch all temple objects from the database
    trips = Trips.objects.all()
    
    # Prepare the response data in the format you need (usually as a list of dicts)
    trips_data = [{'id': trip.id, 'title': trip.trip_title,'thumbnail_image':request.build_absolute_uri(trip.thumbnail_image.url) if trip.thumbnail_image else None ,'status':trip.status,'popular_status':trip.popular_status,'type_of_trip':trip.type_of_trip,'price':trip.price} for trip in trips]
    
    trips_data=TripsSerializer(trips, many=True, context={"request": request}).data

    # Return a JsonResponse, which automatically sets Content-Type to application/json
    return JsonResponse({'trips': trips_data})

@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def trip_detail_api(request):
    """Fetch tripDetail based on trip_id"""

    trip_id = request.GET.get('trip_id')  # Get trip_id from query params

    if not trip_id:
        return JsonResponse({"error": "trip_id is required"}, status=400)

    main_trip_detail = Trips.objects.filter(id=trip_id).first()
    trip_detail = TripsDetails.objects.filter(trip_id=trip_id).first()

    if not trip_detail:
        return JsonResponse({"error": "TripDetail not found"}, status=404)

    trip_detail_items = TripsDetailItem.objects.filter(trip_id=trip_id)

    if not trip_detail_items.exists():
        return JsonResponse({"error": "No TripDetailItems found"}, status=404)

    response_data = json.loads(serialize('json', trip_detail_items, fields=('id', 'list_title', 'list_description')))

    formatted_data = [
        {
            "id": item["pk"],
            "list_title": item["fields"]["list_title"],
            "list_description": item["fields"]["list_description"]
        }
        for item in response_data
    ]

    price = 0
    if isinstance(main_trip_detail.price, Decimal128):
        price = int(main_trip_detail.price.to_decimal())

    # Count how many times this trip was booked
    booking_count = TripBookingConfirmation.objects.filter(trip_id=trip_id).count()

    response_data = {
        "trip_id": trip_detail.trip_id,
        "trip_title": main_trip_detail.trip_title,
        "price": price,
        "image_caption": trip_detail.image_caption,
        "short_description": trip_detail.short_description,
        "trip_duration": trip_detail.trip_duration,
        "no_of_temples": trip_detail.no_of_temples,
        "temple_names": trip_detail.temple_names or [],
        "trip_description": trip_detail.trip_description,
        "facilities_covered": trip_detail.facilities_covered,
        "trip_assembly_point": trip_detail.trip_assembly_point,
        "min_group_size": trip_detail.min_group_size,
        "max_group_size": trip_detail.max_group_size,
        "banner_image": request.build_absolute_uri(trip_detail.banner_image.url) if trip_detail.banner_image else None,
        "item_list": formatted_data,
        "total_bookings": booking_count  # <== NEW FIELD
    }

    return JsonResponse({'trip_details': response_data})


@api_view(['POST'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
@csrf_exempt
def booking_confirmation(request):
    """Handles booking confirmation requests."""
    
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)

    try:
        data = json.loads(request.body.decode("utf-8"))  # Parse JSON from raw body
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON format"}, status=400)

    # Extract values from JSON
    name = data.get("name")
    trip_id = data.get("trip_id")
    trip_title = data.get("trip_title")
    mobile = data.get("mobile")
    email = data.get("email")
    start_date = data.get("start_date")
    no_of_days = data.get("no_of_days")
    no_of_devotees = data.get("no_of_devotees")
    type_of_trip = data.get("type_of_trip")
    trip_price = float(data.get("trip_price"))
    user_id = request.user.id

    if not all([name, mobile, start_date]):
        return JsonResponse({"error": "Missing required fields"}, status=400)

    # Save the booking confirmation
    booking = TripBookingConfirmation.objects.create(
        trip_id=trip_id,
        user_id=user_id,
        trip_title=trip_title,
        name=name, 
        email=email,
        mobile=mobile,
        start_date=start_date,
        no_of_days=no_of_days,
        no_of_devotees=no_of_devotees,
        type_of_trip=type_of_trip,
        trip_price=trip_price
    )

    #message to whatsapp
    
    #template_name='hello_globe'
    #template_name='hello_world'
    #template_name='booking_confirmation'
    #template_name='yogaksema_booking_confirmation'
    template_name='sarvatirthamayi_trip_booking_confirmation'
    
    if len(mobile) == 10 and mobile.isdigit():
        mobile = "91" + mobile  
    phone_number=mobile
    trip=trip_title
    payload = {
        "messaging_product": "whatsapp",
        "to": str(phone_number),
        "type": "template",
        "template": {
            "name": str(template_name),
            "language":{
                "code":"en"
            },
            "components": [
            {
                "type": "body",
                "parameters": [
                    {"type": "text", "text":str(name)},
                    {"type": "text", "text": str(start_date)},
                    {"type":"text","text":str(trip)}
                    
                ]
            }
        ]
        }
    }

    message_res=''
    try:
        token='EAAL7v9krplEBO7Efx8LOnl4Antl0gWgOtzTUi28INCyAoiia2wIDZBIa4qZCDpdYZApKHmtuOkgXdMe4IrYZCGRSCe2NZA9m2zs4U2iEebbsi14BBTPpKUthgr51iJmo7PPDW7xuX7amLZBVeYhaTGnloEiYupejhmiFm0JPud6j0e2J2NOdX7yErfqxjmfsbG6AZDZD'
        phonenumber_id='371941399332594'

        data_json = json.dumps(payload)
        url = 'https://graph.facebook.com/v20.0/'+str(phonenumber_id)+'/messages'
        headers = {'content-type': 'application/json',"Accept": "application/json", 'Accept-Charset': 'UTF-8','Authorization':'Bearer '+str(token)}
        r = requests.post(url, data=data_json, headers=headers)
        res_obj= json.loads(r.text)

        print("URL:", url)  # Debugging
        print("Headers:", headers)
        print("Response:", r.status_code, r.text)
        
        if r.status_code == 200:
            message_res='Message has been sent successfully'
        else:
            message_res='Message is not sent. Status code is '+str(r.status_code)+'||'+str(url)+'||'+r.reason
    except:
        res_obj= 'error in sending whatsapp messages'
        message_res='Error in message sending'
    
    #message to whatsapp
    if email:
        try:
            subject = "Booking Confirmation ✅"
            message = f"""
            Dear {name},

            Your trip to {trip} has been successfully booked! 🎉
            
            📅 Start Date: {start_date}
            📍 Location: No. 10, 2nd Cross Rd, Coffee Board Layout, Hebbal Kempapura, Bengaluru, Karnataka 560024

            📞 Contact:  +91 70705 90505

            We are excited to host you on this spiritual journey! May this trip bring you peace and divine blessings. 🙏✨

            If you have any questions, feel free to reach out.

            Safe travels! 🚀
            
            Best Regards,
            Sarvatirtamayi
            """

            send_mail(
                subject,
                message,
                "hellojarvin@gmail.com",  # Replace with your sender email
                [email],
                fail_silently=False,
            )

            mail_res_text = "Trips Booking confirmation email sent successfully!"

        except Exception as e:
            mail_res_text = f"Email sending failed: {str(e)}"

    else:
        mail_res_text = ''

    return JsonResponse({
        "message": "Booking confirmed successfully!",
        "booking_id": booking.id,
        "name": booking.name,
        "mobile": booking.mobile,
        "start_date": booking.start_date,
        "no_of_days": booking.no_of_days,
        "no_of_devotees": booking.no_of_devotees,
        "type_of_trip": booking.type_of_trip,
        "Whatsapp_message_status":message_res,
        "email_status":mail_res_text
    }, status=201)


@api_view(["POST"])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def subscribe_member(request):
    user_id = request.user.id
    data = request.data
    club_id = data.get('club')
    renewal = data.get('renewal', 0)

    try:
        member = ClubMember.objects.get(user_id=user_id, club=club_id)
        if renewal:
            # Perform renewal update
            today = date.today()
            renewal_entry = {
                "date": today.strftime("%Y-%m-%d"),
                "price": data.get("price", 0)
            }
            # Update history & last_renewal_date
            member.renewal_history.append(renewal_entry)
            member.last_renewal_date = today
            member.save()
            return Response({"message": "Renewal successful!", "data": {
                "name": member.name,
                "email": member.email,
                "last_renewal_date": member.last_renewal_date,
                "renewal_history": member.renewal_history
            }}, status=status.HTTP_200_OK)
        else:
            return Response({"message": "Already subscribed to this club!"}, status=status.HTTP_400_BAD_REQUEST)

    except ClubMember.DoesNotExist:
        # New Subscription Flow
        serializer = ClubMemberSerializer(data=data)
        if serializer.is_valid():
            serializer.save(user_id=user_id)
            return Response({"message": "Successfully subscribed as a club member!", "data": serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["GET"])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def club_list_api(request):
    user = request.user
    clubs = Club.objects.filter(club_status="active")
    result = []

    for club in clubs:
        subscription_status = "not_applicable"
        expiry_date = None
        notification = False
        days_left = None
        expiry_status = None

        if not user.is_superuser:
            subscription = ClubMember.objects.filter(user_id=user.id, club=club.id).first()

            if subscription:
                if subscription.status == "pending":
                    subscription_status = "requested"
                elif subscription.status == "active":
                    subscription_status = "subscribed"

                    # Use last_renewal_date if available, fallback to joined_date
                    base_date = subscription.last_renewal_date or subscription.joined_date
                    expiry_date = base_date + relativedelta(years=1)
                    today = timezone.now().date()
                    days_left = (expiry_date - today).days

                    # Determine expiry status and notification flag
                    if today >= expiry_date:
                        expiry_status = "expired"
                        days_left = 0
                    elif today >= expiry_date - relativedelta(days=30):
                        expiry_status = "expiring_soon"
                        notification = True
                    else:
                        expiry_status = "valid"
                else:
                    subscription_status = "not_subscribed"
            else:
                subscription_status = "not_subscribed"

        club_data = ClubSerializer(club, context={"request": request}).data
        club_data.update({
            "subscription_status": subscription_status,
            "expiry_date": expiry_date,
            "notification": notification,
            "days_left": days_left,
            "expiry_status": expiry_status
        })
        result.append(club_data)

    return Response({"status": "success", "user_id": user.id, "clubs": result}, status=status.HTTP_200_OK)


@api_view(["GET"])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def get_club_details(request):
    try:
        club_id = request.GET.get('club_id')
        user = request.user

        if not club_id:
            return Response({"status": "error", "message": "club_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        club = Club.objects.get(id=club_id)
        serializer = ClubSerializer(club, context={"request": request})

        # Default subscription info for this club
        subscription_info = {
            "status": "not_applicable" if user.is_superuser else "not_subscribed"
        }

        # Global flag to check if the user has any subscription in any club
        has_any_subscription = False

        if not user.is_superuser:
            # Check if the user has any active or pending subscription in ANY club
            any_member = ClubMember.objects.filter(
                user_id=user.id,
                status__in=['active', 'pending']
            ).exists()
            has_any_subscription = any_member

            # Fetch subscription info specific to this club
            member = ClubMember.objects.filter(user_id=user.id, club=club_id).order_by('-joined_date').first()
            if member:
                if member.status == "pending":
                    subscription_info["status"] = "requested"
                elif member.status == "active":
                    base_date = member.last_renewal_date or member.joined_date
                    expiry_date = base_date + timedelta(days=365)
                    today = timezone.now().date()
                    notification_status = "no"
                    expiry_status = "valid"
                    left_days = None

                    if today >= expiry_date:
                        expiry_status = "expired"
                        left_days = 0
                    elif today >= expiry_date - timedelta(days=30):
                        expiry_status = "expiring_soon"
                        notification_status = "yes"
                        left_days = (expiry_date - today).days
                    else:
                        expiry_status = "valid"
                        left_days = (expiry_date - today).days

                    subscription_info.update({
                        "status": "subscribed",
                        "joined_date": member.joined_date,
                        "last_renewal_date": member.last_renewal_date,
                        "expiry_date": expiry_date,
                        "notification_status": notification_status,
                        "left_days": left_days,
                        "expiry_status": expiry_status
                    })
                else:
                    subscription_info["status"] = "not_subscribed"

        return Response({
            "status": "success",
            "subscription": subscription_info,
            "has_any_subscription": has_any_subscription,
            "club": serializer.data,
        }, status=status.HTTP_200_OK)

    except Club.DoesNotExist:
        return Response({"status": "error", "message": "Club not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def rituals(request):

    rituals_list = Rituals.objects.all()
    serializer = RitualsSerializer(rituals_list, many=True, context={'request': request})
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def temple_rituals(request, temple_id):

    rituals_list = Rituals.objects.filter(temple_id=temple_id)
    serializer = RitualsSerializer(rituals_list, many=True, context={'request': request})
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def ritual_detail_api(request):

    ritual_id = request.GET.get("ritual_id")
    if not ritual_id:
        return Response({"error": "ritual_id is required"}, status=status.HTTP_400_BAD_REQUEST)
    try:
        ritual = Rituals.objects.get(id=ritual_id)
        serializer = RitualsDetailSerializer(ritual)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except Rituals.DoesNotExist:
        return Response({"error": "Ritual not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def logout_view(request):
    user = request.user
    smt_user = SmtUsers.objects.filter(user_id=user.id).first()
    
    if smt_user:
        smt_user.login_history.append({"action": "logout", "timestamp": now().isoformat()})
        smt_user.save()

    logout(request)  # Logs out the user and destroys the session
    return Response({"message": "Successfully logged out"}, status=200)

@api_view(['POST'])
@permission_classes([AllowAny])  # Allow login without authentication
def login_view(request):
    """
    Custom API to authenticate users using mobile number and password.
    Returns an access token upon successful login.
    """
    mobile_number = request.data.get("mobile_number")
    password = request.data.get("password")

    if not mobile_number or not password:
        return Response({"error": "Mobile number and password are required"}, status=400)

    # Authenticate user using mobile number
    user = authenticate(username=mobile_number, password=password)

    if user:

        smt_user = SmtUsers.objects.filter(mobile=mobile_number).first()
        if smt_user:
            smt_user.login_history.append({"action": "login", "timestamp": now().isoformat()})
            smt_user.save()

        payload = jwt_payload_handler(user)  # Generate JWT payload
        token = jwt_encode_handler(payload)  # Encode token
        return Response({
            "auth_token": token,
            "user_id": user.id,
            "mobile_number": user.username,  # Assuming mobile number is stored in `username`
            "name": smt_user.name, 
            "email": smt_user.email, 
            "mobile": smt_user.mobile 
        })
    else:
        return Response({"error": "Invalid credentials"}, status=401)

def update_login_history(user):
    user.login_history.append({"action": "login", "timestamp": now().isoformat()})
    user.save()

def update_logout_history(user):
    user.login_history.append({"action": "logout", "timestamp": now().isoformat()})
    user.save()


@api_view(['GET'])
@authentication_classes([JSONWebTokenAuthentication])
@permission_classes([IsAuthenticated])
def get_user_trip_bookings(request):
    user_id = request.user.id  # assuming you store user ID here from the token

    bookings = TripBookingConfirmation.objects.filter(user_id=user_id).order_by('-created_at')
    serializer = TripBookingConfirmationSerializer(bookings, many=True, context={'request': request})

    return Response({"data": serializer.data}, status=status.HTTP_200_OK)