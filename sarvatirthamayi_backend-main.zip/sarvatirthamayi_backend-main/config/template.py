# Template Settings
# ------------------------------------------------------------------------------


# Theme Variables
# ? Personalize template by changing theme variables (For ex: Name, URL Version etc...)
THEME_VARIABLES = {
    "creator_name": "Sarvatirthamayi",
    "creator_url": "#",
    "template_name": "Sarvatirthamayi",
    "template_suffix": "Sarvatirthamayi Admin Template",
    "template_version": "1.0.0",
    "template_free": True,
    "template_description": "Sarvatirthamayi admin dashboard.",
    "template_keyword": "django admin, dashboard",
    "facebook_url": "",
    "twitter_url": "",
    "github_url": "",
    "dribbble_url": "",
    "instagram_url": "",
    "license_url": "",
    "live_preview": "",
    "product_page": "",
    "support": "",
    "more_themes": "",
    "documentation": "",
    "changelog": "",
    "git_repository": "",
    "git_repo_access": "",
    "live_preview_free": "",
    "product_page_free": "",
}

# ! Don't change THEME_LAYOUT_DIR unless it's required
THEME_LAYOUT_DIR = "layout"