from django.conf import settings

def site_email(request):
    return {'site_email': 'example@gmail.com'}
    
def baseurl(request):
    """
    Return a BASE_URL template context for the current request.
    """
    if request.is_secure():
        scheme = 'https://'
    else:
        scheme = 'http://'
        
    #return {'BASE_URL': scheme + request.get_host()+"/crm",}
    
    final_url='http://' + request.get_host()
    return {'BASE_URL': final_url}
def my_setting(request):
    return {'MY_SETTING': settings}

def media_root(request):
    return {
        'MEDIA_ROOT': settings.MEDIA_ROOT,
    }
# Add the 'ENVIRONMENT' setting to the template context
def environment(request):
    return {'ENVIRONMENT': settings.ENVIRONMENT}    