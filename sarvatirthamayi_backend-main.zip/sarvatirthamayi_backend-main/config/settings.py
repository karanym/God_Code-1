
import json,re,os,time;
import random
import string
import datetime

from pathlib import Path
from dotenv import load_dotenv
from .template import  THEME_LAYOUT_DIR, THEME_VARIABLES

load_dotenv()  # take environment variables from .env.

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-3lsb$__=dx36yu1&e826db8%4u04may77$!ap9w91_49wp0g=3'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

MSG91_API_KEY = "your_api_key"
MSG91_SENDER_ID = "SENDERID"

EMAIL_HOST ="smtp.gmail.com";
EMAIL_HOST_USER ="hellojarvin@gmail.com";
EMAIL_HOST_PASSWORD ="fkenazlwvitfzplm";
EMAIL_PORT =587;
EMAIL_USE_TLS =True;
EMAIL_BACKEND ="django.core.mail.backends.smtp.EmailBackend";

CSRF_TRUSTED_ORIGINS = [
    'https://sarvatirthamayi.com/',  # Add your domain here
]

ALLOWED_HOSTS = ['*','localhost','127.0.0.1','https://sarvatirthamayi.com/']
SECURE_SSL_REDIRECT=False
#SESSION_COOKIE_SECURE=False
#CSRF_COOKIE_SECURE=False

ENVIRONMENT = os.environ.get("DJANGO_ENVIRONMENT", default="local")
local_or_live = "";
#local_or_live = "";
# Application definition
#LOGIN_URL='http://localhost:8000/backend_admin/'
#BASE_URL_SERVER='http://localhost:8000'

# Application definition
LOGIN_URL='http://127.0.0.1:8000'
BASE_URL_SERVER='http://127.0.0.1:8000'

'''LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django.db.backends': {
            'level': 'DEBUG',
            'handlers': ['console'],
        },
    },
}'''
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',
    'cms',
    'rest_framework',
    'rest_framework.authtoken',
     "apps.dashboards",

    "apps.layouts",

    "apps.pages",
    "apps.clubs",

    "apps.authentication",

    "apps.cards",

    "apps.ui",

    "apps.extended_ui",

    "apps.icons",

    "apps.forms",

    "apps.form_layouts",

    "apps.tables",
    "ajax_datatable"
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_jwt.authentication.JSONWebTokenAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
}

JWT_AUTH = {
    # Set token expiration to 100 years
    'JWT_EXPIRATION_DELTA': datetime.timedelta(days=365 * 100),
    'JWT_AUTH_HEADER_PREFIX': 'Bearer',  # This makes it expect "Bearer <token>" in the header
}


CORS_ORIGIN_ALLOW_ALL=True
MIDDLEWARE = [  
    "whitenoise.middleware.WhiteNoiseMiddleware",
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'apps.pages.middleware.DatabaseMiddleware'
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR,'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.media',
                'config.context_processors.media_root',
                'config.context_processors.site_email',
                'config.context_processors.baseurl',
                "config.context_processors.my_setting",
                "config.context_processors.environment",
                "apps.pages.context_processors.common_list",
            ],
             "libraries": {

                "theme": "web_project.template_tags.theme",

            },

            "builtins": [

                "django.templatetags.static",

                "web_project.template_tags.theme",
            ],
        },
    },
]
TEMPLATE_CONTEXT_PROCESSORS = (
    # default context processors for Django 1.4
    "django.contrib.auth.context_processors.auth",
    "django.core.context_processors.debug",
    "django.core.context_processors.i18n",
    "django.core.context_processors.media",
    "django.core.context_processors.static",
    "django.core.context_processors.tz",
    "django.contrib.messages.context_processors.messages",
    "django.contrib.messages.context_processors.baseurl",
    "django.contrib.auth.hashers"
)

WSGI_APPLICATION = 'config.wsgi.application'

SESSION_SAVE_EVERY_REQUEST =True
# Database
# https://docs.djangoproject.com/en/5.0/ref/settings/#databases

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#     }
# }
DATABASES = {
      'default': {
          'ENGINE': 'djongo',
          'NAME': 'sarvatirthamayi',
      }
}


# Password validation
# https://docs.djangoproject.com/en/5.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/5.0/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Asia/Kolkata'

USE_I18N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.0/howto/static-files/

STATIC_URL = '/static/'
STATICFILES_DIRS=[
    os.path.join(BASE_DIR,'static')
]
STATIC_ROOT=os.path.join(BASE_DIR,'assets')

# Default primary key field type
# https://docs.djangoproject.com/en/5.0/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

MEDIA_URL='/media/'
MEDIA_ROOT=os.path.join(BASE_DIR,'media')

FILESYSTEM_URL='/filesystem/'
FILESYSTEM_ROOT=os.path.join(BASE_DIR,'filesystem')


THEME_LAYOUT_DIR = THEME_LAYOUT_DIR
THEME_VARIABLES = THEME_VARIABLES

TWITTER_API_KEY = "h3NXsftLwziVHMot1y8iZOsPu"
TWITTER_API_SECRET = "0GOnpPQqEm83g98hGFu4LTPD3lkrfaHLT62XOu3iu9VZlo6NcG"
TWITTER_ACCESS_TOKEN = "1876501023499681792-M4SfYBJstgMkjIY2BBx5HqjSrDXU4q"
TWITTER_ACCESS_SECRET = "cMtPZw3AErohvCdmCEA4I5WOThNJyFRm8S56OI030MBJ8"

OPENAI_API_KEY = "sk-proj-f8ZSqhrtCDrlueWbmd3jT3BlbkFJAw2mH58FmNyuTx9Jx3Rh"


