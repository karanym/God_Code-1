from django.views.generic import TemplateView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from django.core.files.base import ContentFile, File

from .forms import clientform

from .models import clientData
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib.auth.hashers import *
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import EmailMessage

from .forms import ChangePasswordForm,clientform 
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin


import requests

import random
import time
import hashlib


class clientDataCreate(SuccessMessageMixin,CreateView):
    model = clientData
    fields='__all__' 
    success_url=reverse_lazy('pages-account-settings-connections')
    success_message = 'Admin has been added Successfully!'
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super(clientDataCreate, self).get_context_data(**kwargs))
        context["c_form"]= clientform() 
        if User.is_superuser:
            if(self.request.method=='POST'):

                username=self.request.POST['email']
                email=self.request.POST['email']
                #password=request.POST['password']#123456
                password='aA234567'
                
                first_name=self.request.POST['first_name']
                last_name=self.request.POST['last_name']
                company_name=self.request.POST.get('company_name', '')  
                email=self.request.POST['email']
                gstin=self.request.POST.get('gstin', '')  
                phone_number=self.request.POST['phone_number']
                address=self.request.POST['address']
                city=self.request.POST['city']
                state=self.request.POST['state']
                country=self.request.POST['country']
                pincode=self.request.POST.get('pincode',False)
                now=timezone.now() 
                profile_picture=self.request.FILES.get('profile_picture',False)

                c_form=clientform(self.request.POST,self.request.FILES)
                #if c_form.is_valid():
                if 1:
                    
                    user = User.objects.create_user(username=username, email=email, password=password)
                    user.first_name = self.request.POST['first_name']
                    user.last_name = self.request.POST['last_name']
                    user.is_staff = True
                    user.save()
                    
                    client_id=user.id
                    encoded_password=make_password(password)
                    
                    salt = "client_unique_id"
                    rand = random.randint(1, 1000000)
                    milliseconds = round(time.time() * 1000)
                    str_to_hash = f"{salt}{rand}{milliseconds}"
                    key = hashlib.md5(str_to_hash.encode()).hexdigest()
                    client_unique_id=key
    
                    form_d = clientData.objects.create(
    client_unique_id=client_unique_id,
    client_level='0',
    admin_username=username,
    admin_password=encoded_password,
    admin_type='admin',
    client_id=client_id,
    profile_picture=profile_picture,
    first_name=first_name,
    last_name=last_name,
    company_name=company_name,
    email=email,
    gstin=gstin,
    phone_number=phone_number,
    address=address,
    city=city,
    state=state,
    country=country,
    pincode=pincode,
    modified_at=now,
    client_active=True
)

                    context["c_form"]= clientform()
                    success_message = 'Admin has been added Successfully!'
                    messages.success(self.request,'Admin has been added Successfully!')  

                    mail = EmailMessage(
                        'Sarvatirthamayi - Account Created',
                        'Hey '+str(first_name)+' '+str(last_name)+',<br>'+
                        '<p> Your account is created in Sarvatirthamayi Adminpanel. Below are the credentials to login.</p>'+
                        'Your user name : <b>'+str(email)+'</b>'+
                        'Your password : <b>'+str(password)+'</b>'+
                        'Admin URL : <b>'+str(LOGIN_URL)+'</b>'
                        ,
                        settings.EMAIL_HOST_USER,
                        [email],
                    )
                    mail.fail_silently = True
                    mail.content_subtype = 'html'
                    mail.send()
                    
                
                else:

                    context["c_form"]= clientform(self.request.POST,self.request.FILES) 
                    error_message = 'Please fix the error before add Client'
                    messages.error(self.request,clientform.errors)  
                return context     
        else: 

            context["c_form"]= clientform() 
            return context
        return context
def is_client_mail_already_exists_createmode_fun(request):
    email = request.GET.get('email', '')
    count = clientData.objects.filter(email__iexact=email).count()
    if(count>0):
        return JsonResponse({'valid': False})
    else:
        return JsonResponse({'valid': True})

def is_client_mail_already_exists_editmode_fun(request):
    email = request.GET.get('email', '')
    client_id = request.GET.get('client_id', '')
    count = clientData.objects.filter(email__iexact=email).exclude(client_id=client_id).count()
    if(count>0):
        print("exists")
        return JsonResponse({'valid': False})
    else:
        print("notexists")
        return JsonResponse({'valid': True})

class clientDataUpdate(SuccessMessageMixin,UpdateView):
    model = clientData
    fields='__all__' 
    success_url=reverse_lazy('pages-account-settings-connections')
    success_message = 'Admin details has been updated successfully!'
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super(clientDataUpdate, self).get_context_data(**kwargs))
        context['id'] = self.object.pk
        form_data = clientData.objects.get(id=self.object.pk)
        modified_at=timezone.now()
        context['previous_profile_picture']=form_data.profile_picture.url
        #self.request.user.id#find either it is superadmin or Admin is updating
        context["c_form"]= clientform(initial={'client_id':form_data.client_id,'admin_username':form_data.admin_username,'admin_password':form_data.admin_password,"admin_type":"admin",'first_name': form_data.first_name,'last_name':form_data.last_name,'company_name':form_data.company_name,'email':form_data.email,'gstin':form_data.gstin,'phone_number':form_data.phone_number,'address':form_data.address,'city':form_data.city,'state':form_data.state,'country':form_data.country,'pincode':form_data.pincode,'modified_at':modified_at,'client_active':form_data.client_active})      
        return context

class clientDataUpdateProfile(SuccessMessageMixin,UpdateView):
    model = clientData
    fields='__all__' 
    success_url=reverse_lazy('pages-account-settings-profile')
    success_message = 'Profile details has been updated successfully!'
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super(clientDataUpdateProfile, self).get_context_data(**kwargs))
        if(self.request.method=='POST'):
            email = self.request.POST.get('email')  # Use .get() to handle missing keys gracefully
            first_name = self.request.POST.get('first_name')
            last_name = self.request.POST.get('last_name')
            user=User.objects.get(id=self.request.client_id)
            user.first_name = first_name
            user.last_name = last_name
            user.email = email
            user.save()

        context['id'] = self.object.pk
        form_data = clientData.objects.get(id=self.object.pk)
        modified_at=timezone.now()
        if form_data.profile_picture != 'False':
            context['previous_profile_picture']=form_data.profile_picture.url
        else:
            context['previous_profile_picture']='' 
        #self.request.user.id#find either it is superadmin or admin is updating
        
        context["c_form"]= clientform(initial={'client_id':form_data.client_id,'admin_username':form_data.admin_username,'admin_password':form_data.admin_password,"admin_type":"admin",'first_name': form_data.first_name,'last_name':form_data.last_name,'company_name':form_data.company_name,'email':form_data.email,'gstin':form_data.gstin,'phone_number':form_data.phone_number,'address':form_data.address,'city':form_data.city,'state':form_data.state,'country':form_data.country,'pincode':form_data.pincode,'modified_at':modified_at,'client_active':form_data.client_active})      

        return context

def update_client_status_active(request,client_id):
    form=clientData.objects.get(client_id=client_id)
    form.client_active=True
    form.save()

    form=User.objects.get(id=client_id)
    form.is_active=True
    form.save()

    messages.success(request,'Admin status has been changed successfully ')

    return redirect('pages-account-settings-connections')
    
def update_client_status_inactive(request,client_id):
    form=clientData.objects.get(client_id=client_id)
    form.client_active=False
    form.save()

    form=User.objects.get(id=client_id)
    form.is_active=False
    form.save()
    messages.success(request,'Admin status has been changed successfully ')
    return redirect('pages-account-settings-connections')

class ChangePasswordView(LoginRequiredMixin, TemplateView):
    template_name = 'pages_change_password.html'

    def get_context_data(self, **kwargs):
        #context = super().get_context_data(**kwargs)
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['form'] = ChangePasswordForm(user=self.request.user)
        context['message'] = "Please enter your old password and the new password."  # Example context data
        return context

    def post(self, request, *args, **kwargs):
        form = ChangePasswordForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important to keep the user logged in
            messages.success(request,message='New password has been updated successfully')
            return redirect('pages-change-password')  # Redirect to a success page
        else:
            messages.error(request,form.errors)
        #context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        return render(request, self.template_name,self.get_context_data(form=form))
