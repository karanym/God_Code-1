from django import forms
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError


class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)
    remember_me = forms.BooleanField(required=False)  # Remember Me checkbox

class ChangePasswordForm(SetPasswordForm):
    old_password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','required':True}), label="Old Password")
    
    def clean_old_password(self):
        old_password = self.cleaned_data.get('old_password')
        user = self.user

        if not user.check_password(old_password):
            raise ValidationError("The old password is incorrect.")
        return old_password
    
class clientform(forms.Form): 
    client_id=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    admin_username=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    admin_password=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    admin_type=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    profile_picture=forms.FileField(widget=forms.FileInput(attrs={'class':'account-file-input','hidden':True,'required':False,"id":"upload"}),required=False)
    first_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    last_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    company_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    email=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    gstin=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    phone_number=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False,'maxlength':10}),max_length=10,required=False)
    address=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    city=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    state=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    country=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    pincode=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False) 
    modified_at=forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control'}) )
    client_active = forms.BooleanField(initial=True,required=False)

class PasswordResetRequestForm(forms.Form):
    email = forms.EmailField(label="Email", max_length=254)
    
class SalesStagesForm(forms.Form):
    sales_stage_unique_id=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}))
    sales_stage_index=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}))
    sales_stage=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}))
    sales_stage_criteria_1=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    sales_stage_criteria_2=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    sales_stage_criteria_3=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    sales_stage_criteria_4=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    sales_stage_criteria_5=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':False}),required=False)
    
class NurturingEventsOrActionsForm(forms.Form):
    
    name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','required':True,'id':'event_name'}),required=True)
    nurturing_doc=forms.FileField(widget=forms.FileInput(attrs={'class':'form-control','required':False,"id":"upload"}),required=False)
    modified_at=forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control'}),required=False)
    nurturing_type = forms.ChoiceField(
        choices=[
            ('events', 'Events'),
            ('mode', 'Mode'),
            ('duration', 'Duration'),
            ('frequency', 'Frequency'),
        ],
        widget=forms.RadioSelect(attrs={
            'class': 'form-check-input',
            'onchange': 'handleNurturingTypeChange(this)',
        }),
        required=True,
    )
    duration_type = forms.ChoiceField(
        choices=[
            ('', 'Choose Type'),
            ('instantly', 'Instantly'),
            ('minutes', 'Min'),
            ('hours', 'Hrs'),
            ('days', 'Days'),
            ('month', 'Month')
        ],
        widget=forms.Select(attrs={
            'class':'form-control',
            'onchange': 'assign_val(this.value)',
        }), 
        required=False,
    )