# Create your models here.
import os
from django.db import models
from datetime import datetime

# # Create your models here.

def dynamic_upload_path(instance, filename):
    base_folder = "nurturing"
    sub_folder = instance.dynamic_folder or "default"
    return os.path.join(base_folder, sub_folder, filename)

class clientData(models.Model):
    client_id=models.CharField(max_length=100,blank=True)
    client_unique_id=models.CharField(max_length=100,blank=True)
    client_level=models.CharField(max_length=100,blank=True)
    admin_username=models.CharField(max_length=100,blank=True)
    admin_password=models.CharField(max_length=500,blank=True)
    admin_type=models.CharField(max_length=20,blank=True)
    profile_picture=models.FileField()
    first_name=models.CharField(max_length=100,blank=True)
    last_name=models.CharField(max_length=100,blank=True)
    company_name=models.CharField(max_length=100,blank=True)
    email=models.CharField(max_length=100,blank=True)
    gstin=models.CharField(max_length=20,blank=True)
    phone_number=models.CharField(max_length=100,blank=True)
    address=models.CharField(max_length=100,blank=True)
    city=models.CharField(max_length=100,blank=True)
    state=models.CharField(max_length=100,blank=True)
    country=models.CharField(max_length=100,blank=True)
    pincode=models.CharField(max_length=6,blank=True)
    client_active=models.BooleanField(default=True,blank=True)
    modified_at=models.DateTimeField(auto_now_add=True,blank=True)
    