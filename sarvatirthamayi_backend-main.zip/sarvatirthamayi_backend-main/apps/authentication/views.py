from django.views.generic import TemplateView
from web_project import TemplateLayout
from web_project.template_helpers.theme import TemplateHelper

from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import json,re,os;
import random;
from datetime import datetime
from .forms import LoginForm,PasswordResetRequestForm
from django.shortcuts import render,redirect

from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.auth import views as auth_views
from django.urls import reverse,reverse_lazy
from django.core.mail import EmailMultiAlternatives
from django.contrib.messages.views import SuccessMessageMixin
from django.views.generic.edit import CreateView,UpdateView

"""
This file is a view controller for multiple pages as a module.
Here you can override the page view layout.
Refer to auth/urls.py file for more pages.
"""


class AuthView(TemplateView):

    template_name = 'auth_login_basic.html' 

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            if request.user.is_superuser==True:
                return redirect('index')
            else:
                return redirect('business-stats-analytics')
        
        context = self.get_context_data(**kwargs)
        return self.render_to_response(context)
        
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        # Update the context
        context.update(
            {
                "layout_path": TemplateHelper.set_layout("layout_blank.html", context),
            }
        )

        return context

class PasswordResetRequestView(TemplateView):
    template_name = 'auth_forgot_password_basic.html'

    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        # Update the context
        context.update(
            {
                "layout_path": TemplateHelper.set_layout("layout_blank.html", context),
            }
        )

        return context

    def post(self, request, *args, **kwargs):
        form = PasswordResetRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            user = User.objects.filter(email=email).first()
            if user:
                # Create password reset token
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)
                password_reset_link = f"{request.scheme}://{request.get_host()}/reset/{uid}/{token}/"
                
                # Send password reset email
                # send_mail(
                #     'Password Reset Request',
                #     f'Hey User! <br>Click the link to reset your password: {password_reset_link} <br>Team Sarvatirthamayi',
                #     settings.EMAIL_HOST_USER,
                #     [email],
                #     fail_silently=False
                # )
                send_password_reset_email(email,password_reset_link)
            return redirect('password_reset_done')
        return self.render_to_response(self.get_context_data(form=form))
    
def send_password_reset_email(email, password_reset_link):
    subject = 'Password Reset Request'
    from_email = settings.EMAIL_HOST_USER
    #email='nanthinivinothkumar0227@gmail.com'
    
    # Create the plain text content
    text_content = f'Hey User! Click the link to reset your password: {password_reset_link} \nTeam'
    
    # Create the HTML content
    html_content = f'''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Password Reset</title>
            <style>
                /* Add any additional styles here */
            </style>
        </head>
        <body>
            <p>Hey User!</p>
            <p>Click the link to reset your password: <a href="{password_reset_link}">Reset Password</a></p>
            <p>Team</p>
        </body>
        </html>
    '''

    # Create the email
    email_message = EmailMultiAlternatives(subject, text_content, from_email, [email])
    email_message.attach_alternative(html_content, "text/html")  # Attach the HTML content

    # Send the email
    email_message.send()

class CustomPasswordResetConfirmView(auth_views.PasswordResetConfirmView):
    template_name = 'auth_password_reset_confirm.html'

    def get_success_url(self):
        # Redirect to a custom URL after successful password reset
        return reverse_lazy('password_reset_complete')
    
    def form_valid(self, form):
        # Process the form (set the new password)
        form.save()
        return super().form_valid(form)

    def form_invalid(self, form):
        # Return the same page with form errors
        return self.render_to_response(self.get_context_data(form=form))
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        # Update the context
        context.update(
            {
                "layout_path": TemplateHelper.set_layout("layout_blank.html", context),
            }
        )
        return context
        
        
    