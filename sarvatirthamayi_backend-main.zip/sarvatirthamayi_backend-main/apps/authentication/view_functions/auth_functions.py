from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json,re,os,sys;
from datetime import datetime
from ..models import clientData

from django.contrib.auth.hashers import *

from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.forms import UserCreationForm
from config.settings import BASE_DIR
import gridfs
from ..forms import LoginForm



ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'gif'])
UPLOAD_FOLDER = str(BASE_DIR)+'/static/profile_picture/'

def find_admin(request):
    email=request.POST['username']
    password=request.POST['password']#123456
    #new=make_password(password)
    #encoded_password='pbkdf2_sha256$720000$rdI08QLtbfdHbKYAfEhjJs$QXjcYsu+Z060N8kTqEEWVNm835aI1kPwRUARgbVQeeo='
    #stat=check_password(password,encoded_password)

    if request.method=='POST':
        form = LoginForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            remember_me = form.cleaned_data.get('remember_me')

            user = authenticate(request, username=username, password=password)
            if user is not None:
                if(user.is_active):
                    login(request,user)
                    if user.is_superuser:
                        
                        if remember_me:
                            request.session.set_expiry(30 * 24 * 60 * 60)  # 30 days
                        else:
                            request.session.set_expiry(0)  # Session expires on browser close

                        request.session['db_name']='jarvin'
                        request.session["admin_type"]='super_admin'
                        return JsonResponse({"status":"success","msg":"Logged in successfully","redirect_to_u":"dashboard"},safe=False)
                    else:
                        c_data = clientData.objects.get(client_id=request.user.id)
                        if c_data.profile_picture!='' and c_data.profile_picture!='False':
                            request.session["profile_picture"] = c_data.profile_picture.url
                            request.session["profile_picture_status"] = True
                        else:
                            request.session["profile_picture"]='' 
                            request.session["profile_picture_status"] = False
                        request.session["client_unique_id"] = c_data.client_unique_id
                        request.session["first_name"] = c_data.first_name
                        
                        request.session["company_name"]=c_data.company_name
                        request.session["admin_type"]=c_data.admin_type
                        request.session['db_name'] = 'client_'+str(c_data.company_name)
                       
                        if(c_data.admin_type=='admin'):
                            #Temple Admins
                            redirect_to_u='temples/'
                        else:
                            redirect_to_u='business_stats_analytics'
                        return JsonResponse({"status":"success","redirect_to_u":redirect_to_u,"msg":"Logged in successfully"},safe=False)
                else:
                    return JsonResponse({"status":"error","msg":"You are not in active status. Please contact admin"},safe=False)

            else:

                user=User.objects.get(email=email)
                if user is not None:
                    if user.is_active:
                        return JsonResponse({"status":"error","msg":"Please check your password1"},safe=False)                        
                    else:
                        return JsonResponse({"status":"error","msg":"You are not active. Please check with admin"},safe=False)
                else:
                    return JsonResponse({"status":"error","msg":"Please check your password2"},safe=False)
        else:
            return JsonResponse({"status":"error","msg":"Error"},safe=False)
    else:
            return JsonResponse({"status":"error","msg":"Error"},safe=False)



def upload_file(request):

    filename=''
    if request.method == 'POST':
        file = request.FILES.get['profile_picture']
        
        if file and allowed_file(file.filename):
            filename = file.filename
            file.save(os.path.join(UPLOAD_FOLDER, filename))
            #return redirect(url_for('upload_file', filename=filename))
            #os.rename(UPLOAD_FOLDER + filename, UPLOAD_FOLDER+'niloofar.jpg')
    return filename

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

def set_password(request):
    email=request.POST['email']
    password=request.POST['password']
    u = User.objects.get(email=email)
    u.set_password(password)
    u.save()
    
def logout_custom(request):
    try:
        logout(request);
        del request.session["admin_id"]
        del request.session["admin_username"]
        del request.session["admin_type"]
        del request.session["profile_picture"]
        del request.session["profile_picture_status"]
    except KeyError:
        pass
    #return HttpResponse(str('logged out'))
    #return redirect("auth/login/")
    return HttpResponseRedirect(reverse("auth-login-basic")) 
    