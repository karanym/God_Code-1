from django.urls import path
from django.conf.urls.static import static
from .views import AuthView,PasswordResetRequestView,CustomPasswordResetConfirmView
from .view_functions import auth_functions
from django.contrib.auth import views as auth_views
from config.settings import *

urlpatterns = [
    #path(
    #    "backend_admin/",
    #    AuthView.as_view(template_name="auth_login_basic.html"),
    #    name="auth-login-basic",
    #),
    path('auth/check_admin/',auth_functions.find_admin),
    path('auth/logout/',auth_functions.logout_custom),
    path(
        "auth/register/",
        AuthView.as_view(template_name="auth_register_basic.html"),
        name="auth-register-basic",
    ),
    path(
        "auth/forgot_password/",
        PasswordResetRequestView.as_view(template_name="auth_forgot_password_basic.html"),
        name="auth-forgot-password-basic",
    ),
    # path('password_reset/', PasswordResetRequestView.as_view(), name='password_reset'),
    path('password_reset/done/', AuthView.as_view(template_name='auth_password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', CustomPasswordResetConfirmView.as_view(template_name='auth_password_reset_confirm.html'), name='password_reset_confirm'),
    path('reset/done/', AuthView.as_view(template_name='auth_password_reset_complete.html'), name='password_reset_complete'), 
    

]
urlpatterns+=static(MEDIA_URL,document_root=MEDIA_ROOT)