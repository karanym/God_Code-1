from django.urls import path
from .views import *
from .views_leads import *

urlpatterns = [
    path(
        "dashboard",
        DashboardsView.as_view(template_name="dashboard_analytics.html"),
        name="index",
    ),
    path(
        "dashboard/business_stats_analytics",
        BusinessDashboardsView.as_view(template_name="business_stats_analytics.html"),
        name="business-stats-analytics", 
    ),
    path(
        "dashboard/user_stats_analytics/<user_type>", 
        UserStatsDashboardsView.as_view(template_name="user_stats_analytics.html"),
        name="user-stats-analytics",  
    ), 
    path('user_stats_analytics_datatable_items/<user_type>', UserStatsDashboardsView_Datatable, name='user_stats_analytics_datatable-list'),
    path(
        "dashboard/chat_stats_analytics/<chat_type>",
        ChatStatsDashboardsView.as_view(template_name="chat_stats_analytics.html"),
        name="chat-stats-analytics", 
    ),
    path('chat_stats_analytics_datatable_items/<chat_type>', ChatStatsDashboardsView_Datatable, name='chat_stats_analytics_datatable-list'),
    path(
        "dashboard/product_stats_analytics/<product_type>",
        ProductStatsDashboardsView.as_view(template_name="product_stats_analytics.html"),
        name="product-stats-analytics", 
    ),
    path(
        "dashboard/quotesent_stats_analytics/<user_type>",
        QuotesentStatsDashboardsView.as_view(template_name="quotesent_stats_analytics.html"),
        name="quotesent-stats-analytics", 
    ),
    path('quotesent_stats_analytics_datatable_items/', QuotesentStatsDashboardsView_Datatable, name='quotesent_stats_analytics_datatable-list'),
    path(
        "dashboard/conversationlog_stats_analytics/<user_type>/<id>",
        ConversationlogStatsDashboardsView.as_view(template_name="conversationlog_stats_analytics.html"),
        name="conversationlog-stats-analytics", 
    ),
    path('conversationlog_stats_analytics_datatable_items/<user_type>/<user_id>', ConversationlogStatsDashboardsView_Datatable, name='conversationlog_stats_analytics_datatable-list'),
    path(
        "dashboard/lead_stats_analytics",
        LeadStatsDashboardsView.as_view(template_name="lead_stats_analytics.html"),
        name="lead-stats-analytics", 
    ),
    path(
        "dashboard/grievance_stats_analytics",
        GrievanceStatsDashboardsView.as_view(template_name="grievance_stats_analytics.html"),
        name="grievance-stats-analytics",  
    ),
    # path(
    #     path('dashboard/ajax_datatable_users/', get_data_validated_users, name="ajax_datatable_users") 
    # ), 
]
