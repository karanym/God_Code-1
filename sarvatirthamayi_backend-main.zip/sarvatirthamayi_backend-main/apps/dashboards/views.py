from django.views.generic import TemplateView
from django.views.generic.edit import FormView
from web_project import TemplateLayout
from .models import jarvinUser,jarvinProducts
from ..authentication.models import clientData
from datetime import date,datetime, timedelta, time
import json,re,os
from django.http import HttpResponse
from django.http import JsonResponse
import datetime as dt

from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.utils import timezone
from datetime import timedelta
from ajax_datatable.views import AjaxDatatableView
from django.core.paginator import Paginator
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
now = timezone.now()

@method_decorator(login_required, name='dispatch')
class DashboardsView(TemplateView):
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['title']='Dashboard'
        return context
    
class BusinessDashboardsView(TemplateView):

    def post(self, request, *args, **kwargs):
        b_search_input=request.POST['business_search_input']
        # request.session['business_search_input'] = b_search_input 
        context = self.get_context_data(**kwargs)
        context["business_search_input"]=b_search_input
        res_data=get_all_users_business_stats(self.request,b_search_input,context['company_name'])
        
        context['key']=res_data['key'] 
        context['total_users']=res_data['total_users'] 
        context['new_users']=res_data['new_users']
        context['business_queries']=res_data['business_queries']
        context['quote_sent']=res_data['quote_sent']
        return self.render_to_response(context)

    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        context['title']='Business Stats'
        
        if self.request.method == 'POST':
            business_search_input=self.request.POST['business_search_input']
        else:
            context['business_search_input']='1 day'
            business_search_input=context['business_search_input']

        client_id=self.request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        context['client_id']=client_id 
        context['company_name']=c_data.company_name

        res_data=get_all_users_business_stats(self.request,business_search_input,c_data.company_name)
        
        context['key']=res_data['key'] 
        context['total_users']=res_data['total_users'] 
        context['new_users']=res_data['new_users']
        context['business_queries']=res_data['business_queries']
        context['quote_sent']=res_data['quote_sent']
        return context

class UserChatsAjaxDatatableView(AjaxDatatableView): 
    #model = Permission
    title = 'User Chats'
    initial_order = [["app_label", "asc"], ]
    length_menu = [[10, 20, 50, 100, -1], [10, 20, 50, 100, 'all']]
    search_values_separator = '+'

    column_defs = [
        AjaxDatatableView.render_row_tools_column_def(),
        {'name': 'id', 'visible': False, },
        {'name': 'codename', 'visible': True, },
        {'name': 'name', 'visible': True, }
    ]


class LeadStatsDashboardsView(TemplateView):
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['title']='Lead Stats'
        return context
class GrievanceStatsDashboardsView(TemplateView):
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['title']='Business Stats'
        return context
def UserStatsDashboardsView_Datatable(request,user_type):
    client_id=request.user.id
    c_data=clientData.objects.get(client_id=client_id)
        
    res_data=get_all_users_stats_queryset(c_data.company_name,user_type,'1 day')
    userData_userstats=res_data["userData"];
    total_users=res_data["total_users"];
    
    
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'


    # Columns you want to order by
    orderable_columns = ['created_at','name','email', 'mobile_no', 'dob', 'gender', 'city', 'created_at', 'modified_at']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables
    search_value = request.POST.get('search[value]', '')

    # Query the database
    data=userData_userstats

    # Apply search filter if there is any
    if search_value:
        #data=get_searched_conversation_data(data,search_value);
        data = data.filter(name__icontains=search_value) | data.filter(email__icontains=search_value) | data.filter(mobile_no__icontains=search_value)  | data.filter(gender__icontains=search_value)  | data.filter(city__icontains=search_value)  | data.filter(duration__icontains=search_value) | data.filter(created_at__icontains=search_value)   # Modify this filter based on your fields

    # Apply ordering
    data = data.order_by(order_column)
    
    total_records = len(data)

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    for userstatsdataobj in page_data:
        created_at_format=userstatsdataobj.created_at.strftime("%B %d %Y %I:%M %p");
        modified_at_format=userstatsdataobj.modified_at.strftime("%B %d %Y %I:%M %p");
        k=(k+1)
        data_list.append({
            "sno":k,
            "name":userstatsdataobj.name,
            "email":str(userstatsdataobj.email),
            "mobile_no":userstatsdataobj.mobile_no,
            "dob":userstatsdataobj.dob,
            "gender":str(userstatsdataobj.gender),
            "city":userstatsdataobj.city,
            "created_at":created_at_format,
            "modified_at":modified_at_format,
            
            })

    response = {
        'draw': draw,
        'recordsTotal': total_users,
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)
    
class UserStatsDashboardsView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        context['title']='User Stats'
        
        user_type=self.kwargs['user_type']

        if user_type:
            if(user_type=='validated_users'):
                selected_user="Validated Users"
            if(user_type=='unknown_users'):
                selected_user="Unknown Users"
            if(user_type=='all_users'):
                selected_user="All Users"
        else:
            user_type='all_users'
            selected_user="All Users"
        
        context['selected_user']=selected_user
        context['user_type']=user_type

        client_id=self.request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        
        res_data=get_all_users_stats_queryset(c_data.company_name,user_type,'1 day')
        
        context['client_id']=client_id
        
        context['total_users']=res_data['total_users'] 
        context['unknown_users']=res_data['unknown_users'] 
        context['validated_users']=res_data['validated_users'] 
        
        context['current_users_data']=res_data['current_users_data'] 
        #context['userData']=res_data['userData'] 
        
        return context
def get_searched_chats_data(data,search_value):
    data_new=[];
    
    for x in range(len(data)):
        if((search_value in data[x]["name"]) or (search_value in data[x]["email"]) or (search_value in data[x]["mobile_no"]) or (search_value in data[x]["dob"]) or (search_value in data[x]["gender"]) or (search_value in data[x]["city"]) or (search_value in data[x]["created_at_format"]) or (search_value in data[x]["modified_at_format"])):
            data_new.append(data[x]);
    return data_new;        
def ChatStatsDashboardsView_Datatable(request,chat_type):
    company_name = request.POST.get('company_name', '');
    chat_type = request.POST.get('chat_type', '');
    chat_search_input = request.POST.get('chat_search_input', '');
    t_type = int(request.POST.get('t_type', 0));
    
    if t_type != '':
        table_data=table_data_fetch(company_name,chat_type,chat_search_input,t_type)
    else:
        table_data=[]
    
    
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    


    # Columns you want to order by
    orderable_columns = ['created_at','name','email', 'mobile_no', 'dob', 'gender', 'city', 'created_at', 'modified_at']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    '''if order_direction == 'desc':
        order_column = '-' + order_column'''

    # Search query from DataTables
    search_value = request.POST.get('search[value]', '')

    # Query the database
    data=table_data

    # Apply search filter if there is any
    if search_value:
        data=get_searched_chats_data(data,search_value);

    # Apply ordering
    #data = data.order_by(order_column)
    if order_direction == 'desc':
        data = sorted(data, key=lambda x: x[order_column], reverse=True)
    else:
        data = sorted(data, key=lambda x: x[order_column])

    total_records = len(data)

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    '''[{'name': 'shareesh', 'email': 'shareeshk@gmail.com', 'mobile_no': '7899439925', 'gender': 'NA', 'city': 'NA', 'quote_number': 'QUOTE_58031726554424153', 'quote_sent_on_email': 'shareeshk@gmail.com', 'product_quotes': 'emergency genie', 'method': 'jbrain'}]'''
     
    for chatsdataobj in page_data:
        
        k=(k+1)
        data_list.append({
            "sno":k,
            "name":chatsdataobj["name"],
            "email":str(chatsdataobj["email"]),
            "mobile_no":chatsdataobj["mobile_no"],
            "dob":str(chatsdataobj["dob"]),
            "gender":chatsdataobj["gender"],
            "city":chatsdataobj["city"],
            "created_at_format":chatsdataobj["created_at_format"],
            "modified_at_format":chatsdataobj["modified_at_format"]
            })

    response = {
        'draw': draw,
        'recordsTotal': len(table_data),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)
    
    
class ChatStatsDashboardsView(TemplateView):

    def post(self, request, *args, **kwargs):
        chat_search_input=request.POST['chat_search_input']
        t_type=request.POST['t_type']
        #request.session['chat_search_input'] = chat_search_input 
        context = self.get_context_data(**kwargs)
        context["chat_search_input"]=chat_search_input
        context["t_type"]=t_type
        company_name=context["company_name"]
        chat_type=self.kwargs['chat_type']
        chart_categories=context["chart_categories"]
        t_type=t_type 
        #updating context data
        
        res_data=get_all_chat_stats(company_name,chat_type,chat_search_input)
        
        if t_type != '':
            table_data=table_data_fetch(company_name,chat_type,chat_search_input,t_type)
            t_type=int(t_type)
            table_title=str('Chat Session :') + str(chart_categories[t_type])
            #table_title=''
        else:
            table_data=[]
            table_title=''

        #context['table_data']=table_data
        context['table_title']=table_title
        context['t_type']=t_type

        context['all_chat_session']=res_data['all_chat_session'] 
        context['validated_users_session']=res_data['validated_users_session'] 
        context['unknown_users_session']=res_data['unknown_users_session'] 
        context['chart_data']=res_data['chart_data'] 
        #updating context data

        return self.render_to_response(context)
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['title']='Chat Stats'
        chat_type=self.kwargs['chat_type']
        
        if chat_type == 'all_chat_session':
            chart_type='bar';
            chart_categories=['6AM to 10AM ', '10AM to 1PM', '1PM to 4PM', '4PM to 8PM', '8PM to 12Midnight', '12Midnight to 6AM']
        else:
            chart_type='spline';
            chart_categories=['> 10min', '> 5min', '> 3min','> 1min', '< 1min']

        context['chat_search_input']='30 days'
        chat_search_input=context['chat_search_input']
        #t_type=0
            
            
        context['selected_user']='all chats'
        context['chat_type']=chat_type
        #context['t_type']=t_type
        client_id=self.request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        context['client_id']=client_id
        context['company_name']=c_data.company_name

        res_data=get_all_chat_stats(c_data.company_name,chat_type,chat_search_input)
        

        '''
        if t_type != '':
            table_data=table_data_fetch(c_data.company_name,chat_type,chat_search_input,t_type)
            table_title=str('Chat Session :')
            #table_title=''
        else:
            table_data=[]
            table_title=''
        '''

        #context['table_data']=table_data
        #context['table_title']=table_title
        #context['t_type']=t_type

        context['all_chat_session']=res_data['all_chat_session'] 
        context['validated_users_session']=res_data['validated_users_session'] 
        context['unknown_users_session']=res_data['unknown_users_session'] 
        context['chart_data']=res_data['chart_data'] 
        context['chart_type']=chart_type
        context['chart_categories']=chart_categories

        return context


class ProductStatsDashboardsView(TemplateView):

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['title']='Chat Stats'
        product_type=self.kwargs['product_type']
        chart_type='spline'
        search_input='10 day';

        context['selected_user']='all chats'
        context['product_type']=product_type

        client_id=self.request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        res_data=get_all_product_stats(c_data.company_name,product_type,search_input)
        context['client_id']=client_id


        context['all_products']=res_data['all_products']
        context['all_categories']=res_data['all_categories']
        context['all_productsData']=res_data['all_productsData']
        context['all_categoriesData']=res_data['all_categoriesData']
        context['products']=res_data['products']

        products=res_data['products'];
        context['products']=products 

        context['brouchure_downloaded']=res_data['brouchure_downloaded']
        context['discussed']=res_data['discussed']
        context['products_model_list']=res_data['products_model_list']
        context['total_brouchure_downloaded']=res_data['total_brouchure_downloaded']
        context['total_discussed']=res_data['total_discussed']

        return context
    


def get_all_product_stats(company_code,user_type,search_input):
   
    company_code=company_code
    key=company_code
    user_type=user_type
    filter_txt='30 days'

    filter_txt=filter_txt.replace(" ", "");
    res = filter_txt_fun(filter_txt)
    val=re.findall(r'\d+', filter_txt )
    
    if(len(val)>0):
        val=int(val[0])
    else:
        val=0

    current_folder_path="filesystem//"+company_code+"//product_info/";
    dir=current_folder_path
    temp=0
    prod=[];
    cate=[];
    products=[];
    cate_data=[];
    brouchure_downloaded=[];
    discussed=[];
    products_model_list=[];
    for filename in os.listdir(dir):
        temp=(temp+1)
        with open(os.path.join(current_folder_path, filename)) as f:
            while True:
                line = f.readline()
                if("searchablestart_" in line):
                    prod_dict = json.loads(line) 
                    if len(prod_dict) >0:
                        for data in prod_dict:
                            
                            data=prod_dict[data]

                            #return JsonResponse(prod_dict[data],safe=False)
                            product_model=data["product_model"]
                            product_name=data["product_name"]
                            
                            listing_structure=' ' .join(data["product_parcat_valu"])+" > "+' ' .join(data["product_cat_valu"])+" > "+' ' .join(data["product_subcat_valu"])+" > "+' ' .join(data["product_brand"])
                            visual=str(data["product_images"][0])
                            
                            temp_dict=[]
                            brochure_txt='';
                            if("prod_broc_1" in data):
                                brochure_txt+=' ' .join(data["prod_broc_1"])+'">'+' ' .join(data["prod_broc_1"])+"</a>"+"<br>"
                                txt='' .join(data["prod_broc_1"])
                                brouchure_name = txt.split('/')
                                brouchure_name=(brouchure_name[len(brouchure_name)-1])
                                temp_dict.append({"name":brouchure_name,"value":' ' .join(data["prod_broc_1"])})
                            if("prod_broc_2" in data):
                                brochure_txt+='<a href="'+' ' .join(data["prod_broc_2"])+'">'+' ' .join(data["prod_broc_2"])+"</a>"+"<br>"
                                brochure=data["prod_broc_2"]
                                brouchure_name = txt.split('/')
                                brouchure_name=(brouchure_name[len(brouchure_name)-1])
                                temp_dict.append({"name":brouchure_name,"value":' ' .join(data["prod_broc_2"])})
                            if("prod_broc_3" in data):
                                brochure_txt+='<a href="'+' ' .join(data["prod_broc_3"])+'">'+' ' .join(data["prod_broc_3"])+"</a>"+"<br>"
                                brochure=data["prod_broc_3"]
                                brouchure_name = txt.split('/')
                                brouchure_name=(brouchure_name[len(brouchure_name)-1])
                                temp_dict.append({"name":brouchure_name,"value":' ' .join(data["prod_broc_3"])})

                            cat_txt=' ' .join(data["product_cat_valu"])
                            cate.append(cat_txt)

                            product_name=' ' .join(product_name)
                            prod.append({"product_name":str(product_name),"listing_structure":listing_structure,"visual":visual,"brochure":temp_dict})
                            products.append(product_name)

                            
                            if not any(d['category_name'] == cat_txt for d in cate_data):
                                cate_data.append({"category_name":cat_txt,"products":[product_name]})
                            else:
                                for d in cate_data:
                                    if(d['category_name'] == cat_txt):
                                        d["products"].append(product_name)

                            #engagement metricts#
                            product_model_str='' .join(product_model).replace(" ", "")
                            product_model_str=product_model_str.lower();
                            products_model_list.append(product_model_str)
                            product_db_data=get_brouchure_values(key,product_model_str,val)
                            if product_db_data:
                                #for prod_db in product_db_data:
                                discussed_count=int(product_db_data.discussed_count)
                                brouchure_downloads=int(product_db_data.brouchure_downloads)
                            else:
                                discussed_count=0
                                brouchure_downloads=0
                            brouchure_downloaded.append(brouchure_downloads)
                            discussed.append(discussed_count)
                            #engagement metricts#
                                    

                    else:
                        print('1')
                if not line:
                    break
        f.close()

    all_products=temp
    all_categories=len(cate_data)
    all_productsData=prod
    all_categoriesData=cate_data

    #all_productsData=[{"product_name":"Eva 220LS","listing_structure":"> Cat > Abc","visual":"assets/images/smile.png","brochure":"Brouchure"}]
    #all_categoriesData=[{"category_name":"Industrial Cooling","products":"Eva 220LS , Eva 320LS"}];

    total_brouchure_downloaded=sum(brouchure_downloaded)
    total_discussed=sum(discussed)
    resp={"all_products":all_products,"all_categories":all_categories,"all_productsData":all_productsData,"all_categoriesData":all_categoriesData,"products":products,"brouchure_downloaded":brouchure_downloaded,"discussed":discussed,"products_model_list":products_model_list,"total_brouchure_downloaded":total_brouchure_downloaded,"total_discussed":total_discussed}

    return resp


def update_brouchure_download(request):
   
    company_code=request.POST["company_code"]
    user_id=request.POST["user_id"]
    product_code=request.POST["product_code"]
    brouchure_name=request.POST["brouchure_name"]

    brouchure_new={"brouchure_download_on":datetime.now(),"brouchure_name":brouchure_name,"user_id":user_id}
    data1={};
    list_data=find_product(product_code,company_code)
    if(len(list_data)>0):
        brouchure_downloads=0;
        for obj in list_data:
            brouchure_old=obj["brouchure_downloads_in_detail"]
            brouchure_old.append(brouchure_new)
            brouchure_downloads=(obj["brouchure_downloads"]+1)

        data1={"brouchure_downloads_in_detail":brouchure_old,"brouchure_downloads":brouchure_downloads,"modified_at":datetime.now()}

        x = jarvinProducts.objects.get(product_code=product_code,company_code=company_code)
        x.brouchure_downloads_in_detail = brouchure_old
        x.brouchure_downloads = brouchure_downloads
        x.modified_at = datetime.now()
        x.save()

    return JsonResponse("Updated Successfully ",safe=False)

def find_product(product_code,company_code):
    try:
        p_data=jarvinProducts.objects.get(product_code=product_code,company_code=company_code)
    except jarvinProducts.DoesNotExist:
        p_data = None
    
    return p_data

def get_brouchure_values(key,product_code,fitler_txt):
    try:
        p_data=jarvinProducts.objects.get(product_code=product_code,company_code=key)
    except jarvinProducts.DoesNotExist:
        p_data = {}
    
    return p_data

def get_all_chat_stats(key,chat_type,search_input):
    
    company_code=key
    user_type=chat_type#all_chat_session,validated_users_session,unknown_users_percentage
    filter_txt=search_input
    filter_txt=filter_txt.replace(" ", "");
    res = filter_txt_fun(filter_txt)
    val=re.findall(r'\d+', filter_txt )
    if(len(val)>0):
        val=int(val[0])
    else:
        val=0
    new_val=val

    #1. fetch number of chat sessions - number of files -All
    #2. fetch number of chat sessions with email - number of files - Validated
    #3. fetch number of chat sessions without email - number of files - Unknown

    current_folder_path="filesystem//"+company_code+"//users//unidentified"; # this is current folder path for unidentified users
    dir = [filename for filename in os.listdir(current_folder_path)];
    pattern = r'([^@]+@[\.A-Za-z]+)(.*)'
    temp=0 
    temp_val=0
    temp_unknown=0
    current_date = date.today().isoformat()
    days_before = (date.today() - timedelta(days=new_val)).isoformat()
    for _, _, files in os.walk(current_folder_path):
        for filename in files:
            if filename.endswith(".txt"):
                filetime_o = dt.datetime.fromtimestamp(os.path.getctime(current_folder_path +"/"+ filename))   
                filetime = filetime_o.time()
                filedate = filetime_o.date().isoformat()

                if(days_before<filedate<=current_date):
                #if(1):
                    temp=(temp+1)
                    if len(re.findall(pattern, filename)) >0:
                        temp_val=(temp_val+1)
                    else:
                        temp_unknown=(temp_unknown+1)
                else:
                    filter_satisfied=False
                    
    
    all_chat_session=temp
    validated_users_session=temp_val
    unknown_users_session=temp_unknown
    #all_chat_session = sum([len(files) for r, d, files in os.walk(current_folder_path)])
    #validated_users_session=sum([len(re.findall(pattern, filename)) for filename in os.listdir(current_folder_path)])
    #unknown_users_session=(all_chat_session-validated_users_session);
    dir = current_folder_path  #path to directory
    chart_data=[]

    if(user_type=='all_chat_session'):
        ts_1_count=0
        ts_2_count=0
        ts_3_count=0
        ts_4_count=0
        ts_5_count=0
        ts_6_count=0
        for file in os.listdir(dir):
            filetime_o = dt.datetime.fromtimestamp(os.path.getctime(dir +"/"+ file))   
            filetime = filetime_o.time() 
            filedate = filetime_o.date().isoformat()
            if(days_before<filedate<=current_date):
                ts_1=is_time_between(time(6,1), time(10,00),filetime)
                if(ts_1==True):
                    ts_1_count=(ts_1_count+1)
                ts_2=is_time_between(time(10,1), time(13,00),filetime)
                if(ts_2==True):
                    ts_2_count=(ts_2_count+1)
                ts_3=is_time_between(time(13,1), time(16,00),filetime)
                if(ts_3==True):
                    ts_3_count=(ts_3_count+1)
                ts_4=is_time_between(time(16,1), time(20,00),filetime)
                if(ts_4==True):
                    ts_4_count=(ts_4_count+1)
                ts_5=is_time_between(time(20,1), time(23,59),filetime)
                if(ts_5==True):
                    ts_5_count=(ts_5_count+1)
                ts_6=is_time_between(time(0,1), time(6,00),filetime)
                if(ts_6==True):
                    ts_6_count=(ts_6_count+1)
                #if filetime.date() == today:
                    #print(file)
        chart_data=[ts_1_count,ts_2_count,ts_3_count,ts_4_count,ts_5_count,ts_6_count]

    elif(user_type=='validated_users_session'):
        chart_data=[]
        g_10=0;
        g_5=0
        g_3=0;
        g_1=0;
        l_1=0;

        for filename in os.listdir(current_folder_path):
            single_user=0;
            filetime_o = dt.datetime.fromtimestamp(os.path.getctime(dir +"/"+ filename))   
            filetime = filetime_o.time() 
            filedate = filetime_o.date().isoformat()
            if(days_before<filedate<=current_date):
                if(len(re.findall(pattern, filename) )>0) :
                    #read file
                    with open(os.path.join(current_folder_path, filename)) as f:
                        while True:
                            line = f.readline()
                            if("User : " in line):
                                elements = line.split('timetimediffseperator', 1) 
                                if len(elements) < 2:
                                    print("there is no ':' or there is no value after ':' ")
                                else:
                                    val=re.findall(r'\d+', elements[1] )
                                    time_in_seconds=int(val[0])
                                    single_user=(single_user+time_in_seconds)

                                # if line is empty
                                # end of file is reached
                            if not line:
                                break
                        
                    f.close()
                    if(single_user<60):
                        l_1=(l_1+1)
                    elif(single_user>600):
                        g_10=(g_10+1)
                    elif(single_user>300):
                        g_5=(g_5+1)
                    elif(single_user>180):
                        g_3=(g_3+1)
                    elif(single_user>60):
                        g_1=(g_1+1)

        chart_data=[g_10,g_5,g_3,g_1,l_1]
    elif(user_type=='unknown_users_session'):
        chart_data=[]
        g_10=0;
        g_5=0
        g_3=0;
        g_1=0;
        l_1=0;

        for filename in os.listdir(current_folder_path):
            single_user=0;
            filetime_o = dt.datetime.fromtimestamp(os.path.getctime(dir +"/"+ filename))   
            filetime = filetime_o.time() 
            filedate = filetime_o.date().isoformat()
            if(days_before<filedate<=current_date):
                if(len(re.findall(pattern, filename) )==0) :
                    #read file
                    
                    with open(os.path.join(current_folder_path, filename)) as f:
                        while True:
                            line = f.readline()
                            if("User : " in line):
                                elements = line.split('timetimediffseperator', 1) 
                                if len(elements) < 2:
                                    print("there is no ':' or there is no value after ':' ")
                                else:
                                    val=re.findall(r'\d+', elements[1] )
                                    time_in_seconds=int(val[0])
                                    single_user=(single_user+time_in_seconds)

                                # if line is empty
                                # end of file is reached
                            if not line:
                                break
                        
                    f.close()
                    if(single_user<60):
                        l_1=(l_1+1)
                    elif(single_user>600):
                        g_10=(g_10+1)
                    elif(single_user>300):
                        g_5=(g_5+1)
                    elif(single_user>180):
                        g_3=(g_3+1)
                    elif(single_user>60):
                        g_1=(g_1+1)

        chart_data=[g_10,g_5,g_3,g_1,l_1]
        
    resp={"all_chat_session":all_chat_session,"validated_users_session":validated_users_session,"unknown_users_session":unknown_users_session,"chart_data":chart_data}

    return resp

def table_data_fetch(key,chat_type,search_input,t_type):

    company_code=key
    user_type=chat_type
    filter_txt=search_input
    t_type=(int(t_type)+1)
    filter_txt=filter_txt.replace(" ", "");
    res = filter_txt_fun(filter_txt)
    val=re.findall(r'\d+', filter_txt )

    if(len(val)>0):
        val=int(val[0])
    else:
        val=0
    new_val=val
    #return JsonResponse(val,safe=False)

    current_folder_path="filesystem//"+company_code+"//users//unidentified/"; # this is current folder path for unidentified users
    dir = [filename for filename in os.listdir(current_folder_path)];
    today = dt.datetime.now().date()
    dir = current_folder_path  #path to directory
    chart_data=[]

    all_data=[];
    filter_satisfied=False
    if(user_type!=''):
        ts_count=0 
        ts_1=False
        pattern = r'([^@]+@[\.A-Za-z]+)(.*)'
        for file in os.listdir(dir):
            new_list={}
            single_user=0
            filetime_o = dt.datetime.fromtimestamp(os.path.getctime(dir +"/"+ file))   
            filetime = filetime_o.time()
            filedate = filetime_o.date().isoformat()

            current_date = date.today().isoformat()
            days_before = (date.today() - timedelta(days=new_val)).isoformat()

            if(days_before<filedate<=current_date):
                filter_satisfied=True
            else:
                filter_satisfied=False
            
            if(user_type=='all_chat_session' and filter_satisfied==True):
                if(str(t_type)=='1'):
                    ts_1=is_time_between(time(6,1), time(10,00),filetime)
                elif(str(t_type)=='2'):
                    ts_1=is_time_between(time(10,1), time(13,00),filetime)
                elif(str(t_type)=='3'):
                    ts_1=is_time_between(time(13,1), time(16,00),filetime)
                elif(str(t_type)=='4'):
                    ts_1=is_time_between(time(16,1), time(20,00),filetime)
                elif(str(t_type)=='5'):
                    ts_1=is_time_between(time(20,1), time(23,59),filetime)
                elif(str(t_type)=='6'):
                    ts_1=is_time_between(time(0,1), time(6,00),filetime)
            elif(user_type=='validated_users_session' and filter_satisfied==True):
                if(len(re.findall(pattern, file) )>0) :
                    ts_1=True
                    
            elif(user_type=='unknown_users_session' and filter_satisfied==True):
                if(len(re.findall(pattern, file) )==0) :
                    ts_1=True
            else:
                ts_1=False

            if(ts_1==True):
                
                if(len(re.findall(pattern, file)) >0 and user_type=='validated_users_session') or (len(re.findall(pattern, file)) ==0 and (user_type=='unknown_users_session') or (user_type=='all_chat_session')):
                    
                    with open(os.path.join(current_folder_path, file)) as f:
                        ini_count=0;
                        ini_count_list=[]
                        ini_var='';
                        while True:
                            
                            line = f.readline()
                            if("Name : " in line):
                                elements = line.split(' : ', 1) 
                                if len(elements) < 2:
                                    print("there is no ':' or there is no value after ':' ")
                                else:
                                    new_list.update({"name":elements[1]})
                            if("Type : " in line):
                                elements = line.split(' : ', 1) 
                                if len(elements) < 2:
                                    print("there is no ':' or there is no value after ':' ")
                                else:
                                    new_list.update({"type":elements[1]})
                                    new_list.update({"email":"NA"})
                                    new_list.update({"mobile_no":"NA"})
                                    new_list.update({"dob":"NA"})
                                    new_list.update({"gender":"NA"})
                                   
                            if("usertimeseperator " in line):
                                ini_count=(ini_count+1)
                                elements = line.split(' usertimeseperator ', 1) 
                                if len(elements) < 2:
                                    print("there is no ':' or there is no value after ':' ")
                                else:
                                    tm=elements[1].split(' timetimediffseperator ',1)
                                    if(len(tm)>=2):
                                        ini_count_list.append(tm[0])
                                        # if(ini_count==1):
                                        #     ini_count_list.append(tm[0])
                                        # else:
                                        #     ini_var=tm[0];

                                
                            if(user_type=='validated_users_session' or user_type=='unknown_users_session'):
                                if("User : " in line):
                                    elements = line.split('timetimediffseperator', 1) 
                                    if len(elements) < 2:
                                        print("there is no ':' or there is no value after ':' ")
                                    else:
                                        val=re.findall(r'\d+', elements[1] )
                                        time_in_seconds=int(val[0])
                                        single_user=(single_user+time_in_seconds)
                                    
                            if not line:
                                break

                        #ini_count_list.append(ini_var)  
                        
                        f.close()

                    last=(len(ini_count_list)-1)
                    if(len(ini_count_list)>0):
                        new_list.update({"created_at":ini_count_list[0]})
                        new_list.update({"modified_at":ini_count_list[last]})
                        created_at_obj = datetime.strptime(ini_count_list[0], '%Y-%m-%d %H:%M:%S')
                        modified_at_obj = datetime.strptime(ini_count_list[last], '%Y-%m-%d %H:%M:%S')
                        new_list.update({"created_at_format":created_at_obj.strftime("%B %d %Y %I:%M %p")})
                        new_list.update({"modified_at_format":modified_at_obj.strftime("%B %d %Y %I:%M %p")})
                    if(len(re.findall(pattern, file)) >0 and user_type=='validated_users_session') or (len(re.findall(pattern, file)) ==0 and (user_type=='unknown_users_session')):
      
                        if(str(t_type)=='5' and single_user<60):
                            new_list=new_list
                        elif(str(t_type)=='1' and single_user>600):
                            new_list=new_list
                        elif(str(t_type)=='2' and single_user>300 and single_user<600):
                            new_list=new_list
                        elif(str(t_type)=='3' and single_user>180 and single_user<300):
                            new_list=new_list
                        elif(str(t_type)=='4' and single_user>60 and single_user<180):
                            new_list=new_list
                        else:
                            new_list={}
                    elif(user_type=='all_chat_session'):
                        new_list=new_list
                    else:
                        new_list={}
            
                if(len(new_list)>0):
                    # the below code is used to get the user_id from the basepath
                    basepath_name=new_list["name"]; # "filesystem//evapoler//users//unidentified//17-09-2024-01-46-46-PM-userid-user_1726556952175.txt"
                    basepath_name_arr=basepath_name.split("-");
                    basefile=basepath_name_arr[len(basepath_name_arr)-1];
                    user_id=basefile.replace(".txt","")
                    
                    userData_info = get_userdata_by_user_id(key,user_id)
                    if(userData_info):
                        # overriding the textfile info here;
                        new_list["name"]=userData_info.name
                        new_list["email"]=userData_info.email
                        new_list["mobile_no"]=userData_info.mobile_no
                        new_list["dob"]=userData_info.dob
                        new_list["gender"]=userData_info.gender
                        new_list["city"]=userData_info.city
                        #new_list["name"]=user_id+str(key)+"|"+str(user_id)
        
                        all_data.append(new_list)

    resp=all_data
    return resp

def is_time_between(begin_time, end_time, check_time=None):
    # If check time is not given, default to current UTC time
    check_time = check_time or datetime.now().time()
    if begin_time < end_time:
        return check_time >= begin_time and check_time <= end_time
    else: # crosses midnight
        return check_time >= begin_time or check_time <= end_time

def get_searched_quotation_data(data,search_value):
    data_new=[];
    
    for x in range(len(data)):
        if((search_value in data[x]["name"]) or (search_value in data[x]["email"]) or (search_value in data[x]["mobile_no"]) or (search_value in data[x]["gender"]) or (search_value in data[x]["city"]) or (search_value in data[x]["quote_number"]) or (search_value in data[x]["quote_sent_on_email"]) or (search_value in data[x]["product_quotes"]) or (search_value in data[x]["method"]) or (search_value in str(data[x]["quote_sent_on"]))):
            data_new.append(data[x]);
    return data_new;
            
def QuotesentStatsDashboardsView_Datatable(request):
        client_id=request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        user_type='all_quotes'
        res_data=get_all_quotesent_stats(c_data.company_name,user_type,'1 day')
        all_quotesData_with_sent_quotes=res_data["userData_with_sent_quotes"]
        
        
        draw = int(request.POST.get('draw', 0))
        start = int(request.POST.get('start', 0))
        length = int(request.POST.get('length', 10))

        # Order column and direction from DataTables
        order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
        order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

        


        # Columns you want to order by
        orderable_columns = ['id','name','email', 'mobile_no', 'gender', 'city', 'quote_number', 'quote_sent_on_email', 'product_quotes', 'method', 'quote_sent_on']  # Adjust based on your actual fields

        # Get column to order by, fallback to first column if index is out of range
        order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

        # Apply ascending or descending ordering
        '''if order_direction == 'desc':
            order_column = '-' + order_column'''

        # Search query from DataTables
        search_value = request.POST.get('search[value]', '')

        # Query the database
        data=all_quotesData_with_sent_quotes

        # Apply search filter if there is any
        if search_value:
            #data = data.filter(name__icontains=search_value) | data.filter(email__icontains=search_value) | data.filter(mobile_no__icontains=search_value) | data.filter(gender__icontains=search_value) | data.filter(city__icontains=search_value) | data.filter(quote_number__icontains=search_value) | data.filter(quote_sent_on_email__icontains=search_value) | data.filter(product_quotes__icontains=search_value)  | data.filter(method__icontains=search_value)  # Modify this filter based on your fields
            data=get_searched_quotation_data(data,search_value);

        # Apply ordering
        #data = data.order_by(order_column)
        if order_direction == 'desc':
            data = sorted(data, key=lambda x: x[order_column], reverse=True)
        else:
            data = sorted(data, key=lambda x: x[order_column])

        total_records = len(data)

        # Paginate data
        paginator = Paginator(data, length)
        page_number = (start // length) + 1
        page_data = paginator.get_page(page_number)

        # Prepare data for DataTables
        data_list = []
        
        k=0
        '''[{'name': 'shareesh', 'email': 'shareeshk@gmail.com', 'mobile_no': '7899439925', 'gender': 'NA', 'city': 'NA', 'quote_number': 'QUOTE_58031726554424153', 'quote_sent_on_email': 'shareeshk@gmail.com', 'product_quotes': 'emergency genie', 'method': 'jbrain'}]'''
        for quotedataobj in page_data:
            
            k=(k+1)
            data_list.append({
                "sno":k,
                "name":quotedataobj["name"],
                "email":str(quotedataobj["email"]),
                "mobile_no":quotedataobj["mobile_no"],
                "gender":str(quotedataobj["gender"]),
                "city":quotedataobj["city"],
                "quote_number":"<a href='assets/brochures/nia/NIA_Quote.pdf' target='_blank' download style='color:#32465a;font-weight:bold;'>"+str(quotedataobj["quote_number"])+"</a>",
                "quote_sent_on_email":quotedataobj["quote_sent_on_email"],
                "product_quotes":str(quotedataobj["product_quotes"]),
                "method":quotedataobj["method"],
                "quote_sent_on":quotedataobj["quote_sent_on"],
                })

        response = {
            'draw': draw,
            'recordsTotal': len(all_quotesData_with_sent_quotes),
            'recordsFiltered': total_records,
            'data': data_list,
        }

        return JsonResponse(response)
        
        
        

        
class QuotesentStatsDashboardsView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        context['title']='Quote Stats'
        
        user_type=self.kwargs['user_type']
        if user_type:
            pass
        else:
            user_type='all_quotes'
        
        context['user_type']=user_type

        client_id=self.request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        
        res_data=get_all_quotesent_stats(c_data.company_name,user_type,'1 day')
        
        context['client_id']=client_id
        context['workflow_quote_sum']=res_data["workflow_quote_sum"]
        context['jbrain_quote_sum']=res_data["jbrain_quote_sum"]
        #context['all_quotesData_with_sent_quotes']=res_data["userData_with_sent_quotes"]
        context['jbrain_and_workflow_quote_sum']=res_data["jbrain_and_workflow_quote_sum"];
        
        return context          
def get_searched_conversation_data(data,search_value):
    data_new=[];
    
    for x in range(len(data)):
        if((search_value in data[x]["name"]) or (search_value in data[x]["email"]) or (search_value in data[x]["mobile_no"]) or (search_value in data[x]["gender"]) or (search_value in data[x]["city"]) or (search_value in data[x]["duration"]) or (search_value in data[x]["created_at_format"])):
            data_new.append(data[x]);
    return data_new;
    
def ConversationlogStatsDashboardsView_Datatable(request,user_type,user_id):
        client_id=request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        res_data=get_all_conversationlog_stats(c_data.company_name,user_type,'1 day')
        userData_conversation=res_data["userData"];
        conversation_sum=res_data["conversation_sum"];
        
        
        draw = int(request.POST.get('draw', 0))
        start = int(request.POST.get('start', 0))
        length = int(request.POST.get('length', 10))

        # Order column and direction from DataTables
        order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
        order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'


        # Columns you want to order by
        orderable_columns = ['created_at','name','email', 'mobile_no', 'gender', 'city', 'duration', 'created_at']  # Adjust based on your actual fields

        # Get column to order by, fallback to first column if index is out of range
        order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

        # Apply ascending or descending ordering
        if order_direction == 'desc':
            order_column = '-' + order_column

        # Search query from DataTables
        search_value = request.POST.get('search[value]', '')

        # Query the database
        data=userData_conversation

        # Apply search filter if there is any
        if search_value:
            #data=get_searched_conversation_data(data,search_value);
            data = data.filter(name__icontains=search_value) | data.filter(email__icontains=search_value) | data.filter(mobile_no__icontains=search_value)  | data.filter(gender__icontains=search_value)  | data.filter(city__icontains=search_value)  | data.filter(duration__icontains=search_value) | data.filter(created_at__icontains=search_value)   # Modify this filter based on your fields

        # Apply ordering
        data = data.order_by(order_column)
        
        total_records = len(data)

        # Paginate data
        paginator = Paginator(data, length)
        page_number = (start // length) + 1
        page_data = paginator.get_page(page_number)

        # Prepare data for DataTables
        data_list = []
        
        k=0
        for conversationdataobj in page_data:
            created_at_format=conversationdataobj.created_at.strftime("%B %d %Y %I:%M %p");
            k=(k+1)
            data_list.append({
                "sno":k,
                "name":conversationdataobj.name,
                "email":str(conversationdataobj.email),
                "mobile_no":conversationdataobj.mobile_no,
                "gender":str(conversationdataobj.gender),
                "city":conversationdataobj.city,
                "duration":conversationdataobj.duration,
                "created_at":"<a href='"+BASE_URL_SERVER+'/dashboard/conversationlog_stats_analytics/conversationlog_info/'+conversationdataobj.user_id+"' style='color:#32465a;font-weight:bold;'>"+str(created_at_format)+"</a>",
                
                })

        response = {
            'draw': draw,
            'recordsTotal': conversation_sum,
            'recordsFiltered': total_records,
            'data': data_list,
        }

        return JsonResponse(response)
        
        
    
class ConversationlogStatsDashboardsView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        context['title']='Quote Stats'
        
        user_type=self.kwargs['user_type']
        user_id=self.kwargs['id']
        if user_type:
            pass
        elif(user_type=="conversationlog"):
            user_type='conversationlog'
        elif(user_type=="conversationlog_info"):
            user_type='conversationlog_info'
        
        context['user_type']=user_type

        client_id=self.request.user.id
        c_data=clientData.objects.get(client_id=client_id)
        
        res_data=get_all_conversationlog_stats(c_data.company_name,user_type,'1 day')
        
        context['client_id']=client_id
        context['conversation_sum']=res_data["conversation_sum"]
        #context['userData']=res_data["userData"]
        context['conversationlog_info']=""
        if(user_type=="conversationlog_info"):
            context['user_id']=user_id
            res_data=get_specific_conversationlog(c_data.company_name,'1 day',user_id)
            context['conversationlog_info']=res_data["conversationlog_info"]
        
        
        return context     
    
def get_all_users_business_stats(request,business_search_input,key):

    #key='evapoler'
    filter_txt=business_search_input
    filter_txt=filter_txt.replace(" ", "");
    res = "".join(filter(lambda x: not x.isdigit(), filter_txt))
    #val=int(filter_txt)
    val=re.findall(r'\d+', filter_txt )
    val=int(val[0])

    cond_query=now.date()#day filter
    new_user_con=(now - timedelta(hours=4)).date()
    #now - timedelta(days=7)).date())
    
    total_users_query = get_data(key,cond_query)
    new_users_query = get_data_new(key,cond_query)
    business_query=get_data_business_query(key,cond_query)
    quote_query=get_data_quote_sent(key,cond_query)
    #res = [app for app in query]

    total_users=len(total_users_query);
    new_users=len(new_users_query);
    business_queries=len(business_query);
    quote_sent=len(quote_query);

    res={"key":key,"total_users":total_users,"new_users":new_users,"business_queries":business_queries,"quote_sent":quote_sent}

    return res

def get_data(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query)
    return list(res)
def get_data_queryset(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query)
    return res    

def get_data_new(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query)
    return list(res)
def get_data_business_query(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query,business_query='yes')
    return list(res)
def get_data_quote_sent(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query,query_sent='yes')
    return list(res)
def get_data_by_user_id(key,user_id,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query,user_id=user_id)
    return list(res)  
def get_userdata_by_user_id(key,user_id):
    try:
        res=jarvinUser.objects.get(company_code=key.strip(),user_id=user_id.strip())
    except jarvinUser.DoesNotExist:
        res = {}
    return res
    
    
def filter_txt_fun(str_val):
    filter_txt=str_val.replace(" ", "");
    res = "".join(filter(lambda x: not x.isdigit(), filter_txt))
    return str(res)

# functions for userstats

def get_all_users_stats_queryset(company_code,user_type,search_input):
    key=company_code
    filter_txt=search_input
    user_type=user_type
    
    res = filter_txt_fun(filter_txt)

    val=re.findall(r'\d+', filter_txt )
    if len(val)>0:
        val=int(val[0])
    else:
        val=1

    cond_query=now.date()#day filter
    new_user_con=(now - timedelta(hours=4)).date()#last four hours
    cond_query=(now - timedelta(days=7)).date()#last 7 days
    
    #return JsonResponse(cond_query,safe=False)
    total_users_query = get_data(key,cond_query)
    validated_users_query = get_data_validated_users(key,cond_query)
    unknown_users_query=get_data_unknown_users(key,cond_query)
   
    total_users=len(total_users_query);
    validated_users=len(validated_users_query);
    unknown_users=len(unknown_users_query);
       
    #return JsonResponse(cond_query);

    names_identified=get_data_names_identified(key,cond_query,user_type)
    email_ids=get_data_email_ids(key,cond_query,user_type)
    mobile_nos=get_data_mobile_nos(key,cond_query,user_type)
    birth_dates=get_data_birth_dates(key,cond_query,user_type)
    gender=get_data_gender(key,cond_query,user_type)

    res1={"names_identified":len(names_identified),"email_ids":len(email_ids),"mobile_nos":len(mobile_nos),"birth_dates":len(birth_dates),"gender":len(gender)}

    #userData=get_user_indiviual_data(key,cond_query,user_type)
    userData=get_user_indiviual_data_queryset(key,cond_query,user_type)

    res={"total_users":total_users,"validated_users":validated_users,"unknown_users":unknown_users,"current_users_data":res1,"userData":userData}

    return res
    
# functions for quotesentstats    
def get_all_quotesent_stats(company_code,user_type,search_input):
    key=company_code
    filter_txt=search_input
    user_type=user_type
    
    res = filter_txt_fun(filter_txt)

    val=re.findall(r'\d+', filter_txt )
    if len(val)>0:
        val=int(val[0])
    else:
        val=1

    cond_query=now.date()#day filter
    new_user_con=(now - timedelta(hours=4)).date()#last four hours
    cond_query=(now - timedelta(days=7)).date()#last 7 days
    

    #return JsonResponse(cond_query,safe=False)
    userData = get_data(key,cond_query)
    
    jbrain_quote_sum=0
    workflow_quote_sum=0
    # userData is one record in user table
    # each record may have quote_sent_jbrain and quote_sent_workflow . these two has bundle of jsons
    # so the userData has 4 records. 2 records has 5=quote_sent_jbrain and 4=quote_sent_workflow
    # 2+2*(4+5) will display records
    userData_with_sent_quotes=[];
    if len(userData)>0:
        for obj in userData:
            if(obj.quote_sent_jbrain!=None):
                quote_sent_jbrain_list=obj.quote_sent_jbrain;
                if(len(quote_sent_jbrain_list)>0):
                    for x in quote_sent_jbrain_list:
                            
                        #userData_with_sent_quotes.append(Merge(obj,x));
                        #userData_with_sent_quotes.append({"name":obj.name,"email":obj.email,"mobile_no":obj.mobile_no,"gender":obj.gender,"city":obj.city,"quote_number":x["quote_number"],"quote_sent_on_email":x["quote_sent_on_email"],"product_quotes":x["product_quotes"],"method":"JBrain","quote_sent_on":x["quote_sent_on"].strftime("%B %d %Y %I:%M %p")});
                        
                        # Convert string to datetime
                        date_time_obj = datetime.strptime(x["quote_sent_on"], '%Y-%m-%d %H:%M:%S.%f')

                        # Format the datetime object to the desired format
                        formatted_date = date_time_obj.strftime('%B %d %Y %I:%M %p')
                        
                        userData_with_sent_quotes.append({"name":obj.name,"email":obj.email,"mobile_no":obj.mobile_no,"gender":obj.gender,"city":obj.city,"quote_number":x["quote_number"],"quote_sent_on_email":x["quote_sent_on_email"],"product_quotes":x["product_quotes"],"method":"JBrain","quote_sent_on":formatted_date});
                        jbrain_quote_sum=jbrain_quote_sum+1
            if(obj.quote_sent_workflow!=None):
                quote_sent_workflow_list=obj.quote_sent_workflow;
                if(len(quote_sent_workflow_list)>0):
                    for x in quote_sent_workflow_list:
                        #userData_with_sent_quotes.append(Merge(obj,x));
                        userData_with_sent_quotes.append({"name":obj.name,"email":obj.email,"mobile_no":obj.mobile_no,"gender":obj.gender,"city":obj.city,"quote_number":x["quote_number"],"quote_sent_on_email":x["quote_sent_on_email"],"product_quotes":x["product_quotes"],"method":"Workflow","quote_sent_on":x["quote_sent_on"].strftime("%B %d %Y %I:%M %p")});
                        workflow_quote_sum=workflow_quote_sum+1
                        
    jbrain_and_workflow_quote_sum=workflow_quote_sum+jbrain_quote_sum;
    res={"workflow_quote_sum":workflow_quote_sum,"jbrain_quote_sum":jbrain_quote_sum,"userData_with_sent_quotes":userData_with_sent_quotes,"jbrain_and_workflow_quote_sum":jbrain_and_workflow_quote_sum}
    
    return res

# functions for conversationlog    
def get_all_conversationlog_stats(company_code,user_type,search_input):
    key=company_code
    filter_txt=search_input
    user_type=user_type
    
    res = filter_txt_fun(filter_txt)

    val=re.findall(r'\d+', filter_txt )
    if len(val)>0:
        val=int(val[0])
    else:
        val=1

    cond_query=now.date()#day filter
    new_user_con=(now - timedelta(hours=4)).date()#last four hours
    cond_query=(now - timedelta(days=7)).date()#last 7 days
    

    #return JsonResponse(cond_query,safe=False)
    userData = get_data_queryset(key,cond_query)
    
    conversation_sum=0
    conversation_sum=len(list(userData));
    res={"conversation_sum":conversation_sum,"userData":userData}
    
    return res  

def get_specific_conversationlog(company_code,search_input,user_id):
    key=company_code
    
    cond_query=now.date()#day filter
    cond_query=(now - timedelta(days=7)).date()#last 7 days
    

    #return JsonResponse(cond_query,safe=False)
    userData_by_user_id = get_data_by_user_id(key,user_id,cond_query)
    for x in userData_by_user_id:
        if(x.user_id==user_id):
            path=x.path;#take last one'''
    current_path_of_text_file=path;
    is_specific_response_there="no";
    log_file_str="";
    if(os.path.exists(current_path_of_text_file)):
        logic_file_handle = open(current_path_of_text_file, 'r')
        Lines = logic_file_handle.readlines() # reading all the lines in form of list
        for indiv_element_line in Lines: # iterating line by line through list
            log_file_str+=indiv_element_line;
   
    log_file_str=log_file_str.replace("\n","<br>")
    res={"conversationlog_info":log_file_str}
    return res  
    

def get_data_validated_users(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(email='NA')
    return list(res)
def get_data_unknown_users(key,cond_query):
    res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query)
    return list(res)
def get_data_names_identified(key,cond_query,user_type):
    if(user_type=='validated_users'):
       res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(name='NA',email='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query).exclude(name='NA')
    else:
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(name='NA')
    return list(res)

def get_data_email_ids(key,cond_query,user_type):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query)
    if(user_type=='validated_users'):
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(email='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query)
    return list(res)
def get_data_mobile_nos(key,cond_query,user_type):
    myquery = { "company_code": key,'mobile_no': {"$ne" : "NA"}}
    if(user_type=='validated_users'):
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(mobile_no='NA',email='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email= 'NA',created_at__gt=cond_query).exclude(mobile_no='NA')
    else:
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(mobile_no='NA')
    return list(res)
def get_data_birth_dates(key,cond_query,user_type):
    if(user_type=='validated_users'):
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(dob='NA',email='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query).exclude(dob='NA')
    else:
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(dob='NA')
    return list(res)
def get_data_gender(key,cond_query,user_type):
    if(user_type=='validated_users'):
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(email='NA',gender='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query).exclude(gender='NA')
    else:
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(gender='NA')
    return list(res)
def get_user_indiviual_data(key,cond_query,user_type):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query)
    if(user_type=='validated_users'):
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(email='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query)
    return list(res)
def get_user_indiviual_data_queryset(key,cond_query,user_type):
    res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query)
    if(user_type=='validated_users'):
        res=jarvinUser.objects.filter(company_code=key,created_at__gt=cond_query).exclude(email='NA')
    elif(user_type=='unknown_users'):
        res=jarvinUser.objects.filter(company_code=key,email='NA',created_at__gt=cond_query)
    return res 

# functions for userstats
