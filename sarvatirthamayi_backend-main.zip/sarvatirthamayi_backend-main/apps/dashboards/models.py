# Create your models here.
from django.db import models
# from db_connection import db

# Create your models here.
# user_collection=db['user']
# products_collection=db['products']

class jarvinUser(models.Model):
    client_ip_address=models.TextField()
    name=models.TextField()
    user_id=models.TextField()
    email=models.TextField()
    mobile_no=models.TextField()
    company_code=models.TextField()
    path=models.TextField()
    type=models.TextField()
    age=models.TextField()
    gender=models.TextField()
    dob=models.TextField()
    city=models.TextField()
    need_type=models.TextField()
    living_status=models.TextField()
    mother_tongue=models.TextField()
    respect_index=models.TextField()
    affinity_index=models.TextField()
    query_sent=models.TextField()
    business_query=models.TextField()
    quote_sent_workflow=models.TextField()
    timestamp=models.DateTimeField()
    chat_timings=models.JSONField(default=list)
    time_spent=models.JSONField(default=list)
    created_at=models.DateTimeField()
    lastconversation_at=models.TextField()
    modified_at=models.DateTimeField(auto_now_add=True)
    duration=models.TextField()
    conversation_info_metrics=models.JSONField(default=list)
    quote_sent_jbrain=models.JSONField(default=list)

def default_chat_timings():
    return {"default_time": []}  # Replace with your desired default structure

def default_time_spent():
    return {"default_duration": []}  

class jarvinProducts(models.Model):
    #models.JSONField()
    product_code=models.TextField()
    company_code=models.TextField()
    product_name=models.TextField()
    listing_structure=models.TextField()
    brouchure=models.TextField(default='')
    brouchure_downloads=models.TextField()
    discussed_count=models.TextField()
    brouchure_downloads_in_detail=models.TextField()
    discussed_in_detail=models.JSONField(default=list)
    created_at=models.DateTimeField(auto_now_add=True)
    modified_at=models.DateTimeField(auto_now_add=True)