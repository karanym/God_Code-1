from django.views.generic import TemplateView
from django.views.generic.edit import FormView
from web_project import TemplateLayout
from .models import jarvinUser,jarvinProducts
from ..authentication.models import clientData
from datetime import date,datetime, timedelta, time
import json,re,os
from django.http import HttpResponse
from django.http import JsonResponse
import datetime as dt

from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.utils import timezone
from datetime import timedelta
from ajax_datatable.views import AjaxDatatableView
from django.core.paginator import Paginator
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
now = timezone.now()

@method_decorator(login_required, name='dispatch')
class LeadsDashboardsView(TemplateView):
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context['title']='Dashboard'
        return context
 