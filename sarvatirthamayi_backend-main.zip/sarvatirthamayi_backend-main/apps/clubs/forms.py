from django import forms
from .models import *

class ClubForm(forms.ModelForm):

    CLUB_STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    club_status = forms.ChoiceField(
        choices=CLUB_STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    CLUB_TYPE_CHOICES = [
        ("", "Select Type"),
        ("Devotional & Spiritual", "Devotional & Spiritual"),
        ("Pilgrimage & Travel", "Pilgrimage & Travel"),
        ("Community & Charity Clubs", "Community & Charity Clubs"),
        ("Knowledge & Cultural Clubs", "Knowledge & Cultural Clubs"),
    ]
    club_type = forms.ChoiceField(
        choices=CLUB_TYPE_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    class Meta:
        model = Club
        fields = ["name", "price", "description", "image", "benefits", "club_type", "max_members", "club_status"]
        labels = {
            'name': 'Club Name',
            'price': 'Price',
            'description': 'Description',
            'image': 'Image',
            'club_status': 'Status',
            'club_type':'Club Type',
            'benefits':'Benefits',
            'max_members':'Max members',
        }
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Club Name',
            }),
            'image': forms.ClearableFileInput(attrs={
                'class': 'form-control',
            }),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "Enter club description..."}),
            "benefits": forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "List club benefits..."}),
            "club_type": forms.Select(attrs={"class": "form-control"}),
            "price": forms.NumberInput(attrs={"class": "form-control", "placeholder": "Enter club price"}),
            "max_members": forms.NumberInput(attrs={"class": "form-control", "placeholder": "Max members allowed"}),
        }

class ClubMemberForm(forms.ModelForm):
    
    STATUS_CHOICES = [
        ("active", "Active"),
        ("inactive", "Inactive"),
        ("pending", "Pending"),
    ]

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        widget=forms.Select(attrs={"class": "form-control"})
    )

    class Meta:
        model = ClubMember
        fields = ["name", "email", "phone", "club", "status"]
        labels = {
            "name": "Full Name",
            "email": "Email Address",
            "phone": "Phone Number",
            "club": "Select Club",
            "status": "Membership Status",
        }
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter full name"}),
            "email": forms.EmailInput(attrs={"class": "form-control", "placeholder": "Enter email address"}),
            "phone": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter phone number"}),
            "club": forms.Select(attrs={"class": "form-control"}),
        }