from django.urls import path
from .views import *
from .views_club_member import *

urlpatterns = [
    path('clubs/', ClubListView.as_view(), name='clubs'),
    path('club/add/', ClubCreateView.as_view(), name='club-add'), 
    path('club_list/', club_list, name='club-list'),
    path('delete-club/<int:record_id>/', delete_club, name='delete-club'),
    path('club/<int:pk>/edit/', ClubUpdateView.as_view(), name='club-edit'),
    path("change-club-status/", change_club_status, name="change-club-status"),
    path('club_member/', ClubMemberListView.as_view(), name='club-member'),
    path('club_member_list/', club_member_list, name='club-member-list'),
    path("update_member_status/", update_member_status, name="update-club-member-status"),
    path('delete-club-member/<int:record_id>/', delete_club_member, name='delete-club-member'),
]