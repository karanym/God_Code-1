from django.apps import AppConfig


class ClubsConfig(AppConfig):
    name = 'clubs'
