from django.db import models
from django.utils.timezone import now

class Club(models.Model):
    CLUB_TYPE_CHOICES = [
        ("Devotional & Spiritual", "Devotional & Spiritual"),
        ("Pilgrimage & Travel", "Pilgrimage & Travel"),
        ("Community & Charity Clubs", "Community & Charity Clubs"),
        ("Knowledge & Cultural Clubs", "Knowledge & Cultural Clubs"),
    ]

    CLUB_STATUS_CHOICES = [
        ("active", "Active"),
        ("inactive", "Inactive"),
        ("pending", "Pending Approval"),
    ]

    name = models.CharField(max_length=255, unique=True)
    price = models.TextField(default='')
    description = models.TextField(default='')
    image = models.ImageField(upload_to="clubs/",blank=True)
    benefits = models.TextField(blank=True)
    club_type = models.CharField(max_length=50,default="")
    max_members = models.PositiveIntegerField(default=100)
    club_status = models.CharField(max_length=20, choices=CLUB_STATUS_CHOICES, default="pending")
    timestamp = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.name} ({self.get_club_type_display()})"

class ClubMember(models.Model):
    name = models.CharField(max_length=255)
    user_id = models.IntegerField(null=True, blank=True, default=None)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    club = models.PositiveIntegerField()
    joined_date = models.DateField(auto_now_add=True)
    
    status_choices = [
        ("active", "Active"),
        ("inactive", "Inactive"),
        ("pending", "Pending"),
    ]
    status = models.CharField(max_length=10, choices=status_choices, default="pending")
    approved_on = models.DateTimeField(null=True, blank=True)
    rejected_on = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(null=True, blank=True, default='')

    last_renewal_date = models.DateField(null=True, blank=True)
    renewal_history = models.JSONField(default=list)  # List of dicts like [{"date": "2025-03-21", "price": 1000}, ...]

    def __str__(self):
        return self.name
