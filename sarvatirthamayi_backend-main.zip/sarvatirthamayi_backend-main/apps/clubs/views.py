from django.views.generic import ListView, CreateView, UpdateView
from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.urls import reverse_lazy
from django.contrib import messages
from .models import Club
from .forms import ClubForm
from web_project import TemplateLayout

class ClubListView(ListView):
    model = Club
    template_name = 'club/club_list.html'
    context_object_name = 'clubs'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Club List',
        })
        return context

class ClubCreateView(CreateView):
    model = Club
    form_class = ClubForm
    template_name = 'club/club_form.html'
    success_url = reverse_lazy('clubs')

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, "Club added successfully!")
        return response

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context["title"] = "Add New Club"
        return context

class ClubUpdateView(UpdateView):
    model = Club
    form_class = ClubForm
    template_name = 'club/club_form.html'
    success_url = reverse_lazy('clubs')

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, "Club updated successfully!")
        return response

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context["title"] = "Edit Club"
        return context

def club_list(request):
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))
    
    order_column_index = int(request.POST.get('order[0][column]', 0))
    order_direction = request.POST.get('order[0][dir]', 'asc')

    orderable_columns = ['id', 'name', 'club_status']
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]
    if order_direction == 'desc':
        order_column = '-' + order_column

    search_value = request.POST.get('search[value]', '')

    if request.user.is_superuser:
        initial_data = Club.objects.all()
    else:
        initial_data = Club.objects.filter(created_by=request.user)

    if search_value:
        initial_data = initial_data.filter(name__icontains=search_value)

    initial_data = initial_data.order_by(order_column)
    total_records = initial_data.count()

    paginator = Paginator(initial_data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    data_list = []
    for index, obj in enumerate(page_data, start=1):
        data_list.append({
            "sno": index,
            "name": obj.name,
            "club_type": obj.club_type,
            "club_price": "₹ "+str(obj.price),
            "club_status": f'<span class="badge bg-{ "success" if obj.club_status == "active" else "danger"} status-badge" data-id="{obj.id}" style="cursor:pointer;">{obj.club_status.capitalize()}</span>',
            "actions": f'<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu"><a class="dropdown-item" href="/club/{obj.id}/edit"><i class="bx bx-edit-alt me-1"></i> Edit</a><button type="button" class="dropdown-item" onclick="delete_record({obj.id})"><i class="bx bx-trash me-1"></i> Delete</button></div></div>',
        })

    response = {
        'draw': draw,
        'recordsTotal': total_records,
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def change_club_status(request):
    if request.method == "POST":
        club_id = request.POST.get("club_id")
        try:
            club = Club.objects.get(id=club_id)
            new_status = "inactive" if club.club_status == "active" else "active"
            club.club_status = new_status
            club.save()
            return JsonResponse({"success": True, "status": new_status})
        except Club.DoesNotExist:
            return JsonResponse({"success": False, "error": "Club not found"})
    
    return JsonResponse({"success": False, "error": "Invalid request"})

def delete_club(request, record_id):
    if request.method == "POST":
        try:
            club = Club.objects.get(id=record_id)
            club.delete()
            return JsonResponse({'success': True, 'message': 'Club deleted successfully'})
        except Club.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Club not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)
