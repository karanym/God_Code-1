
from django.views.generic import ListView, CreateView, UpdateView
from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.urls import reverse_lazy
from django.contrib import messages
from .models import *
from .forms import *
from web_project import TemplateLayout
from django.core.mail import send_mail
import json,re,os,sys;
import requests
from apps.pages.models import *

class ClubMemberListView(ListView):
    model = Club
    template_name = 'club_member/club_member_list.html'
    context_object_name = 'club_member'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Club Member List',
        })
        return context
    

def club_member_list(request):
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    order_column_index = int(request.POST.get('order[0][column]', 0))
    order_direction = request.POST.get('order[0][dir]', 'asc')

    orderable_columns = ['id', 'name', 'status']
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]
    if order_direction == 'desc':
        order_column = '-' + order_column

    search_value = request.POST.get('search[value]', '')

    initial_data = ClubMember.objects.all()

    if search_value:
        initial_data = initial_data.filter(name__icontains=search_value)

    initial_data = initial_data.order_by(order_column)
    total_records = initial_data.count()

    paginator = Paginator(initial_data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    data_list = []
    for index, obj in enumerate(page_data, start=1):

        # Get Club Name
        club = Club.objects.filter(id=obj.club).first()
        club_name = club.name  # Fetching club name

        user_id=obj.user_id
        user_details=''
        if user_id:
            s_data=SmtUsers.objects.filter(user_id=user_id).first()
            if s_data:
                user_details='<br><br><small><b>Registered User :</b><br>'+s_data.name+'<br>'+s_data.mobile+'<br>'+s_data.email+'</small>'
            else:
                user_details='-'

        # Format Date
        formatted_date = obj.joined_date.strftime('%d-%m-%Y') if obj.joined_date else "N/A"

        # Status Button
        if obj.status == "pending":
            status_html = f'''
                <button class="btn btn-sm btn-success accept-btn" data-id="{obj.id}">Accept</button>
                <button class="btn btn-sm btn-danger reject-btn" data-id="{obj.id}">Reject</button>
            '''
        else:
            status_html = f'<span class="badge bg-{ "success" if obj.status == "active" else "danger"}">{obj.status.capitalize()}</span>'

        # Actions
        actions_html = f'''
            <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                    <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                    <button type="button" class="dropdown-item" onclick="delete_record({obj.id})">
                        <i class="bx bx-trash me-1"></i> Delete
                    </button>
                </div>
            </div>
        '''

        # Append Data
        data_list.append({
            "sno": index,
            "name": f'{obj.name}<br> <b>Club : {club_name}</b><br>Joined Date : {formatted_date}' + user_details,
            "email": obj.email,
            "phone": obj.phone,
            "status": status_html,
            "actions": actions_html,
        })

    response = {
        'draw': draw,
        'recordsTotal': total_records,
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)


def update_member_status(request):
    if request.method == "POST":
        member_id = request.POST.get("id")
        new_status = request.POST.get("status")
        rejection_reason = request.POST.get("rejection_reason", "")
        member = get_object_or_404(ClubMember, id=member_id)
        member.status = new_status
        member.save()

        club = Club.objects.filter(id=member.club).first()
        club_name = club.name  # Fetching club name
        name=member.name
        email=member.email

        if new_status == "active":
            member.status = "active"
            member.approved_on = now()
            member.rejected_on = None
            subject = "Membership Approved!"
            message = f"Dear {member.name},\n\nYour membership for {club_name} has been approved!\n\nWelcome to our club."
            template_name='sarvatirthamayi_club_member_approval'
        else:
            member.status = "inactive"
            member.rejected_on = now()
            member.approved_on = None
            member.rejection_reason = rejection_reason
            subject = "Membership Rejected"
            message = f"Dear {member.name},\n\nWe regret to inform you that your membership for {club_name} has been rejected."
            template_name='sarvatirthamayi_club_member_rejection'

        member.save()


        # Send Email
        send_mail(
            subject,
            message,
            "hellojarvin@gmail.com",  # From Email
            [email],  # To Email
            fail_silently=False,
        )

        # Send WhatsApp Message

        member_phone=member.phone
    
        if len(member_phone) == 10 and member_phone.isdigit():
            mobile = "91" + member_phone  
            phone_number=mobile

            #approved_on=member.approved_on.strftime("%d-%m-%Y %H:%M") if member.approved_on else None

            payload = {
                "messaging_product": "whatsapp",
                "to": str(phone_number),
                "type": "template",
                "template": {
                    "name": str(template_name),
                    "language":{
                        "code":"en"
                    },
                    "components": [
                    {
                        "type": "body",
                        "parameters": [
                        { "type": "text", "text": str(name) },
                        { "type": "text", "text": str(club_name) }
                        ]
                    }
                ]
                }
            }

            try:
                token='EAAL7v9krplEBO7Efx8LOnl4Antl0gWgOtzTUi28INCyAoiia2wIDZBIa4qZCDpdYZApKHmtuOkgXdMe4IrYZCGRSCe2NZA9m2zs4U2iEebbsi14BBTPpKUthgr51iJmo7PPDW7xuX7amLZBVeYhaTGnloEiYupejhmiFm0JPud6j0e2J2NOdX7yErfqxjmfsbG6AZDZD'
                phonenumber_id='371941399332594' #jarvin

                data_json = json.dumps(payload)
                url = 'https://graph.facebook.com/v20.0/'+str(phonenumber_id)+'/messages'
                headers = {'content-type': 'application/json',"Accept": "application/json", 'Accept-Charset': 'UTF-8','Authorization':'Bearer '+str(token)}
                r = requests.post(url, data=data_json, headers=headers)
                res_obj= json.loads(r.text)

                print("URL:", url)  # Debugging
                print("Headers:", headers)
                print("Response:", r.status_code, r.text)
                
                if r.status_code == 200:
                    message_res='Message has been sent successfully'
                else:
                    message_res='Message is not sent. Status code is '+str(r.status_code)+'||'+str(url)+'||'+r.reason
            except:
                res_obj= 'error in sending whatsapp messages'
                message_res='Error in message sending'
        
            #message to whatsapp
        #send_whatsapp_message(member.phone, whatsapp_message)

        return JsonResponse({"success": True, "message": f"Member status updated to {new_status}"})
    return JsonResponse({"success": False, "message": "Invalid request"}, status=400)

def delete_club_member(request, record_id):
    if request.method == "POST":
        try:
            club = ClubMember.objects.get(id=record_id)
            club.delete()
            return JsonResponse({'success': True, 'message': 'Club member deleted successfully'})
        except ClubMember.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Club member not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)
