from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import *

from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
from django.core.paginator import Paginator
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from django.core.files.base import ContentFile, File

from ..authentication.forms import clientform

from ..authentication.models import clientData
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib.auth.hashers import *
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import EmailMessage

from ..authentication.forms import ChangePasswordForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin

import requests
from django.views import View
from .forms import *
from django.shortcuts import get_object_or_404

@method_decorator(login_required, name='dispatch')

class PagesView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        #custom code
        
        #admin_data = admin_collection.objects.all() #for all the records 
        
        context["curr_id"]=self.request.user.id
        client_id=self.request.user.id

        try:

            if self.request.user.is_superuser:
                c_data=clientData.objects.filter(admin_type='admin')
            else:
                client_id=self.request.user.id
                c_data=clientData.objects.get(client_id=client_id)
            
        except clientData.DoesNotExist:
            c_data = None 

      
        if c_data!='':
            context["c_form"]=clientform(initial={'client_id':client_id})
            context['c_data']=c_data
            
        else:
            context["c_form"]=clientform(initial={'ai_client_id':client_id})

        #custom code

        return context
    

class BookingListView(ListView):
    model = TripBookingConfirmation
    template_name = 'booking/bookings.html'
    context_object_name = 'bookings'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Booking List',
        })
        return context

def bookings_list(request):

    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','name','email','mobile']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    initial_data = TripBookingConfirmation.objects.filter()
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(name__icontains=search_value) | data.filter(email__icontains=search_value) | data.filter(mobile__icontains=search_value) | data.filter(trip_title__icontains=search_value)

    # Apply ordering
    data = data.order_by(order_column)

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    for obj in page_data:
        
        
        trip_id=obj.trip_id
        trip_title=''
        if trip_id:
            t_data=Trips.objects.filter(id=trip_id).first()
            trip_title=t_data.trip_title
        
        user_id=obj.user_id
        user_details=''
        if user_id:
            s_data=SmtUsers.objects.filter(user_id=user_id).first()
            if s_data:
                user_details='<br><br><small><b>Registered User :</b><br>'+s_data.name+'<br>'+s_data.mobile+'<br>'+s_data.email+'</small>'
            else:
                user_details='-'

        k=(k+1) 
        formatted_start_date = obj.start_date.strftime("%d-%m-%Y")  
        formatted_date = obj.created_at.strftime("%d-%m-%Y %I:%M %p")  


        trip_details='<small>'
        trip_details+='<b class="text-primary">'+"₹"+ str(obj.trip_price)+'/- </b><br>'
        trip_details+=str(obj.no_of_days)+' days <br>'
        trip_details+=str(obj.no_of_devotees)+' devotees <br>'
        trip_details+="Trip Type : " +str(obj.type_of_trip)+' <br>'
        trip_details+='</small>'

        data_list.append({
            "sno":k,
            "title":trip_title+'<br>'+str(trip_details),
            "name":obj.name+'<br>'+str(obj.email)+user_details,
            "mobile":obj.mobile,
            "start_date":formatted_start_date,
            "timestamp":formatted_date
            })

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)