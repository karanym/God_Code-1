TIME_COUNT = [{"label":f'{i}', "value" : f'{i}'} for i in range(1, 24)]
ASSIGN_LEAD_COUNT = [{"label":f'{i}', "value" : f'{i}'} for i in range(1, 30)]
ESSENTIAL_WORDS = ['if', 'send', 'dont send', 'do not send', 'all', 'everyone' ,'jarvin','hi','hello','hey','after','assign','lead','robin','round','to','repeat','salesreps','salesrep']
   