from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import *

from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
from django.core.paginator import Paginator
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from django.core.files.base import ContentFile, File

from ..authentication.forms import clientform
from ..authentication.models import clientData
from django.views import View
from .forms import *
from django.shortcuts import get_object_or_404



"""
This file is a view controller for multiple pages as a module.
Here you can override the page view layout.
Refer to pages/urls.py file for more pages.
"""
ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'gif'])
UPLOAD_FOLDER = str(BASE_DIR)+'/upload'

@method_decorator(login_required, name='dispatch')

class RitualsLabelsListView(ListView):
    model = RitualsLabels
    template_name = 'rituals_labels/rituals_labels_list.html'
    context_object_name = 'rituals_labels'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'rituals_labels List',
        })
        return context

class RitualsLabelsCreateView(CreateView):
    model = RitualsLabels
    form_class =RitualsLabelsForm

    template_name = 'rituals_labels/rituals_labels_form.html'
    success_url = reverse_lazy('rituals-labels')

    def form_valid(self, form):
        # Save the form and redirect
        return super().form_valid(form)

    def form_invalid(self, form):
        # Debug: Print form errors to console
        print("Form errors:", form.errors)
        return super().form_invalid(form)
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Add New RitualsLabels',
        })
        return context

class RitualsLabelsUpdateView(UpdateView):
    model = RitualsLabels
    form_class = RitualsLabelsForm
    template_name = 'rituals_labels/rituals_labels_form.html'
    success_url = reverse_lazy('rituals-labels')

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        id=self.kwargs['pk']
        context['id']=id
        context.update({
            'title': 'Edit Activity',
        })
        return context
    
def rituals_labels_list(request):

    title = request.POST.get('title')
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','title','status']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    initial_data = RitualsLabels.objects.filter()
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(title__icontains=search_value) 

    # Apply ordering
    data = data.order_by(order_column)

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    for obj in page_data:
        k=(k+1) 
        if obj.image =='':
            img_str='No image'
        else:
            img_str='<img src="'+obj.image.url+'" alt="" />'

        data_list.append({
            "sno":k,
            "title":obj.title,
            "image":img_str,
            "actions":f'<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu"><a class="dropdown-item" href="'+BASE_URL_SERVER+'/rituals_labels/'+str(obj.id)+'/edit"><i class="bx bx-edit-alt me-1"></i> Edit</a><button type="button" class="dropdown-item" onclick="delete_record('+str(obj.id)+')"><i class="bx bx-trash me-1"></i> Delete</button></div></div>'})

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def delete_rituals_labels(request, record_id):
    if request.method == "POST":
        try:
            pmt = RitualsLabels.objects.get(id=record_id)
            pmt.delete()
            return JsonResponse({'success': True, 'message': 'Data deleted successfully'})
        except RitualsLabels.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Record not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)


