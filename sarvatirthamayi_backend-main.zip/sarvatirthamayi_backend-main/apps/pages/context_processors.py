from datetime import datetime,timedelta
from dateutil.relativedelta import relativedelta
import json,re,os,sys;

def common_list(request):
    tc = [(f'{i}', f'{i}') for i in range(1, 24)]
    e_words = ['if', 'send', 'dont send', 'do not send', 'all', 'everyone' ,'jarvin','hi','hello','hey']

    # 'COMMON_LIST': [
    #         ('option1', 'Option 1'),
    #         ('option2', 'Option 2'),
    #         ('option3', 'Option 3'),
    #     ]
    return {
        'TIME_COUNT': tc,
        'ESSENTIAL_WORDS': e_words
    }

def generate_timestamps(duration, unit,frequency,from_timstamp):
    
    duration =int(duration) 
    now = from_timstamp
    unit = unit.lower() 
    future_time=now

    if unit!='' and duration !='':
        if unit == 'hour' or unit == 'hours' or unit == 'hrs' or unit == 'hr':
            future_time = now + timedelta(hours=duration)
        elif unit == 'day' or unit == 'days':
            future_time = now + timedelta(days=duration)
        elif unit == 'week' or unit == 'weeks':
            future_time = now + timedelta(weeks=duration)
        elif unit == 'month' or unit == 'months':
            future_time = now + relativedelta(months=duration)
        else:
            pass
            #raise ValueError("Invalid unit. Use 'hour', 'day', or 'week', or 'months' ")
    
    start_time =  future_time # Start 1 hour from now
    timestamps = []

    if frequency!='' and frequency is not None: 
        match = re.search(r'\bfor\s+(\d+)', frequency, re.IGNORECASE)
        if match:
            duration_in_weeks=int(match.group(1))
        
            word_list = frequency.lower().split()
            if 'once' in word_list:
                occurrences_per_week=1
            if 'twice' in word_list:
                occurrences_per_week=2
            if 'thrice' in word_list:
                occurrences_per_week=3

            days_in_week = 7

            # Calculate the gap (in days) between each occurrence in a week
            gap_between_occurrences = days_in_week / occurrences_per_week

            for week in range(duration_in_weeks):
                for occurrence in range(occurrences_per_week):
                    new_time = start_time + timedelta(days=(week * days_in_week) + (occurrence * gap_between_occurrences))
                    timestamps.append(new_time.strftime('%Y-%m-%d %H:%M:%S'))
    else:
        timestamps.append(future_time.strftime('%Y-%m-%d %H:%M:%S'))

    return timestamps