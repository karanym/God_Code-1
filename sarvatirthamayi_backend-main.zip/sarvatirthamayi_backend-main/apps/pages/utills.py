import requests

def send_sms_via_msg91(api_key, sender_id, mobile_number, message):
    """
    Sends an SMS using MSG91 API.

    Args:
        api_key (str): Your MSG91 API key.
        sender_id (str): Sender ID approved by MSG91.
        mobile_number (str): Recipient's mobile number (with country code).
        message (str): SMS content.
    
    Returns:
        dict: Response from MSG91 API.
    """
    url = "https://api.msg91.com/api/v5/flow/"
    payload = {
        "sender": sender_id,
        "flow_id": '1207161198879960336',
        "message": message,
        "route": "4",  # Transactional route (for promotional use '1')
        "mobiles": mobile_number
    }
    # payload = {
    #     "sender": sender_id,  # Replace with your approved Sender ID
    #     "route": "4",          # '4' is for transactional messages
    #     "country": "91",       # Country code
    #     "sms": [
    #         {
    #             "message": message,  # Replace with your message
    #             "to": ["6384770034"]                   # Replace with recipient numbers
    #         }
    #     ]
    # }
        
    headers = {
        "authkey": api_key,
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error while sending SMS: {e}")
        return None
