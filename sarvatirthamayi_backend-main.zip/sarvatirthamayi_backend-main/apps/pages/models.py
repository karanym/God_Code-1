from django.db import models
from django.core.exceptions import ValidationError
from PIL import Image
from bson import Decimal128
from django.contrib.auth.models import User
from django.utils.timezone import now

class LatestActivities(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='latest_activities/')
    status = models.CharField(max_length=10)

    def clean(self):
        """Validate that the uploaded image is exactly 400x250 pixels."""
        if self.image:
            img = Image.open(self.image)
            if img.width != 400 or img.height != 250:
                raise ValidationError("Image must be exactly 400x250 pixels.")

    def __str__(self):
        return self.title

class Trips(models.Model):
    trip_title = models.CharField(max_length=200)
    thumbnail_image = models.ImageField(upload_to='trips/')
    popular_status = models.CharField(max_length=10)
    status = models.CharField(max_length=10)
    type_of_trip = models.CharField(max_length=50,default='')
    price = models.DecimalField(max_digits=10, decimal_places=2, default=1000.00)

    @property
    def price_as_float(self):
        return float(self.price) if isinstance(self.price, Decimal128) else self.price
    
    def clean(self):
        """Validate that the uploaded thumbnail image is exactly 200x250 pixels."""
        if self.thumbnail_image:
            img = Image.open(self.thumbnail_image)
            if img.width != 200 or img.height != 250:
                raise ValidationError("Thumbnail image must be exactly 200x250 pixels.")

    def __str__(self):
        return self.trip_title


class TripsDetails(models.Model):
    trip_id = models.IntegerField()  # Changed from CharField
    image_caption = models.CharField(max_length=200)
    banner_image = models.ImageField(upload_to='trip_details/')
    short_description = models.TextField()
    status = models.CharField(max_length=10)

    # New Fields
    trip_duration = models.CharField(max_length=50,default=1)  # e.g., "3 Days 2 Nights"
    no_of_temples = models.IntegerField(default=0)
    temple_names = models.JSONField(blank=True, null=True)  # will hold list like ["Temple A", "Temple B"]
    trip_description = models.TextField(blank=True, null=True)
    facilities_covered = models.TextField(blank=True, null=True)
    trip_assembly_point = models.CharField(max_length=200, blank=True, null=True)
    min_group_size = models.IntegerField(default=1)
    max_group_size = models.IntegerField(default=50)

    def clean(self):
        """Validate that the uploaded banner image is exactly 400x250 pixels."""
        if self.banner_image:
            img = Image.open(self.banner_image)
            if img.width != 400 or img.height != 250:
                raise ValidationError("Banner image must be exactly 400x250 pixels.")

    def __str__(self):
        return self.image_caption


class TripsDetailItem(models.Model):
    trip_id = models.IntegerField()  # Changed from TextField
    list_title = models.CharField(max_length=255)
    list_description = models.TextField()

    def __str__(self):
        return f"{self.list_title} (Trip ID: {self.trip_id})"


class TripsImages(models.Model):
    trip_id = models.IntegerField()  # Changed from TextField
    image_caption = models.CharField(max_length=200)
    trip_image = models.ImageField(upload_to='trips_images/')
    trip_image_status = models.CharField(max_length=10)

    def clean(self):
        """Validate that the uploaded trip image is exactly 400x250 pixels."""
        if self.trip_image:
            img = Image.open(self.trip_image)
            if img.width != 400 or img.height != 250:
                raise ValidationError("Trip image must be exactly 400x250 pixels.")

    def __str__(self):
        return self.image_caption


class TripBookingConfirmation(models.Model):
    trip_id = models.IntegerField()  # Changed from TextField
    user_id = models.IntegerField(null=True, blank=True,default=None)
    trip_title = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    mobile = models.CharField(max_length=15)
    email = models.CharField(max_length=50, default='')
    start_date = models.DateField()  # Stores date and time of visit
    no_of_days = models.CharField(max_length=15)
    no_of_devotees = models.CharField(max_length=15)
    type_of_trip = models.CharField(max_length=15)
    trip_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    request_on = models.DateTimeField(auto_now_add=True)  # Auto timestamp when created
    created_at = models.DateTimeField(auto_now_add=True)  # Auto timestamp when created

    def __str__(self):
        return f"{self.name} - {self.mobile} - {self.start_date}"


class Temples(models.Model):
    temple_name = models.CharField(max_length=200)
    icon_image = models.ImageField(upload_to='temples/')
    short_description = models.TextField()
    status = models.CharField(max_length=10)
    temple_state=models.TextField(default='')
    diety=models.TextField(default='')
    type_of_temple=models.TextField(default='')
    who_can_view=models.TextField(default='')
    temple_admin=models.TextField(default='')
    last_updated_at = models.DateTimeField(auto_now=True)
    approved_status = models.CharField(max_length=10, default="pending")  # pending, approved, rejected
    approved_on = models.DateTimeField(null=True, blank=True)
    rejected_on = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(null=True, blank=True)

    def clean(self):
        """Validate that the uploaded icon image is exactly 200x250 pixels."""
        if self.icon_image:
            img = Image.open(self.icon_image)
            if img.width != 200 or img.height != 250:
                raise ValidationError("Icon image must be exactly 200x250 pixels.")

    def __str__(self):
        return self.temple_name


class TempleDetail(models.Model):
    temple_id = models.TextField()  
    detail_image = models.ImageField(upload_to='treatment_details/', null=True, blank=True)
    short_description = models.TextField()
    highlights = models.TextField()

    def __str__(self):
        return f"Temple : {self.temple_id} - {self.short_description[:30]}"

class TempleDetailItem(models.Model):
    temple_id = models.TextField()  
    list_title = models.CharField(max_length=255)
    list_description = models.TextField()

    def __str__(self):
        return f"{self.list_title} (Temple ID: {self.temple_id})"
    
class TempleImages(models.Model):
    temple_id = models.IntegerField()  # Changed from CharField
    image = models.ImageField(upload_to='temples/')
    image_caption = models.CharField(max_length=200)

    def clean(self):
        """Validate that the uploaded temple image is exactly 400x250 pixels."""
        if self.image:
            img = Image.open(self.image)
            if img.width != 400 or img.height != 250:
                raise ValidationError("Temple image must be exactly 400x250 pixels.")

    def __str__(self):
        return self.image_caption

class TempleDynamicField(models.Model):
    temple_id = models.IntegerField()
    temple_admin = models.IntegerField(default=1)
    field_name = models.CharField(max_length=255)
    field_description = models.TextField()
    timestamp = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.field_name} - {self.temple_id} ({self.timestamp})"

class SmtUsers(models.Model):
    user_id = models.IntegerField(null=True, blank=True,default=None)
    name = models.CharField(max_length=255, default='')
    mobile = models.CharField(max_length=15, default='')
    email = models.CharField(max_length=50, default='')
    password = models.CharField(max_length=50, default='')
    city = models.CharField(max_length=255, default='')
    mobile_verified_status = models.BooleanField(default=False)
    mobile_otp = models.TextField(default='')
    email_verified_status = models.BooleanField(default=False)
    email_otp = models.TextField(default='')
    profile = models.ImageField(upload_to='profiles/', null=True, blank=True)  # Profile image
    created_at = models.DateTimeField(auto_now_add=True)
    login_history = models.JSONField(default=list)

    def __str__(self):
        return f"{self.name} - {self.mobile} - {self.city}"

class RitualsLabels(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='rituals_labels/',default='',null=True)
    status = models.CharField(max_length=10)
    timestamp=models.DateTimeField(auto_now=True) 

    def clean(self):
        """Validate that the uploaded image is exactly 400x250 pixels."""
        if self.image:
            img = Image.open(self.image)
            if img.width != 400 or img.height != 250:
                raise ValidationError("Image must be exactly 400x250 pixels.")

    def __str__(self):
        return self.title
class RitualLabelsRequest(models.Model):
    title = models.CharField(max_length=255)
    requested_by = models.CharField(max_length=50)
    requested_on = models.DateTimeField(default=now)
    approved_on=models.DateTimeField(default=now)
    status = models.CharField(max_length=10, default="inactive")

class Rituals(models.Model):
    temple_id = models.CharField(max_length=50)
    rituals_label_id = models.CharField(max_length=50)
    ritual_category = models.CharField(max_length=50,default="")
    ritual_type = models.CharField(max_length=10)
    ritual_status = models.CharField(max_length=10)
    ritual_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    ritual_benefits = models.TextField()
    ritual_procedure = models.TextField()
    ritual_prasadham_or_giveback = models.TextField(default='')
    ritual_duration = models.CharField(max_length=50)
    ritual_perform_time = models.CharField(max_length=50,default="")
    ritual_frequency = models.CharField(max_length=50,default="")
    ritual_days = models.CharField(max_length=50,default="")
    ritual_updated_by = models.CharField(max_length=50) 
    ritual_updated_on = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Ritual {self.rituals_label_id} for Temple {self.temple_id}"

    class Meta:
        verbose_name = "Ritual"
        verbose_name_plural = "Rituals"
class RitualsImages(models.Model):
    rituals_id = models.IntegerField()  # Changed from TextField
    image_caption = models.CharField(max_length=200)
    ritual_image = models.ImageField(upload_to='ritual_image/')
    ritual_image_status = models.CharField(max_length=10)

    def clean(self):
        """Validate that the uploaded trip image is exactly 400x250 pixels."""
        if self.ritual_image:
            img = Image.open(self.ritual_image)
            if img.width != 400 or img.height != 250:
                raise ValidationError("Trip image must be exactly 400x250 pixels.")

    def __str__(self):
        return self.image_caption