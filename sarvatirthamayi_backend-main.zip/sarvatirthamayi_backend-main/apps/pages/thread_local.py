import threading

_thread_locals = threading.local()

def get_current_db():
    return getattr(_thread_locals, 'database_name', 'default')  # Fallback to 'default'

def set_current_db(db_name):
    _thread_locals.database_name = db_name