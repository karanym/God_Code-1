from django.utils.deprecation import MiddlewareMixin
from .thread_local import set_current_db

class DatabaseMiddleware(MiddlewareMixin):
    def __init__(self, get_response):
        self.get_response = get_response
    def process_request(self, request):
        # Get the database name from the session variable
        db_name = request.session.get('db_name', 'default')
        set_current_db(db_name)
    def __call__(self, request):
        # Determine the database name (from a header, session, or URL parameter)
        db_name = request.session.get('db_name', 'default')
        set_current_db(db_name)
        
        response = self.get_response(request)
        return response