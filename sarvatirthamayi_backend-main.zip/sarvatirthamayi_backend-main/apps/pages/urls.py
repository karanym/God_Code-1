from django.urls import path

from ..authentication.views_client_data import clientDataUpdate,clientDataCreate,clientDataUpdateProfile,ChangePasswordView,update_client_status_active,update_client_status_inactive,is_client_mail_already_exists_createmode_fun,is_client_mail_already_exists_editmode_fun

from .views_misc import MiscPagesView
from django.conf.urls.static import static
from django.conf import settings

from .views import *
from .views_booking import *
from .views_temples import *
from .views_trips import *
from .views_rituals_labels import *
from .views_rituals import *

urlpatterns = [
    path(
        "pages/account_settings/account/",
        clientDataCreate.as_view(template_name="pages_account_settings_account.html"),
        name="pages-account-settings-account",
    ),
    path(
        "pages/is_client_mail_already_exists_createmode/",
        is_client_mail_already_exists_createmode_fun,
        name="is-client-mail-already-exists_createmode",
    ),
    path(
        "pages/is_client_mail_already_exists_editmode/",
        is_client_mail_already_exists_editmode_fun,
        name="is-client-mail-already-exists_editmode",
    ),
    path(
        "pages/account_settings/profile/",
        PagesView.as_view(template_name="pages_account_settings_profile.html"),
        name="pages-account-settings-profile",
    ),
    path(
        "pages/account_settings/change_password/",
        ChangePasswordView.as_view(template_name="pages_change_password.html"),
        name="pages-change-password",
    ),

    path(
        "pages/update_client_status_active/<int:client_id>/active",
        update_client_status_active
    ),
    path(
        "pages/update_client_status_inactive/<int:client_id>/inactive",
        update_client_status_inactive
    ),
    path(
        "pages/profile/<int:pk>/update_profile",
        clientDataUpdateProfile.as_view(template_name="pages_client_profile_update.html"),
        name="pages-account-settings-profile-update",
    ),
    path(
        "pages/account_settings/connections/",
        PagesView.as_view(template_name="pages_account_settings_connections.html"),
        name="pages-account-settings-connections",
    ),
    path(
        "stm_users/",
        SmtUsersView.as_view(template_name="smt_users/smt_users.html"),
        name="stm-users",
    ),
    path(
        "pages/client_profile/<int:pk>/update",
        clientDataUpdate.as_view(template_name="pages_client_profile_update.html"),
        name="pages-client-profile-update",
    ),
    path('temple_admins_list', temple_admins_list, name='temple-admins-list'),
    path('smt_users_list', smt_users_list, name='smt-users-list'),

    path('activities/', ActivitiesListView.as_view(), name='activities'),
    path('activities/add/', ActivitiesCreateView.as_view(), name='activities_add'), 
    path('activities_list', activities_list, name='activities-list'),
    path('delete-activities/<int:record_id>/', delete_activities, name='delete_activities'),
    path('activities/<int:pk>/edit/', ActivitiesUpdateView.as_view(), name='activities_edit'),

    path('rituals_labels/', RitualsLabelsListView.as_view(), name='rituals-labels'),
    path('rituals_labels/add/', RitualsLabelsCreateView.as_view(), name='rituals-labels-add'), 
    path('rituals_labels_list', rituals_labels_list, name='rituals-labels-list'),
    path('delete-rituals_labels/<int:record_id>/', delete_rituals_labels, name='delete-rituals-labels'),
    path('rituals_labels/<int:pk>/edit/', RitualsLabelsUpdateView.as_view(), name='rituals-labels-edit'),
    path('add-ritual-label/', add_ritual_label, name='add_ritual_label'),

    path('rituals_label_request/', RitualsLabelRequestListView.as_view(), name='rituals-label-request'),
    path('ritual_label_requests_list/', ritual_label_requests_list, name='ritual-label-requests-list'),
    path('approve_ritual_label/', approve_ritual_label, name='approve-ritual-label'),
    path('reject_ritual_label/', reject_ritual_label, name='reject-ritual-label'),

    path('rituals/', RitualsListView.as_view(), name='rituals'),
    path('rituals/add/', RitualsCreateView.as_view(), name='rituals-add'), 
    path('rituals_list', rituals_list, name='rituals-list'),
    path('delete-rituals/<int:record_id>/', delete_rituals, name='delete-rituals'),
    path('rituals/<int:pk>/edit/', RitualsUpdateView.as_view(), name='rituals-edit'),
    path("rituals/delete_image/<str:image_id>/", delete_ritual_image, name="delete_ritual_image"),
    path("rituals/update_ritual_image_status/<str:image_id>/", update_ritual_image_status, name="update_ritual_image_status"),
    path("change-ritual-status/", change_ritual_status, name="change_ritual_status"),

    path('temples/', TemplesListView.as_view(), name='temples'),
    path('temples/add/', TemplesCreateView.as_view(), name='temples_add'), 
    path('temples_list', temples_list, name='temples-list'),
    path('assign_temple', assign_temple, name='assign-temple'),
    path('delete-temples/<int:record_id>/', delete_temples, name='delete_temples'),
    path('temples/<int:pk>/edit/', TemplesUpdateView.as_view(), name='temples_edit'),
    path('temple_details/<int:pk>/', TempleDetailsView.as_view(template_name='temples/temples_details.html'), name='temples_details'),
    path('temple/', TempleDetailView.as_view(), name='temple_list'), 
    path('temple/item/', TempleDetailItemView.as_view(), name='temple_item_add'),
    path("temple-items/<str:temple_id>/", get_temple_items, name="get_temple_items"),
    path("temple-item/save/", save_temple_item, name="save_temple_item"),
    path("temple-item/delete/<int:item_id>/", delete_temple_item, name="delete_temple_item"),
    path("approve_temple/", approve_temple, name="approve_temple"),
    path("reject_temple/", reject_temple, name="reject_temple"),
    
    path("temple-dynamic-fields/<int:temple_id>/", TempleDynamicFieldView.as_view(), name="temple_dynamic_fields"),
    path("temple-dynamic-fields/<int:temple_id>/add/", add_dynamic_field, name="add_dynamic_field"),
    path("temple-dynamic-fields/<int:temple_id>/edit/", edit_dynamic_field, name="edit_dynamic_field"),
    path("temple-dynamic-fields/<int:temple_id>/delete/", delete_dynamic_field, name="delete_dynamic_field"),

    path('trips/', TripsListView.as_view(), name='trips'),
    path('trips/add/', TripsCreateView.as_view(), name='trips_add'), 
    path('trips_list', trips_list, name='trips-list'),
    path('delete-trips/<int:record_id>/', delete_trips, name='delete_trips'),
    path('trips/<int:pk>/edit/', TripsUpdateView.as_view(), name='trips_edit'),
    path('trip_details/<int:pk>/', TripDetailsView.as_view(template_name='trips/trips_details.html'), name='trips_details'),
    path('trip/', TripDetailView.as_view(), name='trip_list'), 
    path('trip/item/', TripDetailItemView.as_view(), name='trip_item_add'),
    path("trip-items/<str:trip_id>/", get_trip_items, name="get_trip_items"),
    path("trip-item/save/", save_trip_item, name="save_trip_item"),
    path("trip-item/delete/<int:item_id>/", delete_trip_item, name="delete_trip_item"),
    path('bookings/', BookingListView.as_view(), name='bookings'),
    path('bookings_list', bookings_list, name='bookings-list'),
    path('smt_user_login_history/<int:user_id>/', smt_user_login_history, name='smt_user_login_history'),

]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)