from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import *
from django.utils.timezone import now
from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
from django.core.paginator import Paginator
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from .forms import *
from django.shortcuts import get_object_or_404
from django.contrib import messages


ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'gif'])
UPLOAD_FOLDER = str(BASE_DIR)+'/upload'

@method_decorator(login_required, name='dispatch')

class RitualsListView(ListView):
    model = Rituals
    template_name = 'rituals/rituals_list.html'
    context_object_name = 'rituals'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'rituals List',
        })
        return context

class RitualsLabelRequestListView(ListView):
    model = RitualLabelsRequest
    template_name = 'rituals/rituals_label_request_list.html'
    context_object_name = 'rituals'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Rituals Lable Request List',
        })
        return context

def ritual_label_requests_list(request):

    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    order_column_index = int(request.POST.get('order[0][column]', 0))  
    order_direction = request.POST.get('order[0][dir]', 'asc')  

    orderable_columns = ['id', 'title', 'status', 'requested_by', 'requested_on']
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Fetch only pending labels
    if request.user.is_superuser:
        labels_query = RitualLabelsRequest.objects.filter().order_by(order_column)
    else:
        labels_query = RitualLabelsRequest.objects.filter(requested_by=request.user.id).order_by(order_column)

    total_records = labels_query.count()

    paginator = Paginator(labels_query, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number) 

    data_list = []
    k=0
    for label in page_data:
        approve_btn = ""
        requested_by_str=""
        
        if label.status == "active":
            approve_btn += f'''
                <span class="badge bg-success status-badge" data-id="{label.id}" style="cursor:pointer;">
                    {label.status.capitalize()}
                </span>
                <br><small>Approved On: {label.approved_on}</small>
            '''
        elif label.status == "inactive":
            if request.user.is_superuser:
                approve_btn = f'''
                    <button class="btn btn-success btn-sm" onclick="approveLabel({label.id})">Approve</button>            
                '''
            else:
                approve_btn = f'''
                    <button class="btn btn-warning btn-sm">Not Yet Approved</button>
                '''
        
        #<button class="btn btn-danger btn-sm" onclick="rejectLabel({label.id})">Reject 2</button>

        requested_by_user = User.objects.filter(id=label.requested_by).first()
        if requested_by_user:
            requested_by = f"{requested_by_user.first_name} ({requested_by_user.email})"
        else:
            requested_by = "Unknown User"
        
        k=(k+1)
        data_list.append({
            "s_no": k,
            "title": label.title,
            "requested_by": requested_by,
            "requested_on": label.requested_on.strftime("%Y-%m-%d %H:%M:%S"),
            "status": label.status,
            "actions": approve_btn,
        })

    response = {
        'draw': draw,
        'recordsTotal': total_records,
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def approve_ritual_label(request):
    """ Superuser can approve a pending ritual label """
    
    if request.method == "POST":
        label_id = request.POST.get("label_id")
        try:
            label = RitualLabelsRequest.objects.get(id=label_id)
            label.status = "active"
            label.save()
            
            # Insert approved label into RitualsLabels
            RitualsLabels.objects.create(
                title=label.title,
                status="active"
            )

            return JsonResponse({"success": True, "message": "Label approved successfully."})

        except RitualsLabels.DoesNotExist:
            return JsonResponse({"success": False, "error": "Ritual label not found."})

    return JsonResponse({"success": False, "error": "Invalid request."})


def reject_ritual_label(request):
    """ Superuser can approve a pending ritual label """
    
    if request.method == "POST":
        label_id = request.POST.get("label_id")
        try:
            label = RitualLabelsRequest.objects.get(id=label_id)
            label.status = "inactive"
            label.save()
            
            return JsonResponse({"success": True, "message": "Label Request Rejected Successfully."})

        except RitualsLabels.DoesNotExist:
            return JsonResponse({"success": False, "error": "Ritual label not found."})

    return JsonResponse({"success": False, "error": "Invalid request."})


class RitualsCreateView(CreateView):
    model = Rituals
    form_class =RitualsForm

    template_name = 'rituals/rituals_form.html'
    success_url = reverse_lazy('rituals')

    
    def form_valid(self, form):
        response = super().form_valid(form)
        form.instance.ritual_benefits = self.request.POST.get('ritual_benefits')
        form.instance.ritual_procedure = self.request.POST.get('ritual_procedure')
        # Handle multiple image uploads
        images = self.request.FILES.getlist("ritual_images")
        for image in images:
            RitualsImages.objects.create(
                rituals_id=self.object.id, 
                ritual_image=image, 
                image_caption=image.name,
                ritual_image_status="active"
            )

        messages.success(self.request, "Ritual added successfully!")
        return response

    def form_invalid(self, form):
        print("Form errors:", form.errors)
        return super().form_invalid(form)

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        context["title"]= "Add New Ritual"

        user = self.request.user
        if user.is_superuser:
            context["temples"] = Temples.objects.all()
        else:
            context["temples"] = Temples.objects.filter(status="active", temple_admin=user.id)

        context["ritual_labels"]= RitualsLabels.objects.all()
        
        return context

class RitualsUpdateView(UpdateView):
    model = Rituals
    form_class = RitualsForm
    template_name = 'rituals/rituals_form.html'
    success_url = reverse_lazy('rituals')

    def form_valid(self, form):
        response = super().form_valid(form)

        # Handle new image uploads
        images = self.request.FILES.getlist("ritual_images")
        for image in images:
            RitualsImages.objects.create(
                rituals_id=self.object.id, 
                ritual_image=image, 
                image_caption=image.name,
                ritual_image_status="active"
            )

        messages.success(self.request, "Ritual updated successfully!")
        return response

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context["title"]= "Edit Ritual"
        context["ritual_images"]= RitualsImages.objects.filter(rituals_id=self.object.id)
        
        user = self.request.user
        if user.is_superuser:
            context["temples"] = Temples.objects.all()
        else:
            context["temples"] = Temples.objects.filter(status="active", temple_admin=user)

        context["ritual_labels"]= RitualsLabels.objects.all()

        return context
    
def rituals_list(request):

    title = request.POST.get('title')
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','title','status']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    if request.user.is_superuser:
        initial_data = Rituals.objects.filter()
    else:
        initial_data = Rituals.objects.filter(ritual_updated_by=str(request.user.id))
    
    
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(ritual_type__icontains=search_value) 

    # Apply ordering
    data = data.order_by(order_column) 

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    for obj in page_data:
        temple_html=''

        if obj.temple_id:
            temple_details=Temples.objects.filter(id=obj.temple_id).first()
            if temple_details:
                temple_html=str(temple_details.temple_name)+'('+str(temple_details.type_of_temple)+')'
        
        label_html=''
        
        if obj.temple_id:
            label_details=RitualsLabels.objects.filter(id=obj.rituals_label_id).first()
            if temple_details:
                label_html=str(label_details.title)

        k=(k+1) 
        data_list.append({
            "sno":k,
            "ritual_label":label_html,
            "temple":temple_html,
            "ritual_type":obj.ritual_type,
            "ritual_status": f'<span class="badge bg-{ "success" if obj.ritual_status == "active" else "danger"} status-badge" data-id="{obj.id}" style="cursor:pointer;">{obj.ritual_status.capitalize()}</span>', 
            "actions":f'<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu"><a class="dropdown-item" href="'+BASE_URL_SERVER+'/rituals/'+str(obj.id)+'/edit"><i class="bx bx-edit-alt me-1"></i> Edit</a><button type="button" class="dropdown-item" onclick="delete_record('+str(obj.id)+')"><i class="bx bx-trash me-1"></i> Delete</button></div></div>'})

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def change_ritual_status(request):
    if request.method == "POST":
        ritual_id = request.POST.get("ritual_id")
        try:
            ritual = Rituals.objects.get(id=ritual_id)
            new_status = "inactive" if ritual.ritual_status == "active" else "active"
            Rituals.objects.filter(id=ritual_id).update(ritual_status=new_status)
            return JsonResponse({"success": True, "status": ritual.ritual_status})
        except Rituals.DoesNotExist:
            return JsonResponse({"success": False, "error": "Ritual not found"})
    
    return JsonResponse({"success": False, "error": "Invalid request"})

def delete_rituals(request, record_id):
    if request.method == "POST":
        try:
            pmt = Rituals.objects.get(id=record_id)
            pmt.delete()
            return JsonResponse({'success': True, 'message': 'Data deleted successfully'})
        except Rituals.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Record not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)

def delete_ritual_image(request, image_id):
    if request.method == "POST":
        image = get_object_or_404(RitualsImages, id=image_id)
        image.delete()
        return JsonResponse({"success": True})
    return JsonResponse({"success": False})

def update_ritual_image_status(request, image_id):
    if request.method == "POST":
        data = json.loads(request.body)
        new_status = data.get("status")
        image = get_object_or_404(RitualsImages, id=image_id)
        image.ritual_image_status = new_status
        image.save()
        return JsonResponse({"success": True})
    return JsonResponse({"success": False})

def add_ritual_label(request):
    if request.method == "POST":
        title = request.POST.get("title")
        if title:
            print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            new_label = RitualLabelsRequest.objects.create(
                title=title,
                requested_by=request.user.id,  # Store logged-in user ID
                requested_on=now(),
                status="inactive"
            )
            return JsonResponse({"success": True, "message": "Request sent to admin."})
    
    return JsonResponse({"success": False, "message": "Invalid request."}, status=400) 