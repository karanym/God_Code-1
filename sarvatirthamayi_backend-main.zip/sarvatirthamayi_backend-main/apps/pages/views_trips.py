from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import *

from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
from django.core.paginator import Paginator
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from django.core.files.base import ContentFile, File

from ..authentication.forms import clientform

from ..authentication.models import clientData
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib.auth.hashers import *
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import EmailMessage

from ..authentication.forms import ChangePasswordForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import *

import requests
from django.views import View
from .forms import *
from django.shortcuts import get_object_or_404



"""
This file is a view controller for multiple pages as a module.
Here you can override the page view layout.
Refer to pages/urls.py file for more pages.
"""
ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'gif'])
UPLOAD_FOLDER = str(BASE_DIR)+'/upload'

@method_decorator(login_required, name='dispatch')

class PagesView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        #custom code
        
        #admin_data = admin_collection.objects.all() #for all the records 
        
        context["curr_id"]=self.request.user.id
        client_id=self.request.user.id

        try:

            if self.request.user.is_superuser:
                c_data=clientData.objects.filter(admin_type='admin')
            else:
                client_id=self.request.user.id
                c_data=clientData.objects.get(client_id=client_id)
            
        except clientData.DoesNotExist:
            c_data = None 

      
        if c_data!='':
            context["c_form"]=clientform(initial={'client_id':client_id})
            context['c_data']=c_data
            
        else:
            context["c_form"]=clientform(initial={'ai_client_id':client_id})

        #custom code

        return context
    

class TripsListView(ListView):
    model = Trips
    template_name = 'trips/trips_list.html'
    context_object_name = 'trips'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'trips List',
        })
        return context

class TripDetailsView(ListView):
    model = Trips
    context_object_name = 'trips'
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Trip Details',
        })

        # Convert ID to string to match TextField storage
        trip_id = str(self.kwargs['pk'])
        context['id'] = trip_id
        context['trip_id'] = trip_id

        main_trip = Trips.objects.filter(id=trip_id).first()
        context['main_trip_details']=main_trip
        
        temple_list = Temples.objects.filter(status='active')
        context['temple_list']=temple_list 

        if main_trip:
            context['main_title']=main_trip.trip_title
            context['thumbnail_image']=main_trip.thumbnail_image
        else:
            context['main_title']=''
            context['thumbnail_image']=''

        # Fetch trip details if exists, otherwise provide an empty form
        trip = TripsDetails.objects.filter(trip_id=trip_id).first()

        context['trip_form'] = TripDetailForm(instance=trip) if trip else TripDetailForm()
        context["existing_image"] = trip.banner_image.url if trip and trip.banner_image else None

        # Empty form for TripDetailItem
        context['item_form'] = TripDetailItemForm()

        return context

class TripsCreateView(CreateView):
    model = Trips
    form_class =TripsForm

    template_name = 'trips/trips_form.html'
    success_url = reverse_lazy('trips')

    def form_valid(self, form):
        # Save the form and redirect
        return super().form_valid(form)

    def form_invalid(self, form):
        # Debug: Print form errors to console
        print("Form errors:", form.errors)
        return super().form_invalid(form)
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Add New Trips',
        })
        return context

class TripsUpdateView(UpdateView):
    model = Trips
    form_class = TripsForm
    template_name = 'trips/trips_form.html'
    success_url = reverse_lazy('trips')

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        id=self.kwargs['pk']
        context['id']=id
        context.update({
            'title': 'Edit Trips',
        })
        return context
    
def trips_list(request):

    trip_title = request.POST.get('trip_title')
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','trip_title','short_description','status']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    initial_data = Trips.objects.filter()
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(trip_title__icontains=search_value) 

    # Apply ordering
    data = data.order_by(order_column)

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    for obj in page_data:
        k=(k+1) 
        data_list.append({
            "sno":k,
            "trip_title":obj.trip_title,
            "thumbnail_image":'<img src="'+obj.thumbnail_image.url+'" alt="" />',
            "detail_link":'<a href="'+BASE_URL_SERVER+'/trip_details/'+str(obj.id)+'/" class="btn btn-primary">Update More Details</a>',
            "actions":f'<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu"><a class="dropdown-item" href="'+BASE_URL_SERVER+'/trips/'+str(obj.id)+'/edit"><i class="bx bx-edit-alt me-1"></i> Edit</a><button type="button" class="dropdown-item" onclick="delete_record('+str(obj.id)+')"><i class="bx bx-trash me-1"></i> Delete</button></div></div>'})

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def delete_trips(request, record_id):
    if request.method == "POST":
        try:
            pmt = Trips.objects.get(id=record_id)
            pmt.delete()
            return JsonResponse({'success': True, 'message': 'Data deleted successfully'})
        except Trips.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Record not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)

#trip details

class TripDetailView(View):

    def get(self, request):
        """Fetch all trips and return JSON response"""
        trips = TripsDetails.objects.filter()
        data = []
        for trip in trips:
            data.append({
                "id": trip.id,
                "short_description": trip.short_description,
                "image_caption": trip.image_caption,
            })
        return JsonResponse({"trips": data}, safe=False)

    def post(self, request):
        """Create or update a trips based on trip_id"""
        
        trip_id = request.POST.get("trip_id")  # Get trip_id from request

        if trip_id:
            trip_id = str(trip_id)
            trip = TripsDetails.objects.filter(trip_id=trip_id).first()

            if trip:
                form = TripDetailForm(request.POST, request.FILES, instance=trip)  # Include request.FILES
                message = "Trip updated successfully"
            else:
                # If no trip_id, create a new record
                form = TripDetailForm(request.POST, request.FILES)  # Include request.FILES
                message = "New Trip created successfully"

        # Validate and save the form
        if form.is_valid():
            trip = form.save()
            return JsonResponse({
                "id": trip.trip_id,  
                "short_description": trip.short_description,
                "image_caption": trip.image_caption,
                "message": message
            })
        else:
            return JsonResponse({"errors": form.errors}, status=400)

        
class TripDetailItemView(View):
    def post(self, request):
        """Create a new trip item using a form"""
        form = TripDetailItemForm(request.POST)
        if form.is_valid():
            item = form.save()
            return JsonResponse({
                "id": item.id,
                "list_title": item.list_title,
                "list_description": item.list_description,
            })
        else:
            return JsonResponse({"errors": form.errors}, status=400)

def save_trip_item(request):
    """Create or update a trip item"""

    item_id = request.POST.get("item_id")  # Item ID (if editing)
    trip_id = request.POST.get("trip_id")  # Parent trip ID

    if not trip_id:
        return JsonResponse({"error": "Trip ID is required."}, status=400)

    if item_id:
        # Updating an existing item
        item = get_object_or_404(TripsDetailItem, id=item_id)
        form = TripDetailItemForm(request.POST, instance=item)
        message = "Trip item updated successfully"
    else:
        # Creating a new item
        form = TripDetailItemForm(request.POST)
        message = "New trip item created successfully"

    if form.is_valid():
        item = form.save()
        return JsonResponse({
            "id": item.id,
            "list_title": item.list_title,
            "list_description": item.list_description,
            "message": message
        })
    
    return JsonResponse({"errors": form.errors}, status=400)


def get_trip_items(request, trip_id):
    """Fetch all trip items for a given trip ID"""
    
    items = TripsDetailItem.objects.filter(trip_id=trip_id).values("id", "list_title", "list_description")
    
    return JsonResponse(list(items), safe=False)

def delete_trip_item(request, item_id):
    """Delete a trip item by ID"""
    
    item = get_object_or_404(TripsDetailItem, id=item_id)
    item.delete()
    
    return JsonResponse({"message": "Trip item deleted successfully"})

