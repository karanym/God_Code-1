# custom_tags.py
from django import template
from datetime import datetime
from urllib.parse import urlencode, parse_qs
from django.http import HttpRequest

register = template.Library()

@register.filter
def get_attribute(obj, attr):
    return getattr(obj, attr, None)
    
@register.filter
def unixtimestamp_to_date(value):
    try:
        return datetime.fromtimestamp(value).strftime('%d-%m-%Y %H:%M:%S')
    except (ValueError, TypeError):
        return "Invalid Timestamp"

