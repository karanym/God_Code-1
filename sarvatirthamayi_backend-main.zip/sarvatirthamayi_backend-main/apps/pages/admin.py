from django.contrib import admin
from .models import (
    LatestActivities, Trips, TripsDetails, TripsDetailItem, 
    TripsImages, TripBookingConfirmation, Temples, TempleImages
)

@admin.register(LatestActivities)
class LatestActivitiesAdmin(admin.ModelAdmin):
    list_display = ('title', 'status')
    search_fields = ('title',)
    list_filter = ('status',)

@admin.register(Trips)
class TripsAdmin(admin.ModelAdmin):
    list_display = ('trip_title', 'popular_status', 'status')
    search_fields = ('trip_title',)
    list_filter = ('popular_status', 'status')

@admin.register(TripsDetails)
class TripsDetailsAdmin(admin.ModelAdmin):
    list_display = ('trip_id', 'image_caption', 'status')
    search_fields = ('image_caption',)
    list_filter = ('status',)

@admin.register(TripsDetailItem)
class TripsDetailItemAdmin(admin.ModelAdmin):
    list_display = ('trip_id', 'list_title')
    search_fields = ('list_title',)

@admin.register(TripsImages)
class TripsImagesAdmin(admin.ModelAdmin):
    list_display = ('trip_id', 'image_caption', 'trip_image_status')
    search_fields = ('image_caption',)
    list_filter = ('trip_image_status',)

@admin.register(TripBookingConfirmation)
class TripBookingConfirmationAdmin(admin.ModelAdmin):
    list_display = ('trip_id', 'trip_title', 'name', 'mobile', 'start_date')
    search_fields = ('trip_title', 'name', 'mobile')
    list_filter = ('start_date',)

@admin.register(Temples)
class TemplesAdmin(admin.ModelAdmin):
    list_display = ('temple_name', 'status')
    search_fields = ('temple_name',)
    list_filter = ('status',)

@admin.register(TempleImages)
class TempleImagesAdmin(admin.ModelAdmin):
    list_display = ('temple_id', 'image_caption')
    search_fields = ('image_caption',)
