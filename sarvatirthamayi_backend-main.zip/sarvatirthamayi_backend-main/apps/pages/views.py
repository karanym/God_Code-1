from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import *
import pytz
from django.utils.timezone import localtime
from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
from django.core.paginator import Paginator
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from django.core.files.base import ContentFile, File

from ..authentication.forms import clientform

from ..authentication.models import clientData
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib.auth.hashers import *
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import EmailMessage

from ..authentication.forms import ChangePasswordForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import *

import requests
from django.views import View
from .forms import *
from django.shortcuts import get_object_or_404
from django.utils.dateparse import parse_datetime


"""
This file is a view controller for multiple pages as a module.
Here you can override the page view layout.
Refer to pages/urls.py file for more pages.
"""
ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'gif'])
UPLOAD_FOLDER = str(BASE_DIR)+'/upload'

@method_decorator(login_required, name='dispatch')

class PagesView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        #custom code
        
        #admin_data = admin_collection.objects.all() #for all the records 
        
        context["curr_id"]=self.request.user.id
        client_id=self.request.user.id

        try:

            if self.request.user.is_superuser:
                c_data=clientData.objects.filter(admin_type='admin')
            else:
                client_id=self.request.user.id
                c_data=clientData.objects.get(client_id=client_id)
            
        except clientData.DoesNotExist:
            c_data = None 

      
        if c_data!='':
            context["c_form"]=clientform(initial={'client_id':client_id})
            context['c_data']=c_data
            
        else:
            context["c_form"]=clientform(initial={'ai_client_id':client_id})

        #custom code

        return context


def temple_admins_list(request):

    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','name','email','mobile']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    initial_data = clientData.objects.filter()
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(first_name__icontains=search_value) | data.filter(email__icontains=search_value) | data.filter(phone_number__icontains=search_value) | data.filter(last_name__icontains=search_value)

    # Apply ordering
    data = data.order_by(order_column)

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=1
    for obj in page_data:

        if obj.profile_picture != 'False' :
            img_details = f'<img src="{request.build_absolute_uri(obj.profile_picture.url)}" alt="{obj.profile_picture}" class="rounded-circle" style="width: 75px;">'
        else:
            img_details = '<img src="/static/img/avatars/default.jpg" alt="user-avatar" class="rounded-circle" style="width: 75px;" id="profile" />'
        
        status=''
        if obj.client_active:
            status = f"""
                <a href="{BASE_URL_SERVER}/pages/update_client_status_inactive/{obj.client_id}/inactive" title="Change status to Inactive">
                    <span class="badge bg-label-success me-1">Active</span>
                </a>
            """
        else:
            status = f"""
                <a href="{BASE_URL_SERVER}/pages/update_client_status_active/{obj.client_id}/active" title="Change status to Active">
                    <span class="badge bg-label-warning me-1">Inactive</span>
                </a>
            """
        actions=f"""
        <div class="dropdown">
              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="{BASE_URL_SERVER}/pages/client_profile/{obj.id}/update"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                
              </div>
            </div>
        """

        data_list.append({
            "sno": k,
            "profile": img_details,
            "name": f"{obj.first_name} {obj.last_name}<br>{obj.email}",
            "mobile": obj.phone_number,
            "contact": obj.address,
            "status": status,
            "actions": actions
        })
        k += 1

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)    

class ActivitiesListView(ListView):
    model = LatestActivities
    template_name = 'activities/activities_list.html'
    context_object_name = 'activities'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'activities List',
        })
        return context

class ActivitiesCreateView(CreateView):
    model = LatestActivities
    form_class =ActivitiesForm

    template_name = 'activities/activities_form.html'
    success_url = reverse_lazy('activities')

    def form_valid(self, form):
        # Save the form and redirect
        return super().form_valid(form)

    def form_invalid(self, form):
        # Debug: Print form errors to console
        print("Form errors:", form.errors)
        return super().form_invalid(form)
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Add New Activities',
        })
        return context

class ActivitiesUpdateView(UpdateView):
    model = LatestActivities
    form_class = ActivitiesForm
    template_name = 'activities/activities_form.html'
    success_url = reverse_lazy('activities')

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        id=self.kwargs['pk']
        context['id']=id
        context.update({
            'title': 'Edit Activity',
        })
        return context
    
def activities_list(request):

    title = request.POST.get('title')
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','title','status']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    initial_data = LatestActivities.objects.filter()
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(title__icontains=search_value) 

    # Apply ordering
    data = data.order_by(order_column)

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0
    for obj in page_data:
        k=(k+1) 
        data_list.append({
            "sno":k,
            "title":obj.title,
            "image":'<img src="'+obj.image.url+'" alt="" />',
            "actions":f'<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu"><a class="dropdown-item" href="'+BASE_URL_SERVER+'/activities/'+str(obj.id)+'/edit"><i class="bx bx-edit-alt me-1"></i> Edit</a><button type="button" class="dropdown-item" onclick="delete_record('+str(obj.id)+')"><i class="bx bx-trash me-1"></i> Delete</button></div></div>'})

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def delete_activities(request, record_id):
    if request.method == "POST":
        try:
            pmt = LatestActivities.objects.get(id=record_id)
            pmt.delete()
            return JsonResponse({'success': True, 'message': 'Data deleted successfully'})
        except LatestActivities.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Record not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)

class SmtUsersView(ListView):
    model = SmtUsers
    template_name = 'smt_users/smt_users.html'
    context_object_name = 'SmtUsers'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'STM Users List',
        })

        users = SmtUsers.objects.filter()
        context["users"] = list(users)
    
        return context
def smt_users_list(request):
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    order_column_index = int(request.POST.get('order[0][column]', 0))
    order_direction = request.POST.get('order[0][dir]', 'asc')

    orderable_columns = ['id', 'name', 'email', 'mobile']
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]
    if order_direction == 'desc':
        order_column = '-' + order_column

    search_value = request.POST.get('search[value]', '')

    initial_data = SmtUsers.objects.all()
    data = initial_data

    if search_value:
        data = data.filter(
            name__icontains=search_value
        ) | data.filter(
            email__icontains=search_value
        ) | data.filter(
            mobile__icontains=search_value
        ) | data.filter(
            city__icontains=search_value
        )

    data = data.order_by(order_column)

    total_records = data.count()

    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    data_list = []
    k = 1

    for obj in page_data:
        if obj.profile:
            img_details = f'<img src="{request.build_absolute_uri(obj.profile.url)}" alt="{obj.profile}" class="rounded-circle" style="width: 75px;">'
        else:
            img_details = '<img src="/static/img/avatars/default.jpg" alt="user-avatar" class="rounded-circle" style="width: 75px;" id="profile" />'

        status = ''
        if obj.mobile_verified_status:
            status = f"""
                <span class="badge bg-label-success me-1">Mobile Verified</span>
            """
        else:
            status = f"""
                <span class="badge bg-label-warning me-1">Not Verified</span>
            """

        
        actions = f"""
        <div class="dropdown">
              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="javascript:void(0)" onclick="showLoginHistory('{obj.id}')" class="">View History</a>
              </div>
        </div>
        """

        registered_on = localtime(obj.created_at).strftime('%d %b %Y, %I:%M %p')

        data_list.append({
            "sno": k,
            "profile": img_details,
            "name": f"{obj.name}<br>{obj.email}",
            "mobile": obj.mobile or "-",
            "contact": obj.city or "-",
            "registered_on":registered_on, 
            "status": status,
            "actions": actions
        })
        k += 1

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def smt_user_login_history(request, user_id):
    try:
        user = SmtUsers.objects.get(id=user_id)
    except SmtUsers.DoesNotExist:
        return JsonResponse({'history': []})

    data = []
    for entry in user.login_history:
        dt_obj = parse_datetime(entry.get('timestamp'))
        formatted_time = localtime(dt_obj).strftime('%d %b %Y, %I:%M %p') if dt_obj else "-"
        data.append({
            'action': entry.get('action', '-'),
            'timestamp': formatted_time,
        })

    return JsonResponse({'history': data})
