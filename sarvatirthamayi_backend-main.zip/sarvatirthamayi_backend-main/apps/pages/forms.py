from django import forms
from .models import *
from PIL import Image
from django.core.exceptions import ValidationError

class BaseForm(forms.ModelForm):
    """A base form with shared custom styles and validation"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.update({
                'class': 'form-control',
                'placeholder': f'Enter {field.label.lower()}' if field.label else ''
            })

class ActivitiesForm(BaseForm):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='active'  # Default to 'Active'
    )

    class Meta:
        model = LatestActivities
        fields = ['title', 'image', 'status']
        labels = {
            'title': 'Title',
            'image': 'Activity Image',
            'status': 'Status'
        }
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Activity title',
            }),
            'image': forms.ClearableFileInput(attrs={
                'class': 'form-control',
            }),
        }

    def clean_image(self):
        image = self.cleaned_data.get('image')

        if image:
            try:
                img = Image.open(image)
                if img.width != 400 or img.height != 250:
                    raise ValidationError("Image must be exactly 400x250 pixels.")  # Fixed error message
            except ValidationError as e:
                raise e
            except Exception:
                raise ValidationError("Invalid image file.")

        return image

class RitualsLabelsForm(BaseForm):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='active'  # Default to 'Active'
    )

    class Meta:
        model = RitualsLabels
        fields = ['title', 'image', 'status']
        labels = {
            'title': 'Title',
            'image': 'Image',
            'status': 'Status'
        }
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Label Name',
            }),
            'image': forms.ClearableFileInput(attrs={
                'class': 'form-control',
            }),
        }

    def clean_image(self):
        image = self.cleaned_data.get('image')

        if image:
            try:
                img = Image.open(image)
                if img.width != 400 or img.height != 250:
                    raise ValidationError("Image must be exactly 400x250 pixels.")  # Fixed error message
            except ValidationError as e:
                raise e
            except Exception:
                raise ValidationError("Invalid image file.")

        return image


class TemplesForm(BaseForm):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    DIETY_OPT = [
        ('', ''),
        ('shiva', 'Shiva'),
        ('vishnu', 'Vishnu'),
        ('durga', 'Durga'),
        ('ganesh', 'Ganesh')
    ]
    STATE_OPT = [
        ('', ''),
        ('tamil nadu', 'Tamil Nadu'),
        ('karnataka', 'Karnataka'),
        ('kerala', 'Kerala'),
        ('andhra pradesh', 'Andhra Pradesh'),
        ('uttar pradesh', 'Uttar Pradesh')
    ]
    TYPE_OF_TEMPLE_OPT = [
        ('', ''),
        ('Shiva Temple', 'Shiva Temple'),
        ('Devi Temple', 'Devi Temple'),
        ('Vishnu Temple', 'Vishnu Temple')
    ]
    
    WHO_CAN_VIEW_CHOICES = [
        ('', ''),
        ('All members', 'All members'),
        ('Free members', 'Free members'),
        ('Club members - Non Paid', 'Club members - Non Paid'),
        ('Club members - Paid', 'Club members - Paid')
    ]
    
    type_of_temple = forms.ChoiceField(
        choices=TYPE_OF_TEMPLE_OPT,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial=''
    )
    diety = forms.ChoiceField(
        choices=DIETY_OPT,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='' 
    )
    temple_state = forms.ChoiceField(
        choices=STATE_OPT,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='' 
    )

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='active'  # Default to 'Active'
    )
    
    who_can_view = forms.ChoiceField(
        choices=WHO_CAN_VIEW_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial=''
    )


    class Meta:
        model = Temples
        fields = ['temple_name', 'icon_image','short_description', 'status','type_of_temple','diety','temple_state','who_can_view']
        labels = {
            'temple_name': 'Temple Name',
            'icon_image': 'Icon Image',
            'short_description': 'Short Description',
            'status': 'Status',
            'type_of_temple':'Type of temple',
            'diety':'Diety',
            'temple_state':'Temple State',
            'who_can_view':'Who Can View ?'
        }
        widgets = {
            'temple_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Temple title',
            }),
            'icon_image': forms.ClearableFileInput(attrs={
                'class': 'form-control',
            }),
            'short_description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Temple Description',
            }),
        }

    def clean_icon_image(self):
        image = self.cleaned_data.get('icon_image')

        if image:
            try:
                img = Image.open(image)
                if img.width != 200 or img.height != 250:
                    raise ValidationError("Image must be exactly 200x250 pixels.")  # Fixed error message
            except ValidationError as e:
                raise e
            except Exception:
                raise ValidationError("Invalid image file.")

        return image

class TempleDetailForm(BaseForm):
    """Form for TempleDetail model"""
    detail_image = forms.ImageField(
        required=False,
        label="Detail Image",
        help_text="Upload an image of size 400x250 pixels."
    ) 

    short_description = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}),
        label="Short Description"
    )
    temple_id = forms.CharField(
        widget=forms.HiddenInput(),
        label="temple_id"
    )
    highlights = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}),
        label="Highlights"
    )
    
    def clean_detail_image(self): 
        """Ensure uploaded image is 400x250"""
        image = self.cleaned_data.get("detail_image")
        if image:
            from PIL import Image
            img = Image.open(image)
            if img.width != 400 or img.height != 250:
                raise forms.ValidationError("Detail image must be exactly 400x250 pixels.")
        return image

    class Meta:
        model = TempleDetail
        fields = ["detail_image","short_description","temple_id", "highlights"]


class TempleDetailItemForm(BaseForm):
    """Form for TempleDetailItem model"""
    
    list_title = forms.CharField(
        max_length=255,
        label="List Title"
    )
    list_description = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 2}),
        label="List Description"
    )

    class Meta:
        model = TempleDetailItem
        fields = ["temple_id", "list_title", "list_description"]
    
    def clean_detail_image(self):
        image = self.cleaned_data.get('detail_image')

        if image:
            try:
                img = Image.open(image)
                if img.width != 400 or img.height != 250:
                    raise ValidationError("Image must be exactly 400x250 pixels.")  # Fixed error message
            except ValidationError as e:
                raise e
            except Exception:
                raise ValidationError("Invalid image file.")

        return image
#trips

class TripsForm(BaseForm):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    POPULAR_STATUS_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]
    TYPE_OF_TRIP = [
        ('', ''),
        ('family tour', 'Family Tour'),
        ('pilgrimage', 'Pilgrimage'),
        ('adventure', 'Adventure'),
        ('Heritage', 'Heritage'),
        ('Wellness', 'Wellness')
    ]

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='active'  # Default to 'Active'
    )
    popular_status = forms.ChoiceField(
        choices=POPULAR_STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='yes'  # Default to 'Active'
    )
    type_of_trip = forms.ChoiceField(
        choices=TYPE_OF_TRIP,
        widget=forms.Select(attrs={'class': 'form-control'}),
        initial='' 
    )

    class Meta:
        model = Trips
        fields = ['trip_title', 'thumbnail_image','popular_status', 'status','type_of_trip','price']
        labels = {
            'trip_title': 'Trip Title',
            'thumbnail_image': 'Icon Image',
            'popular_status': 'Popular Status',
            'status': 'Status',
            'type_of_trip': 'Type of trip'
        }
        widgets = {
            'trip_title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Trip title',
            }),
            'price': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Trip Price',
            }),
            'thumbnail_image': forms.ClearableFileInput(attrs={
                'class': 'form-control',
            }),
            
        }

    def clean_thumbnail_image(self):
        image = self.cleaned_data.get('thumbnail_image')

        if image:
            try:
                img = Image.open(image)
                if img.width != 200 or img.height != 250:
                    raise ValidationError("Image must be exactly 200x250 pixels.")  # Fixed error message
            except ValidationError as e:
                raise e
            except Exception:
                raise ValidationError("Invalid image file.")

        return image

class TripDetailForm(BaseForm):
    """Form for TripsDetails model"""
    banner_image = forms.ImageField(
        required=False,
        label="Banner Image",
        help_text="Upload an image of size 400x250 pixels."
    )

    short_description = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}),
        label="Short Description"
    )

    trip_id = forms.CharField(
        widget=forms.HiddenInput(),
        label="trip_id"
    )

    image_caption = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}),
        label="Image Caption"
    )

    trip_duration = forms.CharField(
        max_length=50,
        label="Trip Duration (e.g., 3 Days 2 Nights)"
    )

    no_of_temples = forms.IntegerField(
        min_value=0,
        label="No. of Temples"
    )

    temple_names = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 2, 'placeholder': 'Enter up to 4 temple names, comma separated'}),
        label="Temple Names"
    )

    trip_description = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 4}),
        required=False,
        label="Trip Description"
    )

    facilities_covered = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}),
        required=False,
        label="Facilities Covered"
    )

    trip_assembly_point = forms.CharField(
        max_length=200,
        required=False,
        label="Trip Assembly Point"
    )

    min_group_size = forms.IntegerField(
        min_value=1,
        label="Min Group Size"
    )

    max_group_size = forms.IntegerField(
        min_value=1,
        label="Max Group Size"
    )

    def clean_banner_image(self):
        """Ensure uploaded image is 400x250"""
        image = self.cleaned_data.get("banner_image")
        if image:
            from PIL import Image
            img = Image.open(image)
            if img.width != 400 or img.height != 250:
                raise forms.ValidationError("Detail image must be exactly 400x250 pixels.")
        return image

    def clean_temple_names(self):
        """Process comma-separated temple names into a list"""
        names_str = self.cleaned_data.get('temple_names', '')
        names_list = [name.strip() for name in names_str.split(',') if name.strip()]
        if len(names_list) > 4:
            raise forms.ValidationError("You can enter a maximum of 4 temple names.")
        return names_list

    class Meta:
        model = TripsDetails
        fields = [
            "banner_image", "short_description", "trip_id", "image_caption",
            "trip_duration", "no_of_temples", "temple_names",
            "trip_description", "facilities_covered", "trip_assembly_point",
            "min_group_size", "max_group_size"
        ]

class TripDetailItemForm(BaseForm): 
    """Form for TripDetailItem model"""
    
    list_title = forms.CharField(
        max_length=255,
        label="List Title"
    )
    list_description = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 2}),
        label="List Description"
    )

    class Meta:
        model = TripsDetailItem
        fields = ["trip_id", "list_title", "list_description"]

class RitualsForm(forms.ModelForm):

    RITUAL_FREQUENCY_CHOICES = [
        ("Everyday", "Everyday"),
        ("Every Alternate Day", "Every Alternate Day"),
        ("Once a Week", "Once a Week"),
        ("Twice a Week", "Twice a Week"),
        ("Thrice a Week", "Thrice a Week"),
        ("Once a Month", "Once a Month"),
        ("Twice a Month", "Twice a Month"),
    ]

    DAYS_OF_WEEK = [
        ("Monday", "Monday"),
        ("Tuesday", "Tuesday"),
        ("Wednesday", "Wednesday"),
        ("Thursday", "Thursday"),
        ("Friday", "Friday"),
        ("Saturday", "Saturday"),
        ("Sunday", "Sunday"),
    ]

    RITUAL_TYPE_CHOICES = [
        ('Paid', 'Paid'),
        ('Unpaid', 'Unpaid'),
    ]

    RITUAL_STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    RITUAL_CATEGORY_CHOICES = [
        ('', 'Select Category'),
        ('Daily Rituals', 'Daily Rituals'),
        ('Special Poojas', 'Special Poojas'),
        ('Festival Rituals', 'Festival Rituals'),
    ]

    ritual_perform_time = forms.CharField(
        widget=forms.TextInput(attrs={
            "class": "form-control datetimepicker",
            "placeholder": "Select Time"
        })
    )

    ritual_frequency = forms.ChoiceField(
        choices=RITUAL_FREQUENCY_CHOICES,
        widget=forms.RadioSelect(attrs={"class": "form-check-input"})
    )

    ritual_days = forms.MultipleChoiceField(
        choices=DAYS_OF_WEEK,
        required=False,
        widget=forms.CheckboxSelectMultiple(attrs={"class": "form-check-input ritual-days-checkbox"})
    )
    ritual_type = forms.ChoiceField(
        choices=RITUAL_TYPE_CHOICES,
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
    )

    ritual_status = forms.ChoiceField(
        choices=RITUAL_STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    ritual_category = forms.ChoiceField(
        choices=RITUAL_CATEGORY_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    # ritual_perform_time = forms.DateTimeField(
    #     widget=forms.TextInput(attrs={
    #         'class': 'form-control datetimepicker',
    #         'placeholder': 'DD/MM/YYYY HH:mm'
    #     })
    # )

    class Meta:
        model = Rituals
        fields = [
            'temple_id', 'rituals_label_id', 'ritual_type', 'ritual_category' ,'ritual_status',
            'ritual_price', 'ritual_benefits', 'ritual_procedure', 'ritual_prasadham_or_giveback',
            'ritual_duration', 'ritual_perform_time', 'ritual_updated_by','ritual_frequency','ritual_days'
        ]
        widgets = {
            'ritual_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'ritual_benefits': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'ritual_procedure': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'ritual_prasadham_or_giveback': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'ritual_duration': forms.TextInput(attrs={'class': 'form-control'}),
            'ritual_updated_by': forms.TextInput(attrs={'class': 'form-control'}), 
        }

class RitualsImagesForm(forms.ModelForm):
    class Meta:
        model = RitualsImages
        fields = ['rituals_id', 'image_caption', 'ritual_image', 'ritual_image_status']
        widgets = {
            'rituals_id': forms.NumberInput(attrs={'class': 'form-control'}),
            'image_caption': forms.TextInput(attrs={'class': 'form-control'}),
            'ritual_image_status': forms.TextInput(attrs={'class': 'form-control'}),
        }
