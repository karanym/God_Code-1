from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView
from web_project import TemplateLayout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import *

from django.shortcuts import render
from django.contrib.auth.models import User
from config.settings import BASE_DIR,LOGIN_URL,BASE_URL_SERVER
from django.core.paginator import Paginator
import json,re,os,sys;
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from datetime import datetime
from django.core.files.base import ContentFile, File

from ..authentication.forms import clientform

from ..authentication.models import clientData
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib.auth.hashers import *
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import EmailMessage

from ..authentication.forms import ChangePasswordForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import *
from django.utils.timezone import now

import requests
from django.views import View
from .forms import *
from django.shortcuts import get_object_or_404



"""
This file is a view controller for multiple pages as a module.
Here you can override the page view layout.
Refer to pages/urls.py file for more pages.
"""
ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'gif'])
UPLOAD_FOLDER = str(BASE_DIR)+'/upload'

@method_decorator(login_required, name='dispatch')
class TemplesListView(ListView):
    model = Temples
    template_name = 'temples/temples_list.html'
    context_object_name = 'temples'

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'temples List',
        })

        users = clientData.objects.filter()
        context["users"] = list(users)
    
        return context


def assign_temple(request):
    if request.method != "POST":
        return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=400)
    temple_id = request.POST.get('temple_id')
    user_id = request.POST.get('user_id')

    if not temple_id or not user_id:
        return JsonResponse({'success': False, 'message': 'Missing temple_id or user_id'}, status=400)

    # Fetch the temple and user
    temple = get_object_or_404(Temples, id=temple_id)
    temple.temple_admin = user_id 
    temple.save()

    return JsonResponse({
        'success': True,
        'message': 'Temple admin assigned successfully.',
    })

class TempleDetailsView(ListView):
    model = Temples
    context_object_name = 'temples'
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Temple Details',
        })

        # Convert ID to string to match TextField storage
        temple_id = str(self.kwargs['pk'])
        context['id'] = temple_id
        context['temple_id'] = temple_id

        main_temple = Temples.objects.filter(id=temple_id).first()
        context['main_temple_details']=main_temple

        if main_temple:
            context['main_title']=main_temple.temple_name
            context['icon_image']=main_temple.icon_image
        else:
            context['main_title']=''
            context['icon_image']=''

        # Fetch temple details if exists, otherwise provide an empty form
        temple = TempleDetail.objects.filter(temple_id=temple_id).first()

        context['temple_form'] = TempleDetailForm(instance=temple) if temple else TempleDetailForm()
        context["existing_image"] = temple.detail_image.url if temple and temple.detail_image else None

        # Empty form for TempleDetailItem
        context['item_form'] = TempleDetailItemForm()

        return context

class TemplesCreateView(CreateView):
    model = Temples
    form_class =TemplesForm

    template_name = 'temples/temples_form.html'
    success_url = reverse_lazy('temples')

    def form_valid(self, form):
        # Save the form and redirect
        form.instance.temple_admin = self.request.user.id
        if self.request.user.is_superuser:
            form.instance.approved_status = "approved"
            form.instance.approved_on = now()
        else:
            form.instance.approved_status = "pending"
        return super().form_valid(form)

    def form_invalid(self, form):
        # Debug: Print form errors to console
        print("Form errors:", form.errors)
        return super().form_invalid(form)
    
    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        context.update({
            'title': 'Add New Temples',
        })
        return context

class TemplesUpdateView(UpdateView):
    model = Temples
    form_class = TemplesForm
    template_name = 'temples/temples_form.html'
    success_url = reverse_lazy('temples')

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        id=self.kwargs['pk']
        context['id']=id
        context.update({
            'title': 'Edit Temples',
        })
        return context
    
def temples_list(request):

    temple_name = request.POST.get('temple_name')
    draw = int(request.POST.get('draw', 0))
    start = int(request.POST.get('start', 0))
    length = int(request.POST.get('length', 10))

    # Order column and direction from DataTables
    order_column_index = int(request.POST.get('order[0][column]', 0))  # Column index
    order_direction = request.POST.get('order[0][dir]', 'asc')  # 'asc' or 'desc'

    # Columns you want to order by
    orderable_columns = ['id','temple_name','short_description','status']  # Adjust based on your actual fields

    # Get column to order by, fallback to first column if index is out of range
    order_column = orderable_columns[order_column_index] if order_column_index < len(orderable_columns) else orderable_columns[0]

    # Apply ascending or descending ordering
    if order_direction == 'desc':
        order_column = '-' + order_column

    # Search query from DataTables 
    search_value = request.POST.get('search[value]', '')

    # Query the database
    if request.user.is_authenticated and request.user.is_superuser:
        initial_data = Temples.objects.filter()
    else:
        user_id=request.user.id
        initial_data = Temples.objects.filter(temple_admin=user_id)
    data=initial_data;

    # Apply search filter if there is any
    if search_value:
        data = data.filter(temple_name__icontains=search_value) 

    # Apply ordering
    data = data.order_by(order_column)

    total_records = data.count()

    # Paginate data
    paginator = Paginator(data, length)
    page_number = (start // length) + 1
    page_data = paginator.get_page(page_number)

    # Prepare data for DataTables
    data_list = []
    
    k=0

    for obj in page_data:
        admin_str=''
        if obj.temple_admin != '':
            temple_admin_user = User.objects.filter(id=obj.temple_admin).first()
            admin_str+=' '+str(temple_admin_user.first_name)+ '('+temple_admin_user.email+')'
        else:
            admin_str+='Admin'

        if request.user.is_superuser:
            assign_admin=f"""
        <br><br><button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#assignAdminModal" 
                        data-temple-id="{obj.id}">
                    Assign Admin
                </button>
            """
        else:
            assign_admin=''

        k=(k+1)
        
        status_str=''

        if request.user.is_superuser and obj.approved_status == "pending":

            status_str=f'<button class="btn btn-success btn-sm approve-temple" data-id="{obj.id}">Approve</button>'
            
            status_str+=f'<br><br><button class="btn btn-danger btn-sm reject-temple" data-id="{obj.id}">Reject</button>'
        else:
            status_str= f'<span class="badge bg-{ "success" if obj.approved_status == "approved" else "danger"} status-badge" data-id="{obj.id}" style="cursor:pointer;">{obj.approved_status.capitalize()}</span>'


        action = "View New fields" if request.user.is_superuser else "Add/Edit New fields"
        dynamic_fields_str = f'<br><br><a class="btn btn-sm btn-primary" href="{BASE_URL_SERVER}/temple-dynamic-fields/{obj.id}/"><i class="bx bx-edit-alt me-1"></i> {action}</a><br>'


        data_list.append({
            "sno":k,
            "temple_name":obj.temple_name,
            "icon_image":'<img src="'+obj.icon_image.url+'" alt="" />',
            "detail_link":'<a href="'+BASE_URL_SERVER+'/temple_details/'+str(obj.id)+'/" class="btn btn-sm btn-warning">Update More Details</a>'+assign_admin+""+dynamic_fields_str+str('<br><small><b>Created by : <br>'+admin_str+'</b></small>'),
            "status":status_str,

            "actions":f'<div class="dropdown"><button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu"><a class="dropdown-item" href="'+BASE_URL_SERVER+'/temples/'+str(obj.id)+'/edit"><i class="bx bx-edit-alt me-1"></i> Edit</a><button type="button" class="dropdown-item" onclick="delete_record('+str(obj.id)+')"><i class="bx bx-trash me-1"></i> Delete</button></div></div>'})

    response = {
        'draw': draw,
        'recordsTotal': initial_data.count(),
        'recordsFiltered': total_records,
        'data': data_list,
    }

    return JsonResponse(response)

def delete_temples(request, record_id):
    if request.method == "POST":
        try:
            pmt = Temples.objects.get(id=record_id)
            pmt.delete()
            return JsonResponse({'success': True, 'message': 'Data deleted successfully'})
        except Temples.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Record not found'}, status=404)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)

#temple details

class TempleDetailView(View):

    def get(self, request):
        """Fetch all temples and return JSON response"""
        temples = TempleDetail.objects.filter()
        data = []
        for temple in temples:
            data.append({
                "id": temple.id,
                "short_description": temple.short_description,
                "highlights": temple.highlights,
            })
        return JsonResponse({"temples": data}, safe=False)

    def post(self, request):
        """Create or update a temples based on temple_id"""
        
        temple_id = request.POST.get("temple_id")  # Get temple_id from request

        if temple_id:
            temple_id = str(temple_id)
            temple = TempleDetail.objects.filter(temple_id=temple_id).first()

            if temple:
                form = TempleDetailForm(request.POST, request.FILES, instance=temple)  # Include request.FILES
                message = "Temple updated successfully"
            else:
                # If no temple_id, create a new record
                form = TempleDetailForm(request.POST, request.FILES)  # Include request.FILES
                message = "New Temple created successfully"

        # Validate and save the form
        if form.is_valid():
            temple = form.save()
            return JsonResponse({
                "id": temple.temple_id,  
                "short_description": temple.short_description,
                "highlights": temple.highlights,
                "message": message
            })
        else:
            return JsonResponse({"errors": form.errors}, status=400)

        
class TempleDetailItemView(View):
    def post(self, request):
        """Create a new temple item using a form"""
        form = TempleDetailItemForm(request.POST)
        if form.is_valid():
            item = form.save()
            return JsonResponse({
                "id": item.id,
                "list_title": item.list_title,
                "list_description": item.list_description,
            })
        else:
            return JsonResponse({"errors": form.errors}, status=400)

def save_temple_item(request):
    """Create or update a temple item"""

    item_id = request.POST.get("item_id")  # Item ID (if editing)
    temple_id = request.POST.get("temple_id")  # Parent temple ID

    if not temple_id:
        return JsonResponse({"error": "Temple ID is required."}, status=400)

    if item_id:
        # Updating an existing item
        item = get_object_or_404(TempleDetailItem, id=item_id)
        form = TempleDetailItemForm(request.POST, instance=item)
        message = "Temple item updated successfully"
    else:
        # Creating a new item
        form = TempleDetailItemForm(request.POST)
        message = "New temple item created successfully"

    if form.is_valid():
        item = form.save()
        return JsonResponse({
            "id": item.id,
            "list_title": item.list_title,
            "list_description": item.list_description,
            "message": message
        })
    
    return JsonResponse({"errors": form.errors}, status=400)


def get_temple_items(request, temple_id):
    """Fetch all temple items for a given temple ID"""
    
    items = TempleDetailItem.objects.filter(temple_id=temple_id).values("id", "list_title", "list_description")
    
    return JsonResponse(list(items), safe=False)

def delete_temple_item(request, item_id):
    """Delete a temple item by ID"""
    
    item = get_object_or_404(TempleDetailItem, id=item_id)
    item.delete()
    
    return JsonResponse({"message": "Temple item deleted successfully"})

def approve_temple(request):
    if not request.user.is_superuser:
        return JsonResponse({"success": False, "error": "You are not authorized to approve temples."})

    temple_id = request.POST.get("temple_id")

    try:
        temple = Temples.objects.get(id=temple_id)
        temple.approved_status = "approved"
        temple.approved_on = now()
        temple.save()

        # Fetch temple admin details from ClientData
        message_res=''

        try:
            client_data = clientData.objects.get(client_id=temple.temple_admin)
            admin_email = client_data.email
            name = str(client_data.first_name)+' '+str(client_data.last_name)
            admin_mobile = client_data.phone_number
            #mail and whatsapp

            # Send Approval Email
            send_mail(
                subject="Temple Approval Notification",
                message=f"Hello,\n\nYour temple '{temple.temple_name}' has been approved.\nYou can now manage it from the admin panel.",
                from_email="hellojarvin@gmail.com",
                recipient_list=[admin_email],
                fail_silently=False,
            )

            template_name='sarvatirthamayi_temple_approval'
        
            if len(admin_mobile) == 10 and admin_mobile.isdigit():
                mobile = "91" + admin_mobile  
                phone_number=mobile
                temple_name=temple.temple_name
                temple_location=temple.temple_state
                approved_on=temple.approved_on.strftime("%d-%m-%Y %H:%M") if temple.approved_on else None

                payload = {
                    "messaging_product": "whatsapp",
                    "to": str(phone_number),
                    "type": "template",
                    "template": {
                        "name": str(template_name),
                        "language":{
                            "code":"en"
                        },
                        "components": [
                        {
                            "type": "body",
                            "parameters": [
                            { "type": "text", "text": str(name) },
                            { "type": "text", "text": str(temple_name) },
                            { "type": "text", "text": str(temple_name) },
                            { "type": "text", "text": str(temple_location)},
                            { "type": "text", "text": str(approved_on) }
                            ]
                        }
                    ]
                    }
                }

                try:
                    token='EAAL7v9krplEBO7Efx8LOnl4Antl0gWgOtzTUi28INCyAoiia2wIDZBIa4qZCDpdYZApKHmtuOkgXdMe4IrYZCGRSCe2NZA9m2zs4U2iEebbsi14BBTPpKUthgr51iJmo7PPDW7xuX7amLZBVeYhaTGnloEiYupejhmiFm0JPud6j0e2J2NOdX7yErfqxjmfsbG6AZDZD'
                    phonenumber_id='371941399332594' #jarvin

                    data_json = json.dumps(payload)
                    url = 'https://graph.facebook.com/v20.0/'+str(phonenumber_id)+'/messages'
                    headers = {'content-type': 'application/json',"Accept": "application/json", 'Accept-Charset': 'UTF-8','Authorization':'Bearer '+str(token)}
                    r = requests.post(url, data=data_json, headers=headers)
                    res_obj= json.loads(r.text)

                    print("URL:", url)  # Debugging
                    print("Headers:", headers)
                    print("Response:", r.status_code, r.text)
                    
                    if r.status_code == 200:
                        message_res='Message has been sent successfully'
                    else:
                        message_res='Message is not sent. Status code is '+str(r.status_code)+'||'+str(url)+'||'+r.reason
                except:
                    res_obj= 'error in sending whatsapp messages'
                    message_res='Error in message sending'
            
            #message to whatsapp
            return JsonResponse({"success": True, "message": "Temple has been approved"})
            #mail and whatsapp
        except clientData.DoesNotExist:
            return JsonResponse({"success": False, "error": "Temple admin not found."})

    except Temples.DoesNotExist:
        return JsonResponse({"success": False, "error": "Temple not found."})

def reject_temple(request):
    if not request.user.is_superuser:
        return JsonResponse({"success": False, "error": "You are not authorized to reject temples."})

    temple_id = request.POST.get("temple_id")
    rejection_reason = request.POST.get("rejection_reason", "")
    try:
        temple = Temples.objects.get(id=temple_id)
        temple.approved_status = "rejected"
        temple.rejected_on = now()
        temple.approved_on = None
        temple.rejection_reason = rejection_reason
        temple.save()
        #mail and whatsapp
        # Fetch temple admin details from ClientData
        message_res=''

        try:
            client_data = clientData.objects.get(client_id=temple.temple_admin)
            admin_email = client_data.email
            name = str(client_data.first_name)+' '+str(client_data.last_name)
            admin_mobile = client_data.phone_number
            #mail and whatsapp

            # Send Approval Email
            send_mail(
                subject="Temple Rejection Notification",
                message=f"Your temple '{temple.temple_name}' has been rejected on {temple.rejected_on.strftime('%d-%m-%Y %H:%M')}. Reason: {rejection_reason}",
                from_email="hellojarvin@gmail.com",
                recipient_list=[admin_email],
                fail_silently=False,
            )

            template_name='sarvatirthamayi_temple_rejection'
        
            if len(admin_mobile) == 10 and admin_mobile.isdigit():
                mobile = "91" + admin_mobile  
                phone_number=mobile
                temple_name=temple.temple_name
                temple_location=temple.temple_state
                rejected_on=temple.rejected_on.strftime("%d-%m-%Y %H:%M") if temple.rejected_on else None

                payload = {
                    "messaging_product": "whatsapp",
                    "to": str(phone_number),
                    "type": "template",
                    "template": {
                        "name": str(template_name),
                        "language":{
                            "code":"en"
                        },
                        "components": [
                        {
                            "type": "body",
                            "parameters": [
                            { "type": "text", "text": str(name) },
                            { "type": "text", "text": str(temple_name) },
                            { "type": "text", "text": str(rejected_on) },
                            { "type": "text", "text": str(rejection_reason)}
                            ]
                        }
                    ]
                    }
                }

                try:
                    token='EAAL7v9krplEBO7Efx8LOnl4Antl0gWgOtzTUi28INCyAoiia2wIDZBIa4qZCDpdYZApKHmtuOkgXdMe4IrYZCGRSCe2NZA9m2zs4U2iEebbsi14BBTPpKUthgr51iJmo7PPDW7xuX7amLZBVeYhaTGnloEiYupejhmiFm0JPud6j0e2J2NOdX7yErfqxjmfsbG6AZDZD'
                    phonenumber_id='371941399332594' #jarvin

                    data_json = json.dumps(payload)
                    url = 'https://graph.facebook.com/v20.0/'+str(phonenumber_id)+'/messages'
                    headers = {'content-type': 'application/json',"Accept": "application/json", 'Accept-Charset': 'UTF-8','Authorization':'Bearer '+str(token)}
                    r = requests.post(url, data=data_json, headers=headers)
                    res_obj= json.loads(r.text)

                    print("URL:", url)  # Debugging
                    print("Headers:", headers)
                    print("Response:", r.status_code, r.text)
                    
                    if r.status_code == 200:
                        message_res='Message has been sent successfully'
                    else:
                        message_res='Message is not sent. Status code is '+str(r.status_code)+'||'+str(url)+'||'+r.reason
                except:
                    res_obj= 'error in sending whatsapp messages'
                    message_res='Error in message sending'
            
            #message to whatsapp
            return JsonResponse({"success": True, "message": "Temple rejected successfully"})
            #mail and whatsapp
        except clientData.DoesNotExist:
            return JsonResponse({"success": False, "error": "Temple admin not found."})
        #mail and whatsapp
        
    except Temples.DoesNotExist:
        return JsonResponse({"success": False, "error": "Temple not found."})


class TempleDynamicFieldView(TemplateView):
    template_name = "temples/temple_dynamic_fields.html"

    def get_context_data(self, **kwargs):
        """Load temple fields and template layout context."""
        context = super().get_context_data(**kwargs)
        temple_id = self.kwargs["temple_id"]
        context["temple_id"] = temple_id
        temple_details=Temples.objects.filter(id=temple_id).first()
        context["temple_details"]=temple_details
        context["fields"] = TempleDynamicField.objects.filter(temple_id=temple_id).order_by("-timestamp")

        # Initialize global template layout (fix your layout_path issue)
        context = TemplateLayout.init(self, context)
        return context

def add_dynamic_field(request, temple_id):
    """Handles creating a new dynamic field."""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            user_id=request.user.id
            field = TempleDynamicField.objects.create(
                temple_id=temple_id,
                temple_admin=user_id,
                field_name=data.get("field_name"),
                field_description=data.get("field_description"),
                timestamp=now(),
            )
            return JsonResponse({"status": "success", "field_id": field.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

def edit_dynamic_field(request, temple_id):
    """Handles editing an existing dynamic field."""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            field = get_object_or_404(TempleDynamicField, id=data.get("field_id"), temple_id=temple_id)
            field.field_name = data.get("field_name")
            field.field_description = data.get("field_description")     
            field.timestamp = now()
            field.save()
            return JsonResponse({"status": "success", "field_id": field.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

def delete_dynamic_field(request, temple_id):
    """Handles deleting a dynamic field."""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            field = get_object_or_404(TempleDynamicField, id=data.get("field_id"), temple_id=temple_id)
            field.delete()
            return JsonResponse({"status": "success", "message": "Field deleted"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)
